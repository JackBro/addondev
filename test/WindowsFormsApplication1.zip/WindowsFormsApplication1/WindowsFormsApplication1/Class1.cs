﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{

    //public enum UpDateType
    //{
    //    Time,
    //    Title,
    //    Text
    //}
    public class ChangeItemEventArgs : EventArgs
    {
        public ChangeType type;
        public DateTime date;
        public string title;
        public string text;
    }
    delegate void ChangeItemEventHandler(object sender, ChangeItemEventArgs e);

    class Item{
        public DateTime date;
        public string title;
        public string text;
    }

    public enum ChangeType
    {
        Add,
        Delete,
        Update
    }
    public class ChangeEventArgs : EventArgs
    {
        public ChangeType type;
        public string name;
    }
    delegate void ChangeEventHandler(object sender, ChangeEventArgs e);
    class Class1
    {
        public event ChangeItemEventHandler ChangeItemItemEvent;
        public string name;
        public List<Item> items;

        public void Add(Item item)
        {
            items.Add(item);
            if (ChangeItemItemEvent != null)
            {
                ChangeItemItemEvent(item, new ChangeItemEventArgs { type= ChangeType.Add });
            }
        }

        public void Delete(Item item)
        {
            items.Remove(item);
            if (ChangeItemItemEvent != null)
            {
                ChangeItemItemEvent(item, new ChangeItemEventArgs { type = ChangeType.Delete });
            }
        }
    }

    class manager
    {
        public event ChangeEventHandler ChangeEvent;
        public Dictionary<string, Class1> atc;

        public void Add(string name)
        {
            if (!atc.ContainsKey(name))
            {

                atc.Add(name, new Class1 { name=name, items=new List<Item>() });
                if (ChangeEvent != null)
                {
                    ChangeEvent(atc[name], new ChangeEventArgs { name=name, type = ChangeType.Add });
                }
            }
        }

        public void Delete(string name)
        {
            if (atc.ContainsKey(name))
            {
                var ac = atc[name];
                atc.Remove(name);
                if (ChangeEvent != null)
                {
                    ChangeEvent(ac, new ChangeEventArgs { name = name, type = ChangeType.Delete });
                }
            }
        }
    }
}
