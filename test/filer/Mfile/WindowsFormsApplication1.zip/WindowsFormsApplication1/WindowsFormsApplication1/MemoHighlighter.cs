﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sgry.Azuki.Highlighter;
using Sgry.Azuki;

namespace WindowsFormsApplication1
{
    class MemoHighlighter : KeywordHighlighter
    {		
        public MemoHighlighter(Config config)
        {
            var encs = config.editorconfig.enclosurs;
            encs.ForEach(x =>
            {
                AddEnclosure(x.start, x.end, x.cc);
            });

            var single = config.editorconfig.singleLines;
            single.ForEach(x => {
                AddLineHighlight(x.start, x.cc);
            });

            //AddKeywordSet(new string[] { "<<<", ">>>" }, CharClass.Value);
            //AddEnclosure("[>>>", "]", CharClass.Value);
            //AddEnclosure("[", "]", CharClass.Value);
            //AddLineHighlight("=", CharClass.Value);
            //
        }
    }
}
