﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sgry.Azuki.Highlighter;
using Sgry.Azuki;

namespace WindowsFormsApplication1
{
    class MemoHighlighter : KeywordHighlighter
    {		
        public MemoHighlighter()
        {

            AddKeywordSet(new string[] { "<<<", ">>>" }, CharClass.Value);
            //AddEnclosure("[", "]", CharClass.Value);
            //AddLineHighlight("<<<", CharClass.Value);
            //AddLineHighlight(">>>", CharClass.Keyword);
        }
    }
}
