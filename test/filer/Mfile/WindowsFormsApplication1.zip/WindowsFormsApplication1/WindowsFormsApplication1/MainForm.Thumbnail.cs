﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Text.RegularExpressions;
using System.IO;

namespace WindowsFormsApplication1 {
    public partial class MainForm : Form{

        private void execute() {

        }


        // 幅w、高さhのImageオブジェクトを作成
        Image createThumbnail(Image image, int w, int h) {
            Bitmap canvas = new Bitmap(w, h);

            Graphics g = Graphics.FromImage(canvas);
            g.FillRectangle(new SolidBrush(Color.White), 0, 0, w, h);

            float fw = (float)w / (float)image.Width;
            float fh = (float)h / (float)image.Height;

            float scale = Math.Min(fw, fh);
            fw = image.Width * scale;
            fh = image.Height * scale;

            var th = image.GetThumbnailImage((int)fw, (int)fh, delegate { return false; }, IntPtr.Zero);
            g.DrawImage(th, (w - fw) / 2, (h - fh) / 2, fw, fh);
            g.Dispose();
            return canvas;
        }

        Regex regimage = new Regex(@"file:\/\/\/(.*(\.jpg|\.jepg|\.png|\.gif|\.bmp|\.tif))",  RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private void thbutton1_Click() {

            splitContainer2.Panel2Collapsed = false;
            tabControl1.SelectedTab = tabPage2;

            var list = new List<string>();
            string text = mainEditor.Text;
            var ms = regimage.Matches(text);
            for (int i = 0; i < ms.Count; i++) {
                if (ms[i].Groups.Count > 1) {
                    var img = ms[i].Groups[1].Value;
                    if (File.Exists(img)) {
                        list.Add(img);
                    }
                }
            }

            int width = 100;
            int height = 80;

            imageList1.ImageSize = new Size(width, height);
            //listView1.LargeImageList = imageList1;
            for (int i = 0; i < list.Count; i++) {
                Image original = Bitmap.FromFile(list[i]);
                Image thumbnail = createThumbnail(original, width, height);
                imageList1.Images.Add(thumbnail);
                ThumbnailListView.Items.Add(Path.GetFileName(list[i]), i);

                original.Dispose();
                thumbnail.Dispose();
            }
        } 
    }
}
