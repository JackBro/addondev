﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class ListViewEx : ListView
    {
        private List<Item> items;
        private Config _config;
        //public Search search { get; set; }

        public List<Item> DataItems
        {
            get { return this.items; }
            set
            {
                this.items.Clear();
                this.items.AddRange(value);
                //this.items = value;
                this.VirtualListSize = items.Count;
            }
        }

        public ListViewEx(Config config)
        {
            _config = config;
            init(new List<Item>());
        }

        //public ListViewEx(Config config, List<Item> items)
        //{
        //    _config = config;
        //    if (items == null)
        //    {
        //        items = new List<Item>();
        //    }
        //    init(items);
        //}

        private void init(List<Item> items)
        {
            this.items = items;

            this.FullRowSelect = true;
            this.MultiSelect = false;
            this.HideSelection = false;
            this.View = View.Details;

            ColumnHeader headerName = new ColumnHeader();
            headerName.Name = "title";
            headerName.Text = "Title";
            this.Columns.Add(headerName);
            //headerName.Width = -2;

            ColumnHeader headerDateTime = new ColumnHeader();
            headerDateTime.Name = "time";
            headerDateTime.Text = "Time";
            this.Columns.Add(headerDateTime);
            headerDateTime.Width = _config.DateTimeColumnWidth;
            this.ColumnClick += (s, e) => {
                if (e.Column == headerDateTime.Index) {
                    this.SortByDateTime();
                    this.Update();
                }
            };

            this.SizeChanged += (s, e) => {
                headerName.Width = this.Width - headerDateTime.Width - 5;
            };

            this.VirtualMode = true;
            this.VirtualListSize = items.Count;

            this.RetrieveVirtualItem += (sender, e) =>
            {
                if (e.ItemIndex < this.items.Count)
                {
                    var item = this.items[e.ItemIndex];
                    var viewitem = new ListViewItem();
                    viewitem.Text = item.title;
                    viewitem.SubItems.Add(item.date.ToString(_config.DatePattern));
                    e.Item = viewitem;
                }
            };
        }

        public void SortByDateTime() {
            this.BeginUpdate();
            this.items = this.items.OrderByDescending((x) => x.date).ToList<Item>();
            this.EndUpdate();
        }

        public Item SelectedItem {
            get {
                if (this.SelectedIndices.Count > 0) {
                    return this.items[this.SelectedIndices[0]];
                } else {
                    return null;
                }
            }

            //set {
            //    if (this.items.Contains(value)) {
            //        var index = this.items.IndexOf(value);
            //    }
            //}
        }

        public void SetSelect(Item item)
        {
            var index = this.items.FindIndex(x =>
            {
                return x==item;
            });
            if (index >= 0)
            {
                this.Items[index].Selected = true;
            }
        }

        public void DeleteItem(Item item)
        {
            if (this.items.Remove(item))
            {
                this.VirtualListSize = items.Count;

            }
        }

        public void DeleteItem(List<Item> item) {
            if (item.Count == 1)
            {
                this.items.Remove(item[0]);
            }
            else
            {
                this.items.RemoveAll(x =>
                {
                    return item.Contains(x);
                });
            }
            if (this.items.Count != this.VirtualListSize)
            {
                this.VirtualListSize = items.Count;
            }
        }

        public void ClearItem()
        {
            this.items.Clear();
            this.VirtualListSize = 0;
        }

        //public void InsertItem(int index, Item item) {
        //    items.Insert(index, item);
        //    this.VirtualListSize = items.Count;
        //}

        public void AddItem(Item item, bool isselect)
        {
            //items.Add(item);
            items.Insert(0, item);
            this.VirtualListSize = items.Count;
            if (isselect) {
                this.Items[0].Selected = true;
                this.EnsureVisible(0);
            }
            //if (search.getSearch().Invoke(item))
            //{
            //    var i = ItemManager.Insert(items, item);
            //    this.VirtualListSize = items.Count;
            //    return i;
            //}
            //return -1;
        }
        //public void AddItem(List<Item> items) {
        //    items.AddRange(items);
        //    this.VirtualListSize = items.Count;
        //}

        //private List<Data> nulldata = new List<Data>();
        //public List<Data> GetActive()
        //{
        //    if (this.SelectedIndices.Count > 0)
        //    {
        //        var a = new List<Data>();
        //        foreach (int index in this.SelectedIndices)
        //        {
        //            a.Add(this.items[index]);
        //        }
        //        return a;
        //    }

        //    return nulldata;
        //}

        //public Data GetSelectedItem()
        //{
        //    if (this.SelectedIndices.Count == 1)
        //    {
        //        return this.items[this.SelectedIndices[0]];
        //    }
        //    return null;
        //}
    }
}
