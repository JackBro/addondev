﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class ListViewEx : ListView
    {
        private List<Item> items;

        //public Search search { get; set; }

        public List<Item> DataItems
        {
            get { return this.items; }
            set
            {
                this.items = value;
                this.VirtualListSize = items.Count;
            }
        }

        public ListViewEx()
        {
            init(new List<Item>());
        }

        public ListViewEx(List<Item> items)
        {
            if (items == null)
            {
                items = new List<Item>();
            }
            init(items);
        }

        private void init(List<Item> items)
        {
            this.items = items;

            this.FullRowSelect = true;
            this.MultiSelect = false;
            this.HideSelection = false;
            this.View = View.Details;

            ColumnHeader headerName = new ColumnHeader();
            headerName.Name = "title";
            headerName.Text = "Title";
            this.Columns.Add(headerName);
            //headerName.Width = -2;

            ColumnHeader headerDateTime = new ColumnHeader();
            headerDateTime.Name = "time";
            headerDateTime.Text = "Time";
            this.Columns.Add(headerDateTime);
            headerDateTime.Width = 200;

            //this.SizeChanged += (s, e) =>
            //{
            //    headerName.Width = this.Width - headerDateTime.Width - headerID.Width - 5;
            //};

            this.VirtualMode = true;
            this.VirtualListSize = items.Count;

            this.RetrieveVirtualItem += (sender, e) =>
            {
                if (e.ItemIndex < this.items.Count)
                {
                    var item = this.items[e.ItemIndex];
                    var viewitem = new ListViewItem();
                    viewitem.Text = item.title;
                    viewitem.SubItems.Add(item.date.ToString("yyyy/MM/dd HH:mm:ss"));
                    e.Item = viewitem;
                }
            };
        }

        public void DeleteItem(Item item)
        {
            if (this.items.Remove(item))
            {
                this.VirtualListSize = items.Count;

            }
        }

        public void ClearItem()
        {
            this.items.Clear();
            this.VirtualListSize = 0;
        }

        public void AddItem(Item item)
        {
            items.Add(item);
            this.VirtualListSize = items.Count;
            //if (search.getSearch().Invoke(item))
            //{
            //    var i = ItemManager.Insert(items, item);
            //    this.VirtualListSize = items.Count;
            //    return i;
            //}
            //return -1;
        }

        //private List<Data> nulldata = new List<Data>();
        //public List<Data> GetActive()
        //{
        //    if (this.SelectedIndices.Count > 0)
        //    {
        //        var a = new List<Data>();
        //        foreach (int index in this.SelectedIndices)
        //        {
        //            a.Add(this.items[index]);
        //        }
        //        return a;
        //    }

        //    return nulldata;
        //}

        //public Data GetSelectedItem()
        //{
        //    if (this.SelectedIndices.Count == 1)
        //    {
        //        return this.items[this.SelectedIndices[0]];
        //    }
        //    return null;
        //}
    }
}
