﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace WindowsFormsApplication1 {
    class ViewPanel{
        public Panel panel;
        public int Line;
    }
    class ViewPanelManager {
        private Color _backColor;
        private Dictionary<Control, List<ViewPanel>> _viewpaneldic;
        public ImageList Images;

        public ViewPanelManager(Size imageSize, Color backColor) {
            _viewpaneldic = new Dictionary<Control, List<ViewPanel>>();
            Images = new ImageList();
            Images.ImageSize = imageSize;
            _backColor = backColor;
        }

        public void setPanel(Control parent) {
            if (_viewpaneldic.ContainsKey(parent)) {
                _viewpaneldic[parent].Clear();
            } else {
                _viewpaneldic.Add(parent, new List<ViewPanel>());
            }
        }

        public List<ViewPanel> getPanels(Control parent) {
            if(!_viewpaneldic.ContainsKey(parent)){
                _viewpaneldic.Add(parent, new List<ViewPanel>());
            }
            return _viewpaneldic[parent];
        }

        public void removePanel(Control parent, Predicate<ViewPanel> m) {
            var panels = getPanels(parent);
            var r = panels.FindAll(m);
            r.ForEach(x => {
                panels.Remove(x);
                parent.Controls.Remove(x.panel);
            });
        }

        public Panel addPanel(Control parent, string path, int line, Point location) {
            if (!Images.Images.ContainsKey(path)) {
                Image original = null;
                Image thumbnail = null;
                try {
                    original = Bitmap.FromFile(path);
                    thumbnail = createThumbnail(original, Images.ImageSize.Width, Images.ImageSize.Height);
                    Images.Images.Add(path, thumbnail);
                }
                catch (Exception) {
                }
                finally {
                    if (original != null) original.Dispose();
                    //if (thumbnail != null) thumbnail.Dispose();
                }
            }

            var p = new Panel();
            if (Images.Images.ContainsKey(path)) {
                p.BackgroundImage = Images.Images[path];
            }
            p.Size = new Size(Images.ImageSize.Width, Images.ImageSize.Height);
            p.Location = location;
            p.Cursor = Cursors.Hand;
            _viewpaneldic[parent].Add(new ViewPanel() { panel = p, Line = line });

            parent.Controls.Add(p);

            return p;
        }

        private Image createThumbnail(Image image, int w, int h) {
            Bitmap canvas = new Bitmap(w, h);

            Graphics g = Graphics.FromImage(canvas);
            
            //g.FillRectangle(new SolidBrush(Color.White), 0, 0, w, h);
            g.FillRectangle(new SolidBrush(_backColor), 0, 0, w, h);


            float fw = (float)w / (float)image.Width;
            float fh = (float)h / (float)image.Height;

            float scale = Math.Min(fw, fh);
            fw = image.Width * scale;
            fh = image.Height * scale;

            var th = image.GetThumbnailImage((int)fw, (int)fh, delegate { return false; }, IntPtr.Zero);
            g.DrawImage(th, (w - fw) / 2, (h - fh) / 2, fw, fh);
            
            //var p = new Pen(Color.Blue, 3);
            //g.DrawRectangle(p, 0, 0, w-3, h-3); 

            g.Dispose();
            return canvas;
        }
    }
}
