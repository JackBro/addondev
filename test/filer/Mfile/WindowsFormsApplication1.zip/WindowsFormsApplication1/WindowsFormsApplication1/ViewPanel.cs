﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace WindowsFormsApplication1 {
    class ViewPanel{
        public Panel panel;
        public int Line;
    }
    class ViewPanelManager {
        //private Control parent;
        //public List<ViewPanel> panels;
        private Dictionary<Control, List<ViewPanel>> viewpaneldic;
        public ImageList images;

        public ViewPanelManager(Size imageSize) {
            viewpaneldic = new Dictionary<Control, List<ViewPanel>>();
            images = new ImageList();
            images.ImageSize = imageSize;
        }

        public void setPanel(Control parent) {
            if (viewpaneldic.ContainsKey(parent)) {
                viewpaneldic[parent].Clear();
            } else {
                viewpaneldic.Add(parent, new List<ViewPanel>());
            }
        }

        public List<ViewPanel> getPanels(Control parent) {
            if(!viewpaneldic.ContainsKey(parent)){
                viewpaneldic.Add(parent, new List<ViewPanel>());
            }
            return viewpaneldic[parent];
        }

        public void removePanel(Control parent, Predicate<ViewPanel> m) {
            var panels = getPanels(parent);
            var r = panels.FindAll(m);
            r.ForEach(x => {
                panels.Remove(x);
                parent.Controls.Remove(x.panel);
            });
        }

        public Panel addPanel(Control parent, string path, int line, Point location) {
            if (!images.Images.ContainsKey(path)) {
                Image original = null;
                Image thumbnail = null;
                try {
                    original = Bitmap.FromFile(path);
                    thumbnail = createThumbnail(original, images.ImageSize.Width, images.ImageSize.Height);
                    images.Images.Add(path, thumbnail);
                }
                catch (Exception) {
                    //throw;
                }
                finally {
                    if (original != null) original.Dispose();
                    //if (thumbnail != null) thumbnail.Dispose();
                }
            }

            var p = new Panel();
            if (images.Images.ContainsKey(path)) {
                //var iii = images.Images[key];
                p.BackgroundImage = images.Images[path];
            }
            p.Size = new Size(images.ImageSize.Width, images.ImageSize.Height);
            p.Location = location;
            p.Cursor = Cursors.Hand;
            viewpaneldic[parent].Add(new ViewPanel() { panel = p, Line = line });

            parent.Controls.Add(p);
            //panels.Add(new ViewPanel() { panel = p, Line = line });

            return p;
        }

        private Image createThumbnail(Image image, int w, int h) {
            Bitmap canvas = new Bitmap(w, h);

            Graphics g = Graphics.FromImage(canvas);
            
            g.FillRectangle(new SolidBrush(Color.White), 0, 0, w, h);


            float fw = (float)w / (float)image.Width;
            float fh = (float)h / (float)image.Height;

            float scale = Math.Min(fw, fh);
            fw = image.Width * scale;
            fh = image.Height * scale;

            var th = image.GetThumbnailImage((int)fw, (int)fh, delegate { return false; }, IntPtr.Zero);
            g.DrawImage(th, (w - fw) / 2, (h - fh) / 2, fw, fh);
            
            //var p = new Pen(Color.Blue, 3);
            //g.DrawRectangle(p, 0, 0, w-3, h-3); 

            g.Dispose();
            return canvas;
        }
    }
}
