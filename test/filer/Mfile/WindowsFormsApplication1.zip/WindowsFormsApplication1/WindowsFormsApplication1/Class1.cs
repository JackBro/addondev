﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace WindowsFormsApplication1 {
    public class Item {
        public int id { get; set; }
        public DateTime date { get; set; }

        [XmlIgnore]
        public string title { get; set; }

        private string _text;
        public string text {
            get { return _text; }
            set {
                _text = value;
                if (_text == null) {
                    _text = string.Empty;
                }
                var index = _text.IndexOf(Environment.NewLine);
                if (_text.Length > 0 && index > 0) {
                    title = _text.Substring(0, index);
                } else {
                    title = text;
                }
            }
        }
    }

    public class Class1 {
        public string name { get; set; }
        public List<Item> _items { get; set; }

        public Class1() {
            _items = new List<Item>();
        }

        public void clear() {
            _items.Clear();

        }

        public void Add(Item item) {
            _items.Add(item);
        }

        public void Add(List<Item> items) {
            _items.AddRange(items);
        }
        public void Delete(Item item) {
            _items.Remove(item);
        }
        public void Delete(List<Item> items) {
            _items.RemoveAll(x => {
                return items.Contains(x);
            });
        }
    }

    class manager {
        public string dataDir;
        public List<Class1> acts;
        private Dictionary<int, Item> itemdic = new Dictionary<int, Item>();

        public manager() {
            acts = new List<Class1>();
        }

        public Item getItem(int id) {
            foreach (var cl in acts) {
                var item = cl._items.Find(y => {
                    return y.id == id;
                });
                if (item != null) {
                    return item;
                }
            }
            return null;
        }

        public Class1 getClass(string name) {
            var cl = acts.Find((x) => { return x.name.Equals(name); });
            if (cl == null) {
                try {
                    cl = XMLSerializer.Deserialize<Class1>(Path.Combine(dataDir, name));
                }
                catch (Exception) {

                    cl = new Class1() { name = name, _items = new List<Item>() };

                }
                cl._items.ForEach(x => {
                    x.text = x.text.Replace("\n", "\r\n");
                    itemdic.Add(x.id, x);
                });
                acts.Add(cl);
            }
            return cl;
        }

        private int createID() {
            int seed = Environment.TickCount;
            var id = 0;
            while (itemdic.ContainsKey(id)) {
                Random rnd = new Random(seed++);
                id = rnd.Next();
            }
            return id;
        }

        public Item createItem() {
            var id = createID();
            var item = new Item() { id = id, text = "=new", date = DateTime.Now };
            itemdic.Add(id, item);
            return item;
        }

        public void Insert(int index, string name) {
            if (acts.Find((x) => { return x.name.Equals(name); }) == null) {
                var act = new Class1 { name = name, _items = new List<Item>() };
                //acts.Add(act);
                acts.Insert(index, act);
            }
        }


        public void Add(string name) {
            if (acts.Find((x) => { return x.name.Equals(name); }) == null) {
                var act = new Class1 { name = name, _items = new List<Item>() };
                acts.Add(act);
            }
        }

        public void Remove(string name) {
            var act = acts.Find((x) => { return x.name.Equals(name); });
            if (act != null) acts.Remove(act);
        }

        public void Save(string name) {
            var cl = acts.Find(x => {
                return x.name.Equals(name);
            });
            if (cl != null) {
                XMLSerializer.Serialize<Class1>(Path.Combine(dataDir, cl.name), cl);
            }
        }

        //public void Load(List<string> filelist) {
        //    if (filelist.Count == 0) {
        //        filelist.Add("File.xml");
        //        filelist.Add("Trust.xml");
        //        filelist.ForEach(x => {
        //            XMLSerializer.Serialize<Class1>(Path.Combine(dataDir, x), this.getClass(x));
        //        });
        //    } else if (!filelist.Contains("Trust.xml")) {
        //        filelist.Add("Trust.xml");
        //        XMLSerializer.Serialize<Class1>(Path.Combine(dataDir, "Trust.xml"), this.getClass("Trust.xml"));
        //    }
        //}
    }
}
