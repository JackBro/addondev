﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    //public enum UpDateType
    //{
    //    Time,
    //    Title,
    //    Text
    //}
    //public class ChangeItemEventArgs : EventArgs
    //{
    //    public ChangeType type;
    //    public DateTime date;
    //    public string title;
    //    public string text;
    //    public List<Item> items;
    //    public TreeNode node;
    //}
    //public delegate void ChangeItemEventHandler(object sender, ChangeItemEventArgs e);

    public class Item{
        public int id { get; set; }
        public DateTime date { get; set; }
        public string title { get; set; }
        public string text { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(String.Format("[>>>{0}]{1} {2}", this.id, this.title, this.date.ToString("yyyy/MM/dd%2hh:mmm")));
            sb.AppendLine(this.text);
            return sb.ToString();
        }
    }

    //public enum ChangeType
    //{
    //    Add,
    //    //Adds,
    //    Delete,
    //    //Deletes,
    //    Update
    //}
    //public class ChangeEventArgs : EventArgs
    //{
    //    public ChangeType type;
    //    public string name;
    //}
    //public delegate void ChangeEventHandler(object sender, ChangeEventArgs e);
    public class Class1
    {
        //public event ChangeItemEventHandler ChangeItemItemEvent;
        public string name { get; set; }
        public List<Item> _items { get; set; }

        //public Class1(string name)
        //{
        //    this.name = name;
        //    items = new List<Item>();
        //}
        public Class1()
        {
            _items = new List<Item>();
        }

        public void Add(Item item) {
            _items.Add(item);
        }

        public void Add(List<Item> items) {
            _items.AddRange(items);
        }

        //public void Add(Item item)
        //{
        //    _items.Add(item);
        //    if (ChangeItemItemEvent != null)
        //    {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Add, items = new List<Item>() { item } });
        //    }
        //}

        //public void Add(List<Item> items) {
        //    this._items.AddRange(items);
        //    if (ChangeItemItemEvent != null) {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Add, items = items });
        //    }
        //}

        //public void Delete(Item item)
        //{
        //    _items.Remove(item);
        //    if (ChangeItemItemEvent != null)
        //    {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Delete, items = new List<Item>() { item } });
        //    }
        //}

        //public void Delete(List<Item> items) {
        //    _items.RemoveAll(x=>{
        //        return items.Contains(x);
        //    });
        //    if (ChangeItemItemEvent != null) {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Delete, items = items });
        //    }
        //}
    }

    class manager
    {
        //public event ChangeEventHandler ChangeEvent;
        //public Dictionary<string, Class1> atc;
        public List<Class1> acts;

        //private HashSet<int> ids=new HashSet<int>();
        private Dictionary<int, Item> itemdic = new Dictionary<int, Item>();

        public manager()
        {
            acts = new List<Class1>();
        }

        public Item getItem(int id) {
            foreach (var cl in acts) {
                var item = cl._items.Find(y => {
                    return y.id == id;
                });
                if (item != null) {
                    return item;
                }
            }
            return null;
        }

        public Class1 getClass(string name) {
            var cl = acts.Find((x) => { return x.name.Equals(name); });
            if(cl==null){
                try {
                    cl = XMLSerializer.Deserialize<Class1>(name);
                } catch (Exception) {

                    cl = new Class1() { name = name, _items = new List<Item>() };
                    
                }
                cl._items.ForEach(x=>{
                    itemdic.Add(x.id, x);
                });
                acts.Add(cl);
            }
            return cl;
        }

        private int createID() {        
            int seed = Environment.TickCount;
            var id = 0;
            while (itemdic.ContainsKey(id)) {
                Random rnd = new Random(seed++);
                id = rnd.Next();
            }
            return id;
        }

        public Item createItem() {
            var id = createID();
            var item = new Item() { id = id, title = "new", text="", date = DateTime.Now };
            itemdic.Add(id, item);
            return item;
        }

        //public void Add(string name, Class1 class1)
        //{
        //    if (acts.Find((x) => { if (x.name == null) return false; return x.name.Equals(name); }) == null)
        //    {
        //        class1.name = name;
        //        acts.Add(class1);
        //        if (ChangeEvent != null)
        //        {
        //            ChangeEvent(class1, new ChangeEventArgs { name = name, type = ChangeType.Add });
        //        }
        //    }
        //    else
        //    {
        //    }
        //}

        public void Add(string name)
        {
            if (acts.Find((x) => { return x.name.Equals(name); }) == null)
            {
                var act = new Class1 { name = name, _items = new List<Item>() };
                acts.Add(act);
                //if (ChangeEvent != null)
                //{
                //    ChangeEvent(act, new ChangeEventArgs { name = name, type = ChangeType.Add });
                //}
            }
        }

        public void Delete(string name)
        {
            var act = acts.Find((x) => { return x.name.Equals(name); });
            if (act != null) acts.Remove(act);
            //if (act != null)
            //{
            //    acts.Remove(act);
            //    if (ChangeEvent != null)
            //    {
            //        ChangeEvent(act, new ChangeEventArgs { name = name, type = ChangeType.Delete });
            //    }
            //}
        }

        //public void Save() {
        //}
        //public void Save(string actname) {
        //    var cl = acts.Find(x=>{
        //        return x.name.Equals(actname);
        //    });
        //    if (cl != null) {
        //        XMLSerializer.Serialize<Class1>(actname + ".xml", cl);
        //    }
        //}
        public void Save(string filename) {
            var cl = acts.Find(x=>{
                return x.name.Equals(filename);
            });
            if (cl != null) {
                XMLSerializer.Serialize<Class1>(cl.name, cl);
            }
        }

        public void Load(List<string> filelist) {
            if (filelist.Count == 0) {
                filelist.Add("new.xml");
                filelist.Add("Trust.xml");
                //acts.Add(new Class1 { name = "new.xml", _items = new List<Item>() });
                //acts.Add(new Class1 { name = "Trust.xml", _items = new List<Item>() });
            } else if (!filelist.Contains("Trust.xml")) {
                filelist.Add("Trust.xml");
                //acts.Add(new Class1 { name = "Trust.xml", _items = new List<Item>() });
            } else {
                //var tmp = new List<string>();
                filelist.ForEach(x => {
                    Class1 cl;
                    try {
                        //cl = XMLSerializer.Deserialize<Class1>(x);
                        //cl = new Class1() { name = x };
                        //acts.Add(cl);
                    } catch (Exception) {
                        //tmp.Add(x);
                    }

                });
                //filelist.RemoveAll(x => {
                //    return tmp.Contains(x);
                //});
            }
        }
    }
}
