﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace WindowsFormsApplication1 {
    class RequestEventArgs : EventArgs {
        public HttpListenerRequest Request;
        public string Response;
    }
    delegate void RequestEventHandler(object sender, RequestEventArgs e);

    class HttpServer {
        public event RequestEventHandler RequestEvent;
        private HttpListener listener;
        private RequestEventArgs reqArgs;
        //public int Port {
        //}

        public void start() {
            string prefix = "http://*:8088/"; // 受け付けるURL
            HttpListener listener = new HttpListener();
            listener.Prefixes.Add(prefix); // プレフィックスの登録

            listener.Start();

            while (true) {
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest req = context.Request;
                HttpListenerResponse res = context.Response;


                Console.WriteLine(req.RawUrl);

                string resString = "tttt";
                if (RequestEvent != null) {
                    reqArgs = new RequestEventArgs { Request = req };
                    RequestEvent(this, reqArgs);
                    resString = reqArgs.Response; 
                }                
                Encoding enc = Encoding.UTF8;
                byte[] buffer = enc.GetBytes(resString);
                res.OutputStream.Write(buffer, 0, buffer.Length);
                res.Close();
            }
        }
    }
}
