﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    //public enum UpDateType
    //{
    //    Time,
    //    Title,
    //    Text
    //}
    public class ChangeItemEventArgs : EventArgs
    {
        public ChangeType type;
        public DateTime date;
        public string title;
        public string text;
        public List<Item> items;
        public TreeNode node;
    }
    public delegate void ChangeItemEventHandler(object sender, ChangeItemEventArgs e);

    public class Item{
        public DateTime date;
        public string title;
        public string text;
    }

    public enum ChangeType
    {
        Add,
        //Adds,
        Delete,
        //Deletes,
        Update
    }
    public class ChangeEventArgs : EventArgs
    {
        public ChangeType type;
        public string name;
    }
    public delegate void ChangeEventHandler(object sender, ChangeEventArgs e);
    public class Class1
    {
        //public event ChangeItemEventHandler ChangeItemItemEvent;
        public string name;
        public List<Item> _items;

        //public Class1(string name)
        //{
        //    this.name = name;
        //    items = new List<Item>();
        //}
        public Class1()
        {
            _items = new List<Item>();
        }

        //public void Add(Item item)
        //{
        //    _items.Add(item);
        //    if (ChangeItemItemEvent != null)
        //    {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Add, items = new List<Item>() { item } });
        //    }
        //}

        //public void Add(List<Item> items) {
        //    this._items.AddRange(items);
        //    if (ChangeItemItemEvent != null) {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Add, items = items });
        //    }
        //}

        //public void Delete(Item item)
        //{
        //    _items.Remove(item);
        //    if (ChangeItemItemEvent != null)
        //    {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Delete, items = new List<Item>() { item } });
        //    }
        //}

        //public void Delete(List<Item> items) {
        //    _items.RemoveAll(x=>{
        //        return items.Contains(x);
        //    });
        //    if (ChangeItemItemEvent != null) {
        //        ChangeItemItemEvent(this, new ChangeItemEventArgs { type = ChangeType.Delete, items = items });
        //    }
        //}
    }

    class manager
    {
        public event ChangeEventHandler ChangeEvent;
        //public Dictionary<string, Class1> atc;
        public List<Class1> acts;

        public manager()
        {
            acts = new List<Class1>();
        }

        //public Class1 getClass(string name)
        //{
        //    return acts.Find((x) => { return x.name.Equals(name); });
        //}

        public void Add(string name, Class1 class1)
        {
            if (acts.Find((x) => { if (x.name == null) return false; return x.name.Equals(name); }) == null)
            {
                class1.name = name;
                acts.Add(class1);
                if (ChangeEvent != null)
                {
                    ChangeEvent(class1, new ChangeEventArgs { name = name, type = ChangeType.Add });
                }
            }
            else
            {

            }
        }

        public void Add(string name)
        {
            if (acts.Find((x) => { return x.name.Equals(name); }) == null)
            {
                var act = new Class1 { name = name, _items = new List<Item>() };
                acts.Add(act);
                if (ChangeEvent != null)
                {
                    ChangeEvent(act, new ChangeEventArgs { name = name, type = ChangeType.Add });
                }
            }
        }

        public void Delete(string name)
        {
            var act = acts.Find((x) => { return x.name.Equals(name); });
            if (act != null)
            {
                acts.Remove(act);
                if (ChangeEvent != null)
                {
                    ChangeEvent(act, new ChangeEventArgs { name = name, type = ChangeType.Delete });
                }
            }
        }

        //public void Save() {
        //}
        //public void Save(string actname) {
        //    var cl = acts.Find(x=>{
        //        return x.name.Equals(actname);
        //    });
        //    if (cl != null) {
        //        XMLSerializer.Serialize<Class1>(actname + ".xml", cl);
        //    }
        //}

        public void Load(List<string> clist) {
            if (clist.Count == 0) {
                clist.Add("new");
                clist.Add("Trust");
                acts.Add(new Class1 { name = "new", _items = new List<Item>() });
                acts.Add(new Class1 { name = "Trust", _items = new List<Item>() });
            } else if (!clist.Contains("Trust")) {
                clist.Add("Trust");
                acts.Add(new Class1 { name = "Trust", _items = new List<Item>() });
            } else {
                var tmp = new List<string>();
                clist.ForEach(x => {
                    Class1 cl;
                    try {
                        //cl = XMLSerializer.Deserialize<Class1>(x + ".xml");
                        cl = new Class1() { name = x };
                        acts.Add(cl);
                    } catch (Exception) {
                        tmp.Add(x);
                    }

                });
                clist.RemoveAll(x => {
                    return tmp.Contains(x);
                });
            }
        }
    }
}
