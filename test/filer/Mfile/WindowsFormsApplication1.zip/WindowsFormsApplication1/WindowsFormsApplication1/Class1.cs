﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{

    //public enum UpDateType
    //{
    //    Time,
    //    Title,
    //    Text
    //}
    public class ChangeItemEventArgs : EventArgs
    {
        public ChangeType type;
        public DateTime date;
        public string title;
        public string text;
    }
    delegate void ChangeItemEventHandler(object sender, ChangeItemEventArgs e);

    class Item{
        public DateTime date;
        public string title;
        public string text;
    }

    public enum ChangeType
    {
        Add,
        Delete,
        Update
    }
    public class ChangeEventArgs : EventArgs
    {
        public ChangeType type;
        public string name;
    }
    delegate void ChangeEventHandler(object sender, ChangeEventArgs e);
    class Class1
    {
        public event ChangeItemEventHandler ChangeItemItemEvent;
        public string name;
        public List<Item> items;

        //public Class1(string name)
        //{
        //    this.name = name;
        //    items = new List<Item>();
        //}
        public Class1()
        {
            items = new List<Item>();
        }

        public void Add(Item item)
        {
            items.Add(item);
            if (ChangeItemItemEvent != null)
            {
                ChangeItemItemEvent(item, new ChangeItemEventArgs { type= ChangeType.Add });
            }
        }

        public void Delete(Item item)
        {
            items.Remove(item);
            if (ChangeItemItemEvent != null)
            {
                ChangeItemItemEvent(item, new ChangeItemEventArgs { type = ChangeType.Delete });
            }
        }
    }

    class manager
    {
        public event ChangeEventHandler ChangeEvent;
        //public Dictionary<string, Class1> atc;
        public List<Class1> acts;

        public manager()
        {
            acts = new List<Class1>();
        }

        public Class1 getClass(string name)
        {
            return acts.Find((x) => { return x.name.Equals(name); });
        }

        public void Add(string name, Class1 class1)
        {
            if (acts.Find((x) => { if (x.name == null) return false; return x.name.Equals(name); }) == null)
            {
                class1.name = name;
                acts.Add(class1);
                if (ChangeEvent != null)
                {
                    ChangeEvent(class1, new ChangeEventArgs { name = name, type = ChangeType.Add });
                }
            }
            else
            {

            }
        }

        public void Add(string name)
        {
            //if (!atc.ContainsKey(name))
            //{
            //    atc.Add(name, new Class1 { name=name, items=new List<Item>() });
            //    if (ChangeEvent != null)
            //    {
            //        ChangeEvent(atc[name], new ChangeEventArgs { name=name, type = ChangeType.Add });
            //    }
            //}

            if (acts.Find((x) => { return x.name.Equals(name); }) == null)
            {
                var act = new Class1 { name = name, items = new List<Item>() };
                acts.Add(act);
                if (ChangeEvent != null)
                {
                    ChangeEvent(act, new ChangeEventArgs { name = name, type = ChangeType.Add });
                }
            }
        }

        public void Delete(string name)
        {
            //if (atc.ContainsKey(name))
            //{
            //    var ac = atc[name];
            //    atc.Remove(name);
            //    if (ChangeEvent != null)
            //    {
            //        ChangeEvent(ac, new ChangeEventArgs { name = name, type = ChangeType.Delete });
            //    }
            //}
            var act = acts.Find((x) => { return x.name.Equals(name); });
            if (act != null)
            {
                acts.Remove(act);
                if (ChangeEvent != null)
                {
                    ChangeEvent(act, new ChangeEventArgs { name = name, type = ChangeType.Delete });
                }
            }
        }
    }
}
