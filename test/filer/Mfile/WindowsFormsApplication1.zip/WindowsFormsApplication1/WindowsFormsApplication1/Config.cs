﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sgry.Azuki;
using System.Drawing;
using System.Xml.Serialization;

namespace WindowsFormsApplication1 {
    public class EditorColor
    {
        public CharClass cc { get; set; }
        public string backcolor { get; set; }
        public string forecolor { get; set; }

        [XmlIgnore]
        public Color BackColor
        {
            get { return ColorTranslator.FromHtml(backcolor); }
            set
            {
                backcolor = ColorTranslator.ToHtml(value);
            }
        }

        [XmlIgnore]
        public Color ForeColor
        {
            get { return ColorTranslator.FromHtml(forecolor); }
            set
            {
                forecolor = ColorTranslator.ToHtml(value);
            }
        }

    }

    public class EditorConfig {
        public List<EditorColor> colors { get; set; }
        public bool ShowTab { get; set; }

        [XmlIgnore]
        public List<CharClass> ccs;

        public EditorConfig() {
            colors = new List<EditorColor>();
            ccs = new List<CharClass> {
                CharClass.Normal, CharClass.Value, CharClass.Comment, 
                CharClass.Keyword,  CharClass.Keyword2, CharClass.Keyword3,
                CharClass.String, CharClass.DocComment
            };
        }
    }
    public class Config {
        public EditorConfig editorconfig { get; set; }
        public List<string> FileList { get; set; }

        public Config() {
            FileList = new List<string>();
            editorconfig = new EditorConfig();
            //colors.Add(new EditorColor() { cc = CharClass.Normal, BackColor = Color.Red, ForeColor = Color.Black });
        }

        public void setDefault(Sgry.Azuki.WinForms.AzukiControl editor) {

            editorconfig.ccs.ForEach(x => {
                Color f,b;
                editor.ColorScheme.GetColor(x, out f, out b);
                editorconfig.colors.Add(new EditorColor() { cc = x, ForeColor = f, BackColor = b });
            });
            
        }
    }
}
