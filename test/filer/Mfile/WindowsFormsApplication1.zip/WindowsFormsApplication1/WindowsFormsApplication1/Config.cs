﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1 {
    public class Config {
        public List<string> FileList { get; set; }

        public Config() {
            FileList = new List<string>();
        }
    }
}
