﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sgry.Azuki;
using System.Drawing;
using System.Xml.Serialization;

namespace WindowsFormsApplication1 {
    public class EdtorColor
    {
        public CharClass cc;
        public string backcolor { get; set; }
        public string forecolor { get; set; }

        [XmlIgnore]
        public Color BackColor
        {
            get { return ColorTranslator.FromHtml(backcolor); }
            set
            {
                backcolor = ColorTranslator.ToHtml(value);
            }
        }

        [XmlIgnore]
        public Color ForeColor
        {
            get { return ColorTranslator.FromHtml(forecolor); }
            set
            {
                forecolor = ColorTranslator.ToHtml(value);
            }
        }

    }
    public class Config {
        public List<string> FileList { get; set; }

        public Config() {
            FileList = new List<string>();
        }
    }
}
