﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sgry.Azuki;
using System.Drawing;
using System.Xml.Serialization;
using Sgry.Azuki.WinForms;

namespace WindowsFormsApplication1 {
    public class EditorColor
    {
        public CharClass cc { get; set; }
        public string forecolor { get; set; }
        public string backcolor { get; set; }

        [XmlIgnore]
        public Color ForeColor
        {
            get { return ColorTranslator.FromHtml(forecolor); }
            set
            {
                forecolor = ColorTranslator.ToHtml(value);
            }
        }

        [XmlIgnore]
        public Color BackColor
        {
            get { return ColorTranslator.FromHtml(backcolor); }
            set
            {
                backcolor = ColorTranslator.ToHtml(value);
            }
        }
    }

    public class Enclosur{
        public string start { get; set; }
        public string end { get; set; }
        public CharClass cc { get; set; }
        public Enclosur() { }
    }
    public class SingleLine
    {
        public string start { get; set; }
        public CharClass cc { get; set; }
        public SingleLine() { }
    }

    public class EditorConfig {
        public List<EditorColor> colors { get; set; }
        public List<Enclosur> enclosurs { get; set; }
        public List<SingleLine> singleLines { get; set; }

        public string FontName { get; set; }
        public float FontSize { get; set; }

        public bool IsWrap { get; set; }
        public bool DrawTab { get; set; }
        public bool DrawSpace { get; set; }
        public bool DrawFullWidthSpace { get; set; }
        public bool DrawEOF { get; set; }
        public bool DrawEOL { get; set; }
        public bool DrawLineNumber { get; set; }


        public ColorScheme getColorScheme() {
            ColorScheme c = new ColorScheme();
            colors.ForEach(x => {
                c.SetColor(x.cc, x.ForeColor, x.BackColor);
            });
            c.WhiteSpaceColor = Color.Red;
            return c;
        }

        public EditorConfig() {
            colors = new List<EditorColor>();
            enclosurs = new List<Enclosur>();
            singleLines = new List<SingleLine>(); 
        }
        public void setDefault() {
            enclosurs.Add(new Enclosur() { cc= CharClass.Comment, start="/*", end="*/" });
            singleLines.Add(new SingleLine() { cc = CharClass.Comment, start = "//" });
            singleLines.Add(new SingleLine() { cc = CharClass.String, start = ">" });

            IsWrap = false;
            DrawTab = false;
            DrawSpace = false;
            DrawFullWidthSpace = true;
            DrawEOF = true;
            DrawEOL = true;
            DrawLineNumber = true;
        }
    }

    public class Symbols{
        public string symbol;
        public string value;
        public Symbols(){}
    }

    public class Config {

        public EditorConfig editorconfig { get; set; }
        public List<string> FileList { get; set; }
        public string ListHeaderPattern { get; set; }
        public string LinkPattern { get; set; }
        public string DatePattern { get; set; }

        public Size ThumbnailSize { get; set; }

        public string NewFileName { get; set; }
        public string TrustFileName { get; set; }
        public int DateTimeColumnWidth { get; set; }

        public List<Symbols> symbols { get; set; }

        public Config() {
            FileList = new List<string>();
            editorconfig = new EditorConfig();
            symbols = new List<Symbols>();
            //colors.Add(new EditorColor() { cc = CharClass.Normal, BackColor = Color.Red, ForeColor = Color.Black });
        }

        public string makeListHeader(Item item) {
            return ListHeaderPattern.Replace("%id%", item.id.ToString()).Replace("%date%", item.date.ToString(DatePattern));
        }
        public string makeLink(Item item) {
            return LinkPattern.Replace("%id%", item.id.ToString()).Replace("%title%", item.title).Replace("%date%", item.date.ToString(DatePattern));
        }

        public void setDefault() {
            
            var cs = ColorScheme.Default;
            foreach (CharClass cc in Enum.GetValues(typeof(CharClass)))
            {
                //Console.WriteLine((int)cc + ", " + cc.ToString());
                 Color f,b;
                 cs.GetColor(cc, out f, out b);
                 editorconfig.colors.Add(new EditorColor() { cc = cc, ForeColor = f, BackColor = b });
            }
            editorconfig.setDefault();

            ListHeaderPattern = "========>>>%id% %date%";
            LinkPattern = "[>>>%id% %title% %date%]";
            DatePattern = "yyyy/MM/dd hh:mmm";

            ThumbnailSize = new Size(100, 80);

            NewFileName = "File.xml";
            TrustFileName = "Trust.xml";
            DateTimeColumnWidth = 150;

            AzukiControl editor = new AzukiControl();
            var fi = editor.FontInfo;
            this.editorconfig.FontName = fi.Name;
            this.editorconfig.FontSize = fi.Size;

            editor.Dispose();
        }
    }
}
