﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string trustfile = "Trust.xml";
        Sgry.Azuki.WinForms.AzukiControl editor, subEditor;

        Config config;
        manager m;
        Dictionary<string, TabControl> tabcontrols = new Dictionary<string, TabControl>();

        public Form1()
        {
            InitializeComponent();

            ConfigLoad();

            editor = new Sgry.Azuki.WinForms.AzukiControl();
            editor.Dock = DockStyle.Fill;
            MainEditorPanel.Controls.Add(editor);
            editor.Document.MarksUri = true;
            editor.MouseClick += (s, e) => {
                var lineindex = editor.Document.GetLineIndexFromCharIndex(editor.CaretIndex);
                string line = editor.Document.GetLineContent(lineindex);
                var match = Regex.Match(line, @"((\sfile|^file):\/\/\S*).*");
                if (match.Success) {
                    var st = editor.Document.GetLineHeadIndex(lineindex) + match.Groups[1].Index;
                    var end = st + match.Groups[1].Length;
                    if (editor.CaretIndex > st && editor.CaretIndex < end) {
                        Debug.WriteLine(match.Groups[1]);
                    }
                }
                //Debug.WriteLine(line);
            };
            editor.TextChanged += (s, e) => {
                
            };
            
            editor.LostFocus += (s, e) => {
                if (editor.Document.IsDirty) {
                    var tb = getTabControl(listView1.SelectedItems[0].Text); 
                    if (tb.SelectedTab.Controls[0] is ListViewEx)
                    {
                        var lv = tb.SelectedTab.Controls[0] as ListViewEx;
                        if(lv.SelectedIndices.Count>0){
                            var item = lv.DataItems[lv.SelectedIndices[0]];
                            item.text = editor.Text;
                        }
                    }
                        //m.Save(item.Text);
                    SaveFile(listView1.SelectedItems[0].Text);
                   // }
                }
            };

            TitleTextBox.LostFocus += (s, e) => {
                var tb = getTabControl(listView1.SelectedItems[0].Text);
                    //(editor.Tag as Item).text = editor.Text;
                Item item=null;
                    if (tb.SelectedTab.Controls[0] is ListViewEx) {
                        var lv = tb.SelectedTab.Controls[0] as ListViewEx;
                        item = lv.DataItems[lv.SelectedIndices[0]];
                        if (item != null && !TitleTextBox.Text.Equals(item.title)) {
                            lv.Refresh();
                            SaveFile(listView1.SelectedItems[0].Text);
                        }
                    }
            };

            toolStripComboBox1.KeyDown += (s, e) => {
                ToolStripComboBox cb = s as ToolStripComboBox;
                if (e.KeyData == Keys.Return) {
                    createListView(listView1.SelectedItems[0].Text, cb.Text);
                }
            };

            this.FormClosing += (s, e) => {
                ConfigSave();
            };

            bool selnon = false;
            listView1.MouseDown += (s, e) => {
                if (listView1.GetItemAt(e.X, e.Y) == null) {
                    selnon = true;
                } else {
                    selnon = false;
                }
            };


            listView1.BeforeLabelEdit += (s, e) => {

            };
            listView1.AfterLabelEdit += (s, e) => {
                if(File.Exists(e.Label)){
                    e.CancelEdit = true;
                }else{
                    RenameFile(listView1.Items[e.Item].Text, e.Label);
                }
            };
            
            ListViewItem selitem = null;
            bool res= false;
            listView1.ItemSelectionChanged += (s, e) =>
            {
                if (listView1.SelectedItems.Count > 0 ) {
                    if (res) {
                        res = false;
                        return;
                    }
                    selitem = e.Item;

                    var filename = listView1.SelectedItems[0].Text;
                    Item item=null;
                    if (!tabcontrols.ContainsKey(filename)) {
                        var tb = getTabControl(filename);
                        var cl = m.getClass(filename);
                        var lv = getAllListView(tb);
                        lv.DataItems = cl._items;
     
                        tb.BringToFront();
                        if (lv.DataItems.Count>0) {
                            lv.Items[0].Selected = true;
                            item = lv.DataItems[0];
                        }
                    } else {
                        var tb = getTabControl(filename);
                        var lv = getAllListView(tb);
                        tb.BringToFront();
                        if (lv.DataItems.Count > 0) {
                            lv.Items[0].Selected = true;
                            item = lv.DataItems[0];
                        }
                    }
                    SetMainEditorText(item);
                } else {
                    if (selitem != null && !res && selnon) {
                        res = true;
                        selitem.Selected = true;
                    }
                }
            };

            if (listView1.Items.Count > 0)
            {
                listView1.Items[0].Selected = true;
            }

            CreateFileToolStripButton.Click += (s, e) => {
                CreateFile();
            };

            CreateItemToolStripButton.Click += (s, e) =>
            {
                CreateItem();
            };

            DeleteItemToolStripButton.Click += (s, e) => {
                DeleteItem();
            };

            ListItemToolStripButton.Click += (s, e) =>
            {
                var tb = getTabControl(listView1.SelectedItems[0].Text);
                if (tb.SelectedTab.Controls[0] is ListViewEx)
                {

                }
                //var tv = getTreeView(tb);
                //var item = tv.SelectedNode.Tag as Item;
                //if (!TitleTextBox.Text.Equals(item.title)) {
                //    item.title = TitleTextBox.Text;
                //    //(editor.Tag as Item).text = editor.Text;
                    
                //    if (tb.SelectedTab.Controls[0] is ListViewEx)
                //    {                
            };

            toolStripMenuItem1.Click += (s, e) =>
            {
                //var newcl = new Class1();
                ////newcl.ChangeItemItemEvent += (s2, e2) =>
                ////{
                ////    if (e2.type == ChangeType.Add)
                ////    {
                ////        //listview.DataItems = newcl.items;
                ////        //listview.Refresh();
                ////        listview.AddItem(s2 as Item);
                ////    }
                ////};
                //newcl.ChangeItemItemEvent += cl_ChangeItemItemEvent;
                //newcl.Add(new Item { title = "title1", text = "test1", date = DateTime.Now });
                //m.Add("new5", newcl);
            };


            listView1.ContextMenuStrip = FileListViewContextMenuStrip;

            subEditor = new Sgry.Azuki.WinForms.AzukiControl();
            subEditor.Document.MarksUri = true;
            subEditor.Dock= DockStyle.Fill;
            subEditor.Document.IsReadOnly = true;
            SubEditorTabPage.Controls.Add(subEditor);

            CreateLinkItemToolStripMenuItem.Click += (s, e) => {
                var name =listView1.SelectedItems[0].Text;
                var fromlv = getSelectedListView(getTabControl(name));
                var item = m.createItem();
                var link = makeLink(fromlv.DataItems[fromlv.SelectedIndices[0]]);
                item.text = link;
                m.getClass(name)._items.Add(item);
                fromlv.AddItem(item);
            };


            m = new manager();
            m.Load(config.FileList);

            listView1.Items[0].Selected = true;
            var ff = DateTime.Now.ToString("yyyy/MM/dd hh:mmm:ss:fff").Replace(" ", "%02");


        }

        private string makeLink(Item item) {
            return String.Format("file://{0}/{1}:{2}", item.id, item.title, item.date.ToString("yyyy/MM/dd_hh:mmm"));
        }

        private void SaveFile(string name) {
            m.Save(name);
        }

        private ListViewEx getSelectedListView(TabControl tb) {

            return tb.SelectedTab.Controls[0] as ListViewEx;
        }

        private ListViewEx getAllListView(TabControl tb) {
            for (int i = 0; i < tb.TabPages.Count; i++) {
                ListViewEx lv = tb.TabPages[i].Controls[0] as ListViewEx;
                if (lv.Name.Equals("all")) {
                    return lv;
                }
            }
            return null;
        }
        //private ListViewEx getSearchListView() {
        //}

        private void addSubEditor(Item item) {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("//====================================//");
            sb.AppendLine("file://sub/" + item.title + "/" + item.date.ToString("yyyy/MM/dd%2hh:mmm:ss:fff"));
            sb.AppendLine(item.title + " " + item.date.ToString());
            sb.AppendLine(item.text);

            subEditor.Text = sb.AppendLine(subEditor.Text).ToString();
        }
        private void addSubEditor(List<Item> items) {

        }

        private void createListView(string name, string word) {
            var tb = getTabControl(name);
            tb.BringToFront();

            var tbp = new TabPage();
            tbp.Text = word;
            var lv = new ListViewEx();
            lv.ContextMenuStrip = ListViewContextMenuStrip;
            lv.Dock= DockStyle.Fill;
            lv.Margin = new Padding(0);
            lv.ItemSelectionChanged += (s, e) => {

                if (e.IsSelected) {
                    var item = lv.DataItems[e.ItemIndex];
                    SetMainEditorText(item, false);
                }
            };

            Regex rg = new Regex(word, RegexOptions.IgnoreCase| RegexOptions.Compiled);
            var lists = m.getClass(name)._items.FindAll(x => {
                return rg.IsMatch(x.title) || rg.IsMatch(x.text);
            });
            
            lv.ClearItem();
            lv.DataItems = lists;
            tbp.Controls.Add(lv);
            tb.TabPages.Add(tbp);
            tb.SelectedTab = tbp;
        }

        private TabControl getTabControl(string name) {
            if (!tabcontrols.ContainsKey(name)) {
                TabControl tb = new TabControl();
                tb.Dock = DockStyle.Fill;
                tb.Selected += (s,e) =>
                {
                    if (tb.SelectedTab.Controls[0] is ListView)
                    {
                        var lv = tb.SelectedTab.Controls[0] as ListView;
                        if (lv.SelectedIndices.Count == 0 && lv.Items.Count>0)
                        {
                            lv.Items[0].Selected = true;
                        }
                    }
                };

                var lvex = new ListViewEx();
                lvex.ContextMenuStrip = ListViewContextMenuStrip;
                lvex.AllowDrop = true;
                lvex.Dock = DockStyle.Fill;
                lvex.HideSelection = false;
                lvex.Name = "all";
                lvex.ItemSelectionChanged += (s, e) => {
                    if (e.IsSelected) {
                        SetMainEditorText(lvex.DataItems[e.ItemIndex]);
                    }
                };
                
                var tbp = new TabPage();
                tbp.Name="all";
                tbp.Controls.Add(lvex);
                tb.TabPages.Add(tbp);
                tb.SendToBack();
                TabPanel.Controls.Add(tb);

                tabcontrols.Add(name, tb);

            }
            return tabcontrols[name];
        }

        //void tv_AfterSelect(object sender, TreeViewEventArgs e) {
        //    if (e.Node.Tag != null) {
        //        var item = e.Node.Tag as Item;
        //        if (item != null) {
        //            SetMainEditorText(item);
        //        }
        //    }
        //}

        private void SetMainEditorText(Item item)
        {
            SetMainEditorText(item, false);
        }

        private void SetMainEditorText(Item item, bool isreadonly) {
            if (item == null)
            {
                TitleTextBox.Text = "";
                DateTimeLabel.Text = "";
                editor.Text = "";
                TitleTextBox.Enabled = false;
                editor.Document.IsReadOnly = true;
            }
            else
            {

                TitleTextBox.Text = item.title;
                DateTimeLabel.Text = item.date.ToString();

                editor.Text = item.text;
                editor.Document.IsDirty = false;
                //editor.Tag = item;

                TitleTextBox.Enabled = !isreadonly;
                editor.Document.IsReadOnly = isreadonly;
            }

        }

        private void ConfigLoad() {
            try {
                config = XMLSerializer.Deserialize<Config>("config.xml");
            } catch (Exception) {

                config = new Config();
            }

            if (config.FileList.Count == 0) {
                config.FileList.Add("new.xml");
                config.FileList.Add(trustfile);
            } else if (!config.FileList.Contains(trustfile)) {
                config.FileList.Add(trustfile);
            } 

            config.FileList.ForEach(x => {
                listView1.Items.Add(x);
            });
        }
        private void ConfigSave() {

            XMLSerializer.Serialize<Config>("config.xml", config);

            var items = listView1.Items;
            for (int i = 0; i < items.Count; i++) {
                var text = items[i].Text;
                //m.Save(text);
                //if (NodeCashe.ContainsKey(text)) {
                    //SaveTree(NodeCashe[text], text + ".tree.xml");

                //    SerializeTreeView(NodeCashe[text], text + ".xml");
                //}
            }

            
        }

        public void CreateFile() {
            var name = "new.xml";
            var cnt=1;

            while (!File.Exists(name)) {
                name = "new" + cnt.ToString() + ".xml";
            }

            listView1.Items.Insert(0, name);
            listView1.Items[0].Selected = true;
        }

        public void DeleteFile() {
            
        }

        public void RenameFile(string from, string to) {
            try {
                File.Move(from, to);
                if (tabcontrols.ContainsKey(from)) {
                    var tb = tabcontrols[from];
                    tabcontrols.Remove(from);
                    tabcontrols.Add(to, tb);
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        public void CreateItem() {
            if (!EnableEdit) return;

            if (listView1.SelectedItems.Count > 0) {
                var name = listView1.SelectedItems[0].Text;
                var tb = getTabControl(name);
                var sellv = getSelectedListView(tb);
                var item = m.createItem();
                m.getClass(name).Add(item);
                if(sellv.Name.Equals("all")){
                    sellv.AddItem(item);
                }else{
                    var lv = getAllListView(tb);
                    //var item = m.createItem();
                    lv.AddItem(item);
                    sellv.AddItem(item);
                }
                SaveFile(name);   
            }
        }

        //public void MoveIem(string from, string to) {
        //    if (!EnableEdit) return;
        //}

        public void DeleteItem() {
            if (!EnableEdit) return;

            var name = listView1.SelectedItems[0].Text;
            var fromtb = getTabControl(name);
            var lv = getSelectedListView(fromtb);
            var item = lv.DataItems[lv.SelectedIndices[0]];

            for (int i = 0; i < fromtb.TabPages.Count; i++)
            {
                var tbp = fromtb.TabPages[i];
                if (tbp.Controls[0] is ListViewEx)
                {
                    var lvex = tbp.Controls[0] as ListViewEx;
                    lvex.DeleteItem(item);
                }
            }
            SaveFile(name);

            if (!name.Equals(trustfile)) {
                lv = getAllListView(getTabControl(trustfile));
                lv.AddItem(item);
                SaveFile(trustfile);
            }
        }

        //private void getItems(ref List<Item> items, TreeNode node) {
        //    items.Add(node.Tag as Item);
        //    for (int i = 0; i < node.Nodes.Count; i++) {
        //        getItems(ref items, node.Nodes[i]);
        //    }
        //}
        //private void getNode(TreeNode node, Item item, out TreeNode res)
        //{
        //    res = null;
        //    if ((node.Tag as Item) == item)
        //    {
        //        res = node;
        //        return;
        //    }
        //    for (int i = 0; i < node.Nodes.Count; i++)
        //    {
        //        getNode(node.Nodes[i], item, out res);
        //    }
        //}


        private bool editenable = true;
        private bool EnableEdit {
            get { return editenable; }
            set {
                editenable = value;
                if (editenable) {

                } else {

                }
            }
        }


        private void listView1_DragOver(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(typeof(ListViewItem))) {
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                    //何も押されていなければMove
                    e.Effect = DragDropEffects.Move;
            } else {
                //TreeNodeでなければ受け入れない
                e.Effect = DragDropEffects.None;
            }


            //マウス下のNodeを選択する
            if (e.Effect != DragDropEffects.None) {
                ListView lv = (ListView)sender;
                //マウスのあるNodeを取得する
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                //ドラッグされているNodeを取得する
                ListViewItem source = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                //マウス下のNodeがドロップ先として適切か調べる
                if (target != null && !target.Text.Equals(lv.SelectedItems[0].Text)) {
                } else
                    e.Effect = DragDropEffects.None;
            }
        }

        private void listView1_DragDrop(object sender, DragEventArgs e) {
            //ドロップされたデータがTreeNodeか調べる
            if (e.Data.GetDataPresent(typeof(ListViewItem))) {
                ListView lv = (ListView)sender;
                //ドロップされたデータ(TreeNode)を取得
                ListViewItem source = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                //ドロップ先のTreeNodeを取得する
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                //マウス下のNodeがドロップ先として適切か調べる
                if (target != null) {
                    ////ドロップされたNodeのコピーを作成
                    //TreeNode cln = (TreeNode)source.Clone();
                    ////TreeNode cln = (TreeNode)source;
                    //var tv = getTreeView(getTabControl(target.Text));
                    //tv.Nodes.Add(cln);
                    //SerializeTreeView(tv.Nodes.Cast<TreeNode>().ToArray(), target.Text);

                    //var fromtb = getTabControl(lv.SelectedItems[0].Text);
                    //tv = getTreeView(fromtb);
                    //tv.Nodes.Remove((TreeNode)source);
                    //var list = new List<Item>();
                    //getItems(ref list, (TreeNode)source);
                    //for (int i = 0; i < fromtb.TabPages.Count; i++)
                    //{
                    //    var tbp = fromtb.TabPages[i];
                    //    if (tbp.Controls[0] is ListViewEx)
                    //    {
                    //        var lvex = tbp.Controls[0] as ListViewEx;
                    //        lvex.DeleteItem(list);
                    //    }
                    //}

                    //SerializeTreeView(tv.Nodes.Cast<TreeNode>().ToArray(), lv.SelectedItems[0].Text);

                } else
                    e.Effect = DragDropEffects.None;
            } else
                e.Effect = DragDropEffects.None;
        }
       
    }
}
