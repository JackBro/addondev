﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string trustfile = "Trust.xml";
        Sgry.Azuki.WinForms.AzukiControl editor;
        Config config;
        //manager m;
        Dictionary<string, TabControl> tabcontrols = new Dictionary<string, TabControl>();
        public Form1()
        {
            InitializeComponent();

            editor = new Sgry.Azuki.WinForms.AzukiControl();
            editor.Dock = DockStyle.Fill;
            MainEditorPanel.Controls.Add(editor);
            editor.Document.MarksUri = true;
            editor.MouseClick += (s, e) => {
                var lineindex = editor.Document.GetLineIndexFromCharIndex(editor.CaretIndex);
                string line = editor.Document.GetLineContent(lineindex);
                var match = Regex.Match(line, @"(\sfile:\/\/\S*).*");
                if (match.Success) {
                    var st = editor.Document.GetLineHeadIndex(lineindex) + match.Groups[1].Index;
                    var end = st + match.Groups[1].Length;
                    if (editor.CaretIndex > st && editor.CaretIndex < end) {
                        Debug.WriteLine(match.Groups[1]);
                    }
                }
                //Debug.WriteLine(line);
            };
            editor.TextChanged += (s, e) => {
                
            };
            editor.LostFocus += (s, e) => {
                if (editor.Document.IsDirty) {
                    if (listView1.SelectedItems.Count == 1) {
                        var item = listView1.SelectedItems[0];
                        //m.Save(item.Text);
                    }
                }
            };

            TitleTextBox.LostFocus += (s, e) => {
                var tv = getTreeView(getTabControl(listView1.SelectedItems[0].Text));
                var item = tv.SelectedNode.Tag as Item;
                if (!TitleTextBox.Text.Equals(item.title)) {
                    item.title = TitleTextBox.Text;
                    tv.SelectedNode.Text = item.title;
                }
            };

            toolStripComboBox1.KeyDown += (s, e) => {
                ToolStripComboBox cb = s as ToolStripComboBox;
                if (e.KeyData == Keys.Return) {
                    createListView(listView1.SelectedItems[0].Text, cb.Text);
                }
            };


            this.FormClosing += (s, e) => {

                ConfigSave();
            };



            bool selnon = false;
            listView1.MouseDown += (s, e) => {
                if (listView1.GetItemAt(e.X, e.Y) == null) {
                    selnon = true;
                } else {
                    selnon = false;
                }
            };

            listView1.ItemActivate += (s, e) => {
                var i = 0;
            };

            listView1.BeforeLabelEdit += (s, e) => {

            };
            listView1.AfterLabelEdit += (s, e) => {
                if(File.Exists(e.Label)){
                    e.CancelEdit = true;
                }else{
                    RenameFile(listView1.Items[e.Item].Text, e.Label);
                }
            };
            
            ListViewItem selitem = null;
            bool res= false;
            listView1.ItemSelectionChanged += (s, e) =>
            {
                if (listView1.SelectedItems.Count > 0 ) {
                    if (res) {
                        res = false;
                        return;
                    }
                    selitem = e.Item;

                    var filename = listView1.SelectedItems[0].Text;
                    Item item;
                    if (!tabcontrols.ContainsKey(filename)) {
                        var tb = getTabControl(filename);
                        var tv = getTreeView(tb);
                        try {
                            var items = DeserializeTreeView(tv, filename);
                        } catch (Exception) {
                            
                            //throw;
                        }     
                        tb.BringToFront();
                        tv.ExpandAll();
                        if (tv.SelectedNode == null && tv.Nodes.Count > 0) {
                            tv.SelectedNode = tv.Nodes[0];
                        }
                        item = tv.SelectedNode.Tag as Item;
                    } else {
                        //tabcontrols[filename].BringToFront();
                        var tb = getTabControl(filename);
                        var tv = getTreeView(tb);
                        tb.BringToFront();
                        tv.ExpandAll();
                        if (tv.SelectedNode == null && tv.Nodes.Count>0) {
                            tv.SelectedNode = tv.Nodes[0];
                        }
                        item = tv.SelectedNode.Tag as Item;
                    }
                    SetMainEditorText(item);
                } else {
                    if (selitem != null && !res && selnon) {
                        res = true;
                        selitem.Selected = true;
                    }
                }
            };

            if (listView1.Items.Count > 0)
            {
                listView1.Items[0].Selected = true;
            }

            CreateFileToolStripButton.Click += (s, e) => {
                CreateFile();
            };

            CreateItemToolStripButton.Click += (s, e) =>
            {
                CreateItem();
            };

            DeleteItemToolStripButton.Click += (s, e) => {
            };

            toolStripMenuItem1.Click += (s, e) =>
            {
                //var newcl = new Class1();
                ////newcl.ChangeItemItemEvent += (s2, e2) =>
                ////{
                ////    if (e2.type == ChangeType.Add)
                ////    {
                ////        //listview.DataItems = newcl.items;
                ////        //listview.Refresh();
                ////        listview.AddItem(s2 as Item);
                ////    }
                ////};
                //newcl.ChangeItemItemEvent += cl_ChangeItemItemEvent;
                //newcl.Add(new Item { title = "title1", text = "test1", date = DateTime.Now });
                //m.Add("new5", newcl);
            };


            listView1.ContextMenuStrip = contextMenuStrip1;

            ConfigLoad();
        }

        private void createListView(string name, string word) {
            var tb = getTabControl(name);
            tb.BringToFront();

            var tbp = new TabPage();
            //tbp.Name = word;
            tbp.Text = word;
            var lv = new ListViewEx();
            lv.Dock= DockStyle.Fill;
            lv.Margin = new Padding(0);
            lv.ItemSelectionChanged += (s, e) => {

                if (e.IsSelected) {
                    var item = lv.DataItems[e.ItemIndex];
                    SetMainEditorText(item);
                }
            };

            var lists = new List<Item>();
            var nodes = getTreeView(tb).Nodes;
            for (int i = 0; i < nodes.Count; i++) {
                getNodes(ref lists, nodes[i]);
            }
            
            lv.ClearItem();
            lv.DataItems = lists;
            tbp.Controls.Add(lv);
            tb.TabPages.Add(tbp);
            tbp.Select();
        }

        private TabControl getTabControl(string name) {
            if (!tabcontrols.ContainsKey(name)) {
                TabControl tb = new TabControl();
                tb.Dock = DockStyle.Fill;

                TreeView tv = new TreeView();
                tv.AllowDrop = true;
                tv.Dock = DockStyle.Fill;
                tv.HideSelection = false;
                tv.Name = name;
                tv.AfterSelect += new TreeViewEventHandler(tv_AfterSelect);
                tv.BeforeCollapse += treeView1_BeforeCollapse;
                tv.ItemDrag += treeView1_ItemDrag;
                tv.DragOver += treeView1_DragOver;
                tv.DragDrop += treeView1_DragDrop;
                
                var tbp = new TabPage();
                tbp.Name="tree";
                tbp.Controls.Add(tv);
                tb.TabPages.Add(tbp);
                tb.SendToBack();
                TabPanel.Controls.Add(tb);

                tabcontrols.Add(name, tb);

            }
            return tabcontrols[name];
        }

        private TreeView getTreeView(TabControl tb) {
            return tb.TabPages["tree"].Controls[0] as TreeView;
        }

        void tv_AfterSelect(object sender, TreeViewEventArgs e) {
            if (e.Node.Tag != null) {
                var item = e.Node.Tag as Item;
                if (item != null) {
                    SetMainEditorText(item);
                }
            }
        }

        private void SetMainEditorText(Item item) {
            TitleTextBox.Text = item.title;
            DateTimeLabel.Text = item.date.ToString();

            editor.Text = item.text;
            editor.Document.IsDirty = false;
        }

        private void ConfigLoad() {
            try {
                config = XMLSerializer.Deserialize<Config>("config.xml");
            } catch (Exception) {

                config = new Config();
            }

            if (config.FileList.Count == 0) {
                config.FileList.Add("new.xml");
                config.FileList.Add(trustfile);
            } else if (!config.FileList.Contains(trustfile)) {
                config.FileList.Add(trustfile);
            } 

            config.FileList.ForEach(x => {
                listView1.Items.Add(x);
            });

            listView1.Items[0].Selected = true;
        }
        private void ConfigSave() {

            XMLSerializer.Serialize<Config>("config.xml", config);

            var items = listView1.Items;
            for (int i = 0; i < items.Count; i++) {
                var text = items[i].Text;
                //m.Save(text);
                //if (NodeCashe.ContainsKey(text)) {
                    //SaveTree(NodeCashe[text], text + ".tree.xml");

                //    SerializeTreeView(NodeCashe[text], text + ".xml");
                //}
            }

            
        }

        private void treeView1_BeforeCollapse(object sender, TreeViewCancelEventArgs e) {
            e.Cancel = true;
        }

        public void CreateFile() {
            var name = "new.xml";
            var cnt=1;

            while (!File.Exists(name)) {
                name = "new" + cnt.ToString() + ".xml";
            }

            listView1.Items.Insert(0, name);
            listView1.Items[0].Selected = true;
        }

        public void DeleteFile() {
            
        }

        public void RenameFile(string from, string to) {
            try {
                File.Move(from, to);
                if (tabcontrols.ContainsKey(from)) {
                    var tb = tabcontrols[from];
                    tabcontrols.Remove(from);
                    tabcontrols.Add(to, tb);
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        public void CreateItem() {
            if (!EnableEdit) return;

            if (listView1.SelectedItems.Count > 0) {
                var item = new Item { title = "new", text = "", date = DateTime.Now };
                var name = listView1.SelectedItems[0].Text;

                var node = new TreeNode(item.title);
                node.Text = item.title + " " + item.date.ToString();
                node.Tag = item;
                var tv = getTreeView(getTabControl(name));
                if (tv.SelectedNode == null) {
                    tv.Nodes.Insert(0, node);
                } else {
                    tv.SelectedNode.Nodes.Insert(0, node);
                    tv.SelectedNode.ExpandAll();
                }
                SaveTreeView(name);   
            }
        }

        //public void MoveIem(string from, string to) {
        //    if (!EnableEdit) return;

        //}

        public void DeleteItem() {
            if (!EnableEdit) return;
            var name = listView1.SelectedItems[0].Text;
            var tv = getTreeView(getTabControl(name));
            //var items = new List<Item>();
            var node = tv.SelectedNode;
            //getNodes(ref items, node);
            tv.Nodes.Remove(node);
            SerializeTreeView(tv.Nodes.Cast<TreeNode>().ToArray(), name);

            if (!name.Equals(trustfile)) {
                tv = getTreeView(getTabControl(trustfile));
                tv.Nodes.Insert(0, node);
                SerializeTreeView(tv.Nodes.Cast<TreeNode>().ToArray(), trustfile);  
            }
        }

        private void getNodes(ref List<Item> items, TreeNode node) {
            items.Add(node.Tag as Item);
            for (int i = 0; i < node.Nodes.Count; i++) {
                getNodes(ref items, node.Nodes[i]);
            }
        }

        private bool editenable = true;
        private bool EnableEdit {
            get { return editenable; }
            set {
                editenable = value;
                if (editenable) {

                } else {

                }
            }
        }

        public void SaveTreeView(string name){
            var filename = listView1.SelectedItems[0].Text;
            var tv = getTreeView(getTabControl(filename));
            SerializeTreeView(tv.Nodes.Cast<TreeNode>().ToArray(), name);
        }

        // Xml tag for node, e.g. 'node' in case of <node></node>

        private const string XmlNodeTag = "node";

        // Xml attributes for node e.g. <node text="Asia" tag="" 

        // imageindex="1"></node>

        private const string XmlNodeTextAtt = "text";
        private const string XmlNodeTagAtt = "tag";
        private const string XmlNodeImageIndexAtt = "imageindex";

		//System.IO.StringWriter s;
		//public void SerializeTreeView(TreeView treeView, string fileName) 
        public void SerializeTreeView(TreeNode[] nodes, string fileName) 
		{
			XmlTextWriter textWriter = new XmlTextWriter(fileName, System.Text.Encoding.ASCII);
			// writing the xml declaration tag
			textWriter.WriteStartDocument();
			//textWriter.WriteRaw("\r\n");
			// writing the main tag that encloses all node tags
			textWriter.WriteStartElement("TreeView");
			
			// save the nodes, recursive method
			//SaveNodes(treeView.Nodes, textWriter);
            SaveNodes(nodes, textWriter);
			
			textWriter.WriteEndElement();
					
			textWriter.Close();
		}

		 //private void SaveNodes(TreeNodeCollection nodesCollection, XmlTextWriter textWriter) {
         private void SaveNodes(TreeNode[] nodesCollection, XmlTextWriter textWriter) {
            for (int i = 0; i < nodesCollection.Count(); i++) {
                TreeNode node = nodesCollection[i];
                var item = node.Tag as Item;

                textWriter.WriteStartElement(XmlNodeTag);
                textWriter.WriteAttributeString(XmlNodeTextAtt, item.title);
                //textWriter.WriteAttributeString(
                //    XmlNodeImageIndexAtt, node.ImageIndex.ToString());
                //if (node.Tag != null)
                //    textWriter.WriteAttributeString(XmlNodeTagAtt,
                //                                node.Tag.ToString());
                // add other node properties to serialize here  
                
                //textWriter.WriteStartElement("item");
                
                textWriter.WriteStartElement("Item");
                //textWriter.WriteStartElement("date");
                textWriter.WriteElementString("date", item.date.ToString());
                textWriter.WriteElementString("title", item.title);
                textWriter.WriteElementString("text", item.text);
                textWriter.WriteEndElement();

                //XmlSerializer seri = new XmlSerializer(typeof(Item));
                //seri.Serialize(textWriter, item);
                //textWriter.WriteString("sample3");
                //textWriter.WriteEndElement();

                if (node.Nodes.Count > 0) {
                    SaveNodes(node.Nodes.Cast<TreeNode>().ToArray(), textWriter);
                }
                textWriter.WriteEndElement();
            }
        }		

		public List<Item> DeserializeTreeView(TreeView treeView, string fileName)
		{
            var items = new List<Item>();
			XmlTextReader reader = null;
			try
			{
                // disabling re-drawing of treeview till all nodes are added
				treeView.BeginUpdate();				
				reader =
					new XmlTextReader(fileName);

				TreeNode parentNode = null;
				
				while (reader.Read())
				{
					if (reader.NodeType == XmlNodeType.Element)
					{						
						if (reader.Name == XmlNodeTag)
						{
							TreeNode newNode = new TreeNode();
							bool isEmptyElement = reader.IsEmptyElement;

                            // loading node attributes
							int attributeCount = reader.AttributeCount;
							if (attributeCount > 0)
							{
								for (int i = 0; i < attributeCount; i++)
								{
									reader.MoveToAttribute(i);
									
									SetAttributeValue(newNode, reader.Name, reader.Value);
								}								
							}

                            // add new node to Parent Node or TreeView
                            if(parentNode != null)
                                parentNode.Nodes.Add(newNode);
                            else
                                treeView.Nodes.Add(newNode);

                            // making current node 'ParentNode' if its not empty
							if (!isEmptyElement)
							{
                                parentNode = newNode;
							}

														
						}
                        else if(reader.Name == "Item")	{
                        
                            if(!reader.IsEmptyElement){
                                var item = new Item();
                                //reader.Read();

                                while (item.date == null || item.title == null || item.text == null) {
                                    reader.Read();
                                    if (reader.Name == "date") {
                                        //var date = reader.ReadElementContentAsDateTime();
                                        var date = DateTime.Parse(reader.ReadElementString());
                                        item.date = date;// DateTime.Parse(date);
                                    }

                                    if (reader.Name == "title") {
                                        var title = reader.ReadElementString();
                                        item.title = title;
                                    }

                                    if (reader.Name == "text") {
                                        var text = reader.ReadElementString();
                                        item.text = text;
                                    }
                                 
                                }
                                items.Add(item);
                                parentNode.Text = item.title + " " + item.date.ToString();
                                parentNode.Tag = item;
                            }
                        }            
					}
                    // moving up to in TreeView if end tag is encountered
					else if (reader.NodeType == XmlNodeType.EndElement)
					{
						if (reader.Name == XmlNodeTag)
						{
							parentNode = parentNode.Parent;
						}
					}
					else if (reader.NodeType == XmlNodeType.XmlDeclaration)
					{ //Ignore Xml Declaration                    
					}
					else if (reader.NodeType == XmlNodeType.None)
					{
                        return items;
					}
					else if (reader.NodeType == XmlNodeType.Text)
					{
						parentNode.Nodes.Add(reader.Value);
					}

				}
			}
			finally
			{
                // enabling redrawing of treeview after all nodes are added
				treeView.EndUpdate();      
                reader.Close();	
			}
            return items;
		}

		/// <summary>
		/// Used by Deserialize method for setting properties of TreeNode from xml node attributes
		/// </summary>
		/// <param name="node"></param>
		/// <param name="propertyName"></param>
		/// <param name="value"></param>
		private void SetAttributeValue(TreeNode node, string propertyName, string value)
		{
			if (propertyName == XmlNodeTextAtt)
			{                
				node.Text = value;				
			}
			else if (propertyName == XmlNodeImageIndexAtt) 
			{
				node.ImageIndex = int.Parse(value);
			}
			else if (propertyName == XmlNodeTagAtt)
			{
				node.Tag = value;
			}		
		}


        private void treeView1_ItemDrag(object sender, ItemDragEventArgs e) {
            TreeView tv = (TreeView)sender;
            tv.SelectedNode = (TreeNode)e.Item;
            tv.Focus();
            //ノードのドラッグを開始する
            DragDropEffects dde = tv.DoDragDrop(e.Item, DragDropEffects.All);
            //移動した時は、ドラッグしたノードを削除する
            if ((dde & DragDropEffects.Move) == DragDropEffects.Move) {
                tv.Nodes.Remove((TreeNode)e.Item);
            }
        }

        private void treeView1_DragOver(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(typeof(TreeNode))) {
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                    //何も押されていなければMove
                    e.Effect = DragDropEffects.Move;
            } else {
                //TreeNodeでなければ受け入れない
                e.Effect = DragDropEffects.None;
            }
        

            //マウス下のNodeを選択する
            if (e.Effect != DragDropEffects.None) {
                TreeView tv = (TreeView)sender;
                //マウスのあるNodeを取得する
                TreeNode target = tv.GetNodeAt(tv.PointToClient(new Point(e.X, e.Y)));
                //ドラッグされているNodeを取得する
                TreeNode source = (TreeNode)e.Data.GetData(typeof(TreeNode));
                //マウス下のNodeがドロップ先として適切か調べる
                if (target != null && target != source && !IsChildNode(source, target)) {
                    //Nodeを選択する
                    if (target.IsSelected == false)
                        tv.SelectedNode = target;
                } else if (target == null) {
                    tv.SelectedNode = null;
                } else
                    e.Effect = DragDropEffects.None;
            }
        }

        private void treeView1_DragDrop(object sender, DragEventArgs e) {
            //ドロップされたデータがTreeNodeか調べる
            if (e.Data.GetDataPresent(typeof(TreeNode))) {
                TreeView tv = (TreeView)sender;
                //ドロップされたデータ(TreeNode)を取得
                TreeNode source = (TreeNode)e.Data.GetData(typeof(TreeNode));
                //ドロップ先のTreeNodeを取得する
                TreeNode target = tv.GetNodeAt(tv.PointToClient(new Point(e.X, e.Y)));
                //マウス下のNodeがドロップ先として適切か調べる
                if (target != null && target != source && !IsChildNode(source, target)) {
                    //ドロップされたNodeのコピーを作成
                    TreeNode cln = (TreeNode)source.Clone();
                    //Nodeを追加
                    target.Nodes.Add(cln);
                    //ドロップ先のNodeを展開
                    target.Expand();
                    //追加されたNodeを選択
                    tv.SelectedNode = cln;
                } else if (target == null) {
                    //ドロップされたNodeのコピーを作成
                    TreeNode cln = (TreeNode)source.Clone();
                    //Nodeを追加
                    tv.Nodes.Add(cln);
                    
                    //ドロップ先のNodeを展開
                    //target.Expand();
                    //追加されたNodeを選択
                    tv.SelectedNode = cln;

                } else
                    e.Effect = DragDropEffects.None;
            } else
                e.Effect = DragDropEffects.None;
        }

        /// <returns>子ノードの時はTrue</returns>
        private static bool IsChildNode(TreeNode parent, TreeNode child) {
            if (child.Parent == parent)
                return true;
            else if (child.Parent != null)
                return IsChildNode(parent, child.Parent);
            else
                return false;
        }

        private void listView1_DragOver(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(typeof(TreeNode))) {
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                    //何も押されていなければMove
                    e.Effect = DragDropEffects.Move;
            } else {
                //TreeNodeでなければ受け入れない
                e.Effect = DragDropEffects.None;
            }


            //マウス下のNodeを選択する
            if (e.Effect != DragDropEffects.None) {
                ListView lv = (ListView)sender;
                //マウスのあるNodeを取得する
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                //ドラッグされているNodeを取得する
                TreeNode source = (TreeNode)e.Data.GetData(typeof(TreeNode));
                //マウス下のNodeがドロップ先として適切か調べる
                if (target != null && !target.Text.Equals(lv.SelectedItems[0].Text)) {
                } else
                    e.Effect = DragDropEffects.None;
            }
        }

        private void listView1_DragDrop(object sender, DragEventArgs e) {
            //ドロップされたデータがTreeNodeか調べる
            if (e.Data.GetDataPresent(typeof(TreeNode))) {
                ListView lv = (ListView)sender;
                //ドロップされたデータ(TreeNode)を取得
                TreeNode source = (TreeNode)e.Data.GetData(typeof(TreeNode));
                //ドロップ先のTreeNodeを取得する
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                //マウス下のNodeがドロップ先として適切か調べる
                if (target != null) {
                    //ドロップされたNodeのコピーを作成
                    TreeNode cln = (TreeNode)source.Clone();
                    var tv = getTreeView(getTabControl(target.Text));
                    tv.Nodes.Add(cln);
                    SerializeTreeView(tv.Nodes.Cast<TreeNode>().ToArray(), target.Text);

                    tv = getTreeView(getTabControl(lv.SelectedItems[0].Text));
                    tv.Nodes.Remove((TreeNode)source);
                    SerializeTreeView(tv.Nodes.Cast<TreeNode>().ToArray(), lv.SelectedItems[0].Text);

                } else
                    e.Effect = DragDropEffects.None;
            } else
                e.Effect = DragDropEffects.None;
        }
       
    }
}
