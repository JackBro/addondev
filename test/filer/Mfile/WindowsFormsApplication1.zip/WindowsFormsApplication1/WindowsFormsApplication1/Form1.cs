﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Jint;
using Jint.Debugger;
using System.Threading;

namespace WindowsFormsApplication1 {
    public partial class Form1 : Form {
        JintEngine jint;
        FileStream fs;
        bool step;
        Sgry.Azuki.WinForms.AzukiControl azuki;
        BackgroundWorker bw = new BackgroundWorker();
        public Form1() {
            InitializeComponent();

            var ds = DateTime.Now.ToShortDateString();
            var ts = DateTime.Now.ToLongTimeString();

            azuki = new Sgry.Azuki.WinForms.AzukiControl();
            ///azuki.Document.Highlighter 
            azuki.Dock = DockStyle.Fill;
            panel1.Controls.Add(azuki);

            azuki.AllowDrop = true;
            azuki.DragEnter += new DragEventHandler(azuki_DragEnter);
            azuki.DragOver += new DragEventHandler(azuki_DragOver);
            azuki.DragDrop +=new DragEventHandler(azuki_DragDrop);


            //azuki.LineDrawing += (sender, e) => {
            //    e.ShouldBeRedrawn = true;
            //    //if (e.LineIndex == 3)
            //    e.Graphics.FillRectangle(10, 10, 10, 10);
            //};
            var bks = new List<int>();
            var lm = azuki.View.XofTextArea;

            markpanel.MouseClick +=(s, e)=>{
                //if (e.Location.X < lm) {
                    var p = e.Location;
                    var l = azuki.GetIndexFromPosition(p);
                    var line = azuki.GetLineIndexFromCharIndex(l);
                    var tmp = 0;
                    if (bks.Contains(line)) {
                        bks.Remove(line);
                    }else{
                        bks.Add(line);
                    }
                    azuki.Invalidate();// Refresh();
                    //azuki.Refresh();
                //}
            };
            Brush b = new SolidBrush(Color.Red);
            azuki.LineDrawn += (sender, e) => {
                e.ShouldBeRedrawn = true;
                //if (e.LineIndex == 3)
                if (bks.Contains(e.LineIndex)) {
                    e.Graphics.FillRectangle(0, e.Position.Y, 10, 10);
                }
               
                //markpanel.CreateGraphics().FillRectangle(b, e.Position.X, e.Position.Y, 10, 10);
            };
            string test = @"
print(f(4,5));
var i = 3; 
print(i);
function square(x) { 
    return x*x; // breakpoint here
}
    
square(1);
square(2); // will break only on this line
square(3);
print(100);
";

            System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();

            azuki.HighlightsCurrentLine = true;
           

            azuki.Text = test;

            bool isstop = false;

            jint = new JintEngine();
            
            jint.DisableSecurity();
            jint.AllowClr = true;
            jint.SetDebugMode(true);


            jint.SetFunction("print", new Action<object>(s => { 
                //Console.ForegroundColor = ConsoleColor.Blue; Console.Write(s); Console.ResetColor();
                Console.WriteLine(s.ToString()); // Displays 2
            }));

            jint .Run(@"
  var f = function (x, y) {
print('function');
    return x * y;
  }
");



            //jint.BreakPoints.Add(new BreakPoint(5, 22, "x == 2;")); // Line 4, Char 22 => return x*x; only if x == 2
            jint.BreakPoints.Add(new BreakPoint(3, 0)); // Line 4, Char 22 => return x*x; only if x == 2
            step = false;

            jint.Step += (sender, info) => {

                if (bw.CancellationPending) {
                    isstop = true;
                    throw new Jint.JintException("stop");
                    //bw.CancelAsync();
                }
                else {
                    var ll = info.Locals;

                    Console.WriteLine("{0} CallStack:{1} Label:{2} Line:{3}", info.CurrentStatement.ToString(), info.CallStack.Count>0 ?info.CallStack.Peek():"null", info.CurrentStatement.Label, info.CurrentStatement.Source.Start.Line);
                    
                    //MessageBox.Show("step");
                    //t.Interval = 5000;
                    //t.Start();
                    while (true) {
                        Thread.Sleep(500);
                        if (step) {
                            step = false;
                            bw.ReportProgress(info.CurrentStatement.Source.Start.Line - 1, info);
                            //azuki.Document.SetCaretIndex(info.CurrentStatement.Source.Start.Line, 0);
                            break;
                        }
                    }
                }
            };
            jint.Break += (sender, info) => {
                Console.WriteLine("Break : " + info.Locals["i"].Value); // Displays 2
                
                while (true) {
                    Thread.Sleep(500);
                    if (step) {
                        step = false;
                        break;
                    }
                }
            };
            bw.WorkerSupportsCancellation = true;
            bw.WorkerReportsProgress = true;
            bw.DoWork += (s, a) => {
                try {
                    jint.Run((string)a.Argument);
                }
                catch (Exception ex) {
                    //bw.
                    //throw;
                    var ff = ex;
                }       
            };
            bw.ProgressChanged += (s, a) => {
                var line = a.ProgressPercentage;
                azuki.Document.SetCaretIndex(line, 0);
                DebugInformation info = a.UserState as DebugInformation;
                info.Locals.
                LocalListView.Items
            };
            bw.RunWorkerCompleted += (s, a) => {
                var c = bw.CancellationPending;
                if (isstop) {
                }
            };
            //jint.Run(test);

            ////string root = @"c:\wwwroot\"; // ドキュメント・ルート
            ////http://localhost:8088/
            ////http://*:8080/
            //string prefix = "http://*:8088/"; // 受け付けるURL

            //HttpListener listener = new HttpListener();
            
            //listener.Prefixes.Add(prefix); // プレフィックスの登録

            //bw.DoWork += (sender, e) => {
            //    listener.Start();

            //    while (true) {
            //        HttpListenerContext context = listener.GetContext();
            //        HttpListenerRequest req = context.Request;
            //        HttpListenerResponse res = context.Response;

            //        Console.WriteLine(req.RawUrl);

            //        //// リクエストされたURLからファイルのパスを求める
            //        //string path = root + req.RawUrl.Replace("/", "\\");

            //        //// ファイルが存在すればレスポンス・ストリームに書き出す
            //        //if (File.Exists(path)) {
            //        //    byte[] content = File.ReadAllBytes(path);
            //        //    res.OutputStream.Write(content, 0, content.Length);
            //        //}
            //        string resString = "tttt";
            //        Encoding enc = Encoding.UTF8;
            //        byte[] buffer = enc.GetBytes(resString);
            //        res.OutputStream.Write(buffer, 0, buffer.Length);
            //        res.Close();
            //    }   
            //};
            //bw.RunWorkerAsync();
            //HttpServer hs = new HttpServer();
            //hs.RequestEvent += new RequestEventHandler(hs_RequestEvent);
            //bw.DoWork += (sender, e) => {
            //    hs.start();
            //};
            //bw.RunWorkerAsync();
        }

        void hs_RequestEvent(object sender, RequestEventArgs e) {
            //throw new NotImplementedException();
            e.Response = "hs_RequestEvent";
        }


        void azuki_DragEnter(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                //ドラッグされたデータ形式を調べ、ファイルのときはコピーとする
                e.Effect = DragDropEffects.Copy;
        }

        void azuki_DragOver(object sender, DragEventArgs e) {
            //throw new NotImplementedException();
            //e.Effect = DragDropEffects.Move;
           
        }

        void azuki_DragDrop(object sender, DragEventArgs e) {
            //throw new NotImplementedException();
            //コントロール内にドロップされたとき実行される
            //ドロップされたすべてのファイル名を取得する
            string[] fileName =
                (string[])e.Data.GetData(DataFormats.FileDrop, false);
            //ListBoxに追加する
            //ListBox1.Items.AddRange(fileName);
            var i = azuki.CaretIndex;
            //azuki.Text.Insert(0, fileName[0]);
            azuki.Document.Replace(fileName[0], i, i);
            var kk = 0;
        }

        private void RuntoolStripButton1_Click(object sender, EventArgs e) {
            //jint.Run(azuki.Text);
            var test = azuki.Text;
            bw.RunWorkerAsync(test);
        }

        private void steptoolStripButton1_Click(object sender, EventArgs e) {
            step = true;
            //jint.Step += (s, info) => {
            //    Console.WriteLine("{0}: Line {1}", info.CurrentStatement.ToString(), info.CurrentStatement.Source.Start.Line);
            //};
            //jint.
        }

        private void stoptoolStripButton1_Click(object sender, EventArgs e) {
            bw.CancelAsync();
            step = true;
        }
    }
}
