﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Sgry.Azuki.WinForms.AzukiControl editor;
        ListViewEx listview;
        manager m;
        public Form1()
        {
            InitializeComponent();

            editor = new Sgry.Azuki.WinForms.AzukiControl();
            editor.Dock = DockStyle.Fill;
            panel1.Controls.Add(editor);
            editor.Document.MarksUri = true;

            listview = new ListViewEx();
            listview.Dock = DockStyle.Fill;
            panel2.Controls.Add(listview);


            m = new manager();
            m.ChangeEvent += (s, e) =>
            {
                if (e.type == ChangeType.Add)
                {
                    var c = s as Class1;
                    listView1.Items.Add(c.name);
                }
            };
            var cl = new Class1();
            cl.ChangeItemItemEvent+=(s,e)=>{
               if( e.type== ChangeType.Add){
                //listview.AddItem(s as Item);
                //   listview.DataItems = cl.items;
                //   listview.Refresh();
               }
            };

            cl.Add(new Item { title = "title", text = "test", date = DateTime.Now });
            m.Add("test", cl);


            listview.SelectedIndexChanged += (s, e) =>
            {
                if (listview.SelectedIndices.Count > 0)
                {
                    var index = listview.SelectedIndices[0];
                    editor.Text = listview.DataItems[index].text;
                }
            };

            listView1.ItemSelectionChanged += (s, e) =>
            {
                if (listView1.SelectedItems.Count > 0)
                {
                    var name = listView1.SelectedItems[0].Text;
                    var items = m.getClass(name).items;
                    if (items != null)
                    {
                        listview.DataItems = items;
                        listview.Refresh();
                    }
                }
            };

            if (listView1.Items.Count > 0)
            {
                listView1.Items[0].Selected = true;
            }

            toolStripButton1.Click += (s, e) =>
            {
                if (listView1.SelectedItems.Count > 0)
                {
                    var viewitem = listView1.SelectedItems[0];
                    var c = m.getClass(viewitem.Text);
                    c.Add(new Item { title="new", text="new", date=DateTime.Now });
                }
            };

            toolStripMenuItem1.Click += (s, e) =>
            {
                var newcl = new Class1();
                newcl.ChangeItemItemEvent += (s2, e2) =>
                {
                    if (e2.type == ChangeType.Add)
                    {
                        //listview.DataItems = newcl.items;
                        //listview.Refresh();
                        //listview.AddItem(s2 as Item);
                    }
                };

                newcl.Add(new Item { title = "title1", text = "test1", date = DateTime.Now });
                m.Add("new", newcl);
            };

            listView1.ContextMenuStrip = contextMenuStrip1;
        }
    }
}
