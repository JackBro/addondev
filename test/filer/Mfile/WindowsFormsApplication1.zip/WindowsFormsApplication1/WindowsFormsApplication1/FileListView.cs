﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1 {
    class FileListView :ListView {
        public FileListView() {
            this.MultiSelect = false;
            this.AllowDrop = true;
            this.FullRowSelect = true;
            this.HideSelection = false;
            this.LabelEdit = true;
            this.LabelWrap = false;
        }
        protected override void OnMouseDown(MouseEventArgs e) {
            if (this.GetItemAt(e.X, e.Y) != null) {
                base.OnMouseDown(e);
            }
        }
    }
}
