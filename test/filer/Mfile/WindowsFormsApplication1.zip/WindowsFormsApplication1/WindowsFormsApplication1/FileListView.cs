﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1 {
    class FileListView :ListView {
        private bool f;
        private int index=-1;
        public FileListView() {
            this.MultiSelect = false;
            this.AllowDrop = true;
            this.FullRowSelect = true;
            this.HideSelection = false;
            this.LabelEdit = true;
            this.LabelWrap = false;
            
            f = true;
        }
        protected override void OnMouseDown(MouseEventArgs e) {
            if (this.GetItemAt(e.X, e.Y) != null) {
                f = true;

            } else {
                f = false;
                //if (sle != null) {
                //    sle.Focused = true;
                //    sle.Selected = true;
                //}
                //if (index != -1) {
                //    this.Items[index].Selected = true;
                //}
            }
            base.OnMouseDown(e);
        }
        protected override void OnMouseUp(MouseEventArgs e) {
            f = this.GetItemAt(e.X, e.Y) != null;
            if (index != -1 && (this.GetItemAt(e.X, e.Y) == null)) {
                this.Items[index].Selected = true;
            }
            
            base.OnMouseUp(e);
        }
        //protected override void OnMouseClick(MouseEventArgs e) {
        //    if (this.GetItemAt(e.X, e.Y) != null) {
        //        f = true;

        //    } else {
        //        f = false;
        //        //if (sle != null) {
        //        //    sle.Focused = true;
        //        //    sle.Selected = true;
        //        //}
        //        //if (index != -1) {
        //        //    this.Items[index].Selected = true;
        //        //}
        //    }
        //    base.OnMouseClick(e);
        //}

        protected override void OnItemSelectionChanged(ListViewItemSelectionChangedEventArgs e) {
            if (e.IsSelected && f) {
                //if (sle != null) sle.Selected = false;
                base.OnItemSelectionChanged(e);
            } else {
                //if(sle!=null)sle.Selected = true;
            }
            if (e.IsSelected) {
                //sle = e.Item;
                index = e.ItemIndex;
            }
        }
    }
}
