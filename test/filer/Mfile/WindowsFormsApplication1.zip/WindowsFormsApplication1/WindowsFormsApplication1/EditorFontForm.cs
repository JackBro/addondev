﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Text;
using Sgry.Azuki;

namespace WindowsFormsApplication1 {
    public partial class EditorFontForm : Form {
        public EditorFontForm() {
            InitializeComponent();

            foreach (FontFamily family in new InstalledFontCollection().Families) {
                FontNamelistBox.Items.Add(family.Name);
            }
        }

        public void setFontInfo(string fontName, int fontSize) {
            FontNamelistBox.Text = fontName;
            FontSizenumericUpDown.Value = fontSize;
        }

        public FontInfo getFontInfo() {
            return new FontInfo(FontNamelistBox.Text, int.Parse(FontSizenumericUpDown.Value.ToString()), FontStyle.Regular);
        }

        private void OKbutton_Click(object sender, EventArgs e) {
            DialogResult = DialogResult.OK;
        }

        private void Cancelbutton_Click(object sender, EventArgs e) {
            DialogResult = DialogResult.Cancel;
        }
    }
}
