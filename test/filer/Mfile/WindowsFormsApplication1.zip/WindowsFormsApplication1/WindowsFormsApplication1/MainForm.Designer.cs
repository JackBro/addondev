﻿namespace WindowsFormsApplication1
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.TabPanel = new System.Windows.Forms.Panel();
            this.MainEditorPanel = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.DateTimeLabel = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ThumbnailListView = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.FileimageList = new System.Windows.Forms.ImageList(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newFiletoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.newMemotoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.listMemotoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.thumbnailtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.WraptoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.showSubPaneltoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renameFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emptyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.newMemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newMemoWithLinkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newMemoWithRootLinkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editDateTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorsearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wrapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subPanleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThumbnailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showMemoListtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showLinkedMemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FileListViewContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.renameFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.upFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.downFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.emptyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ListViewContextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newMemoToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.newMemoWithLinkToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.newMemoWithParentLinkToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMemoToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.editorcontextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.undotoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redotoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.cuttoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copytoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pastetoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteAsQuotationtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAlltoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertDatetoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.notifyIconcontextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.showToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.FileListViewContextMenuStrip.SuspendLayout();
            this.ListViewContextMenuStrip3.SuspendLayout();
            this.editorcontextMenuStrip.SuspendLayout();
            this.notifyIconcontextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 52);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(735, 486);
            this.splitContainer1.SplitterDistance = 102;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer2.Size = new System.Drawing.Size(629, 486);
            this.splitContainer2.SplitterDistance = 311;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.TabPanel);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.MainEditorPanel);
            this.splitContainer3.Panel2.Controls.Add(this.panel4);
            this.splitContainer3.Size = new System.Drawing.Size(629, 311);
            this.splitContainer3.SplitterDistance = 118;
            this.splitContainer3.TabIndex = 0;
            // 
            // TabPanel
            // 
            this.TabPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabPanel.Location = new System.Drawing.Point(0, 0);
            this.TabPanel.Margin = new System.Windows.Forms.Padding(0);
            this.TabPanel.Name = "TabPanel";
            this.TabPanel.Size = new System.Drawing.Size(629, 118);
            this.TabPanel.TabIndex = 0;
            // 
            // MainEditorPanel
            // 
            this.MainEditorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainEditorPanel.Location = new System.Drawing.Point(0, 25);
            this.MainEditorPanel.Name = "MainEditorPanel";
            this.MainEditorPanel.Size = new System.Drawing.Size(629, 164);
            this.MainEditorPanel.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.Controls.Add(this.DateTimeLabel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(5);
            this.panel4.Size = new System.Drawing.Size(629, 25);
            this.panel4.TabIndex = 0;
            // 
            // DateTimeLabel
            // 
            this.DateTimeLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.DateTimeLabel.AutoSize = true;
            this.DateTimeLabel.Location = new System.Drawing.Point(5, 5);
            this.DateTimeLabel.Margin = new System.Windows.Forms.Padding(3);
            this.DateTimeLabel.Name = "DateTimeLabel";
            this.DateTimeLabel.Size = new System.Drawing.Size(35, 12);
            this.DateTimeLabel.TabIndex = 0;
            this.DateTimeLabel.Text = "label1";
            this.DateTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(629, 171);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(621, 145);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ThumbnailListView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(621, 152);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ThumbnailListView
            // 
            this.ThumbnailListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThumbnailListView.LargeImageList = this.imageList1;
            this.ThumbnailListView.Location = new System.Drawing.Point(3, 3);
            this.ThumbnailListView.Name = "ThumbnailListView";
            this.ThumbnailListView.Size = new System.Drawing.Size(615, 146);
            this.ThumbnailListView.TabIndex = 0;
            this.ThumbnailListView.UseCompatibleStateImageBehavior = false;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // FileimageList
            // 
            this.FileimageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("FileimageList.ImageStream")));
            this.FileimageList.TransparentColor = System.Drawing.Color.Transparent;
            this.FileimageList.Images.SetKeyName(0, "newfile24.png");
            this.FileimageList.Images.SetKeyName(1, "trust24.png");
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFiletoolStripButton,
            this.toolStripSeparator1,
            this.newMemotoolStripButton,
            this.toolStripSeparator2,
            this.listMemotoolStripButton,
            this.thumbnailtoolStripButton,
            this.WraptoolStripButton,
            this.toolStripSeparator3,
            this.showSubPaneltoolStripButton,
            this.toolStripComboBox1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 26);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(735, 26);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newFiletoolStripButton
            // 
            this.newFiletoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newFiletoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newFiletoolStripButton.Image")));
            this.newFiletoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newFiletoolStripButton.Name = "newFiletoolStripButton";
            this.newFiletoolStripButton.Size = new System.Drawing.Size(23, 23);
            this.newFiletoolStripButton.Text = "新規ファイル";
            this.newFiletoolStripButton.Click += new System.EventHandler(this.newFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 26);
            // 
            // newMemotoolStripButton
            // 
            this.newMemotoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newMemotoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newMemotoolStripButton.Image")));
            this.newMemotoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newMemotoolStripButton.Name = "newMemotoolStripButton";
            this.newMemotoolStripButton.Size = new System.Drawing.Size(23, 23);
            this.newMemotoolStripButton.Text = "New Memo";
            this.newMemotoolStripButton.Click += new System.EventHandler(this.newMemoToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 26);
            // 
            // listMemotoolStripButton
            // 
            this.listMemotoolStripButton.BackColor = System.Drawing.SystemColors.Control;
            this.listMemotoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.listMemotoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("listMemotoolStripButton.Image")));
            this.listMemotoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.listMemotoolStripButton.Name = "listMemotoolStripButton";
            this.listMemotoolStripButton.Size = new System.Drawing.Size(23, 23);
            this.listMemotoolStripButton.Text = "List";
            this.listMemotoolStripButton.Click += new System.EventHandler(this.showMemoListtoolStripMenuItem_Click);
            // 
            // thumbnailtoolStripButton
            // 
            this.thumbnailtoolStripButton.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.thumbnailtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.thumbnailtoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("thumbnailtoolStripButton.Image")));
            this.thumbnailtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.thumbnailtoolStripButton.Name = "thumbnailtoolStripButton";
            this.thumbnailtoolStripButton.Size = new System.Drawing.Size(23, 23);
            this.thumbnailtoolStripButton.Text = "Thumbnail";
            this.thumbnailtoolStripButton.Click += new System.EventHandler(this.ThumbnailToolStripMenuItem_Click);
            // 
            // WraptoolStripButton
            // 
            this.WraptoolStripButton.CheckOnClick = true;
            this.WraptoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.WraptoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("WraptoolStripButton.Image")));
            this.WraptoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.WraptoolStripButton.Name = "WraptoolStripButton";
            this.WraptoolStripButton.Size = new System.Drawing.Size(23, 23);
            this.WraptoolStripButton.Text = "toolStripButton1";
            this.WraptoolStripButton.Click += new System.EventHandler(this.WraptoolStripButton_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 26);
            // 
            // showSubPaneltoolStripButton
            // 
            this.showSubPaneltoolStripButton.CheckOnClick = true;
            this.showSubPaneltoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.showSubPaneltoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("showSubPaneltoolStripButton.Image")));
            this.showSubPaneltoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.showSubPaneltoolStripButton.Name = "showSubPaneltoolStripButton";
            this.showSubPaneltoolStripButton.Size = new System.Drawing.Size(23, 23);
            this.showSubPaneltoolStripButton.Text = "toolStripButton1";
            this.showSubPaneltoolStripButton.Click += new System.EventHandler(this.showSubPaneltoolStripButton_Click);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 26);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.toolToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(735, 26);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFileToolStripMenuItem,
            this.deleteFileToolStripMenuItem,
            this.renameFileToolStripMenuItem,
            this.emptyToolStripMenuItem1,
            this.toolStripSeparator5,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            this.fileToolStripMenuItem.Text = "ファイル";
            // 
            // newFileToolStripMenuItem
            // 
            this.newFileToolStripMenuItem.Name = "newFileToolStripMenuItem";
            this.newFileToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.newFileToolStripMenuItem.Text = "新規ファイル";
            this.newFileToolStripMenuItem.Click += new System.EventHandler(this.newFileToolStripMenuItem_Click);
            // 
            // deleteFileToolStripMenuItem
            // 
            this.deleteFileToolStripMenuItem.Name = "deleteFileToolStripMenuItem";
            this.deleteFileToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.deleteFileToolStripMenuItem.Text = "ファイル削除";
            this.deleteFileToolStripMenuItem.Click += new System.EventHandler(this.deleteFileToolStripMenuItem_Click);
            // 
            // renameFileToolStripMenuItem
            // 
            this.renameFileToolStripMenuItem.Name = "renameFileToolStripMenuItem";
            this.renameFileToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.renameFileToolStripMenuItem.Text = "ファイル名変更";
            this.renameFileToolStripMenuItem.Click += new System.EventHandler(this.renameFileToolStripMenuItem_Click);
            // 
            // emptyToolStripMenuItem1
            // 
            this.emptyToolStripMenuItem1.Name = "emptyToolStripMenuItem1";
            this.emptyToolStripMenuItem1.Size = new System.Drawing.Size(172, 22);
            this.emptyToolStripMenuItem1.Text = "ゴミ箱を空にする";
            this.emptyToolStripMenuItem1.Click += new System.EventHandler(this.emptyToolStripMenuItem1_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(169, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.exitToolStripMenuItem.Text = "終了";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem1,
            this.toolStripSeparator4,
            this.newMemoToolStripMenuItem,
            this.newMemoWithLinkToolStripMenuItem,
            this.newMemoWithRootLinkToolStripMenuItem,
            this.deleteMemoToolStripMenuItem,
            this.editDateTimeToolStripMenuItem,
            this.editorsearchToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(44, 22);
            this.editToolStripMenuItem.Text = "編集";
            this.editToolStripMenuItem.DropDownOpening += new System.EventHandler(this.editToolStripMenuItem_DropDownOpening);
            // 
            // copyToolStripMenuItem1
            // 
            this.copyToolStripMenuItem1.Name = "copyToolStripMenuItem1";
            this.copyToolStripMenuItem1.Size = new System.Drawing.Size(237, 22);
            this.copyToolStripMenuItem1.Text = "Copy";
            this.copyToolStripMenuItem1.Click += new System.EventHandler(this.copyToolStripMenuItem1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(234, 6);
            // 
            // newMemoToolStripMenuItem
            // 
            this.newMemoToolStripMenuItem.Name = "newMemoToolStripMenuItem";
            this.newMemoToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.newMemoToolStripMenuItem.Text = "新規メモ";
            this.newMemoToolStripMenuItem.Click += new System.EventHandler(this.newMemoToolStripMenuItem_Click);
            // 
            // newMemoWithLinkToolStripMenuItem
            // 
            this.newMemoWithLinkToolStripMenuItem.Name = "newMemoWithLinkToolStripMenuItem";
            this.newMemoWithLinkToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.newMemoWithLinkToolStripMenuItem.Text = "New Memo with link";
            this.newMemoWithLinkToolStripMenuItem.Click += new System.EventHandler(this.newMemoWithLinkToolStripMenuItem_Click);
            // 
            // newMemoWithRootLinkToolStripMenuItem
            // 
            this.newMemoWithRootLinkToolStripMenuItem.Name = "newMemoWithRootLinkToolStripMenuItem";
            this.newMemoWithRootLinkToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.newMemoWithRootLinkToolStripMenuItem.Text = "New Memo with parent link";
            this.newMemoWithRootLinkToolStripMenuItem.Click += new System.EventHandler(this.newMemoWithParentLinkToolStripMenuItem_Click);
            // 
            // deleteMemoToolStripMenuItem
            // 
            this.deleteMemoToolStripMenuItem.Name = "deleteMemoToolStripMenuItem";
            this.deleteMemoToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.deleteMemoToolStripMenuItem.Text = "メモの削除";
            this.deleteMemoToolStripMenuItem.Click += new System.EventHandler(this.deleteMemoToolStripMenuItem_Click);
            // 
            // editDateTimeToolStripMenuItem
            // 
            this.editDateTimeToolStripMenuItem.Name = "editDateTimeToolStripMenuItem";
            this.editDateTimeToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.editDateTimeToolStripMenuItem.Text = "日付の編集";
            this.editDateTimeToolStripMenuItem.Click += new System.EventHandler(this.editDateTimeToolStripMenuItem_Click);
            // 
            // editorsearchToolStripMenuItem
            // 
            this.editorsearchToolStripMenuItem.Name = "editorsearchToolStripMenuItem";
            this.editorsearchToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.editorsearchToolStripMenuItem.Text = "エディタ内検索";
            this.editorsearchToolStripMenuItem.Click += new System.EventHandler(this.editorsearchToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wrapToolStripMenuItem,
            this.subPanleToolStripMenuItem,
            this.ThumbnailToolStripMenuItem,
            this.showMemoListtoolStripMenuItem,
            this.showLinkedMemoToolStripMenuItem,
            this.showToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 22);
            this.viewToolStripMenuItem.Text = "表示";
            // 
            // wrapToolStripMenuItem
            // 
            this.wrapToolStripMenuItem.CheckOnClick = true;
            this.wrapToolStripMenuItem.Name = "wrapToolStripMenuItem";
            this.wrapToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.wrapToolStripMenuItem.Text = "折り返し";
            this.wrapToolStripMenuItem.Click += new System.EventHandler(this.wrapToolStripMenuItem_Click);
            // 
            // subPanleToolStripMenuItem
            // 
            this.subPanleToolStripMenuItem.CheckOnClick = true;
            this.subPanleToolStripMenuItem.Name = "subPanleToolStripMenuItem";
            this.subPanleToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.subPanleToolStripMenuItem.Text = "Sub Panle";
            this.subPanleToolStripMenuItem.Click += new System.EventHandler(this.subPanleToolStripMenuItem_Click);
            // 
            // ThumbnailToolStripMenuItem
            // 
            this.ThumbnailToolStripMenuItem.Name = "ThumbnailToolStripMenuItem";
            this.ThumbnailToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.ThumbnailToolStripMenuItem.Text = "Thumbnail";
            this.ThumbnailToolStripMenuItem.Click += new System.EventHandler(this.ThumbnailToolStripMenuItem_Click);
            // 
            // showMemoListtoolStripMenuItem
            // 
            this.showMemoListtoolStripMenuItem.Name = "showMemoListtoolStripMenuItem";
            this.showMemoListtoolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.showMemoListtoolStripMenuItem.Text = "メモの連結表示";
            this.showMemoListtoolStripMenuItem.Click += new System.EventHandler(this.showMemoListtoolStripMenuItem_Click);
            // 
            // showLinkedMemoToolStripMenuItem
            // 
            this.showLinkedMemoToolStripMenuItem.Name = "showLinkedMemoToolStripMenuItem";
            this.showLinkedMemoToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.showLinkedMemoToolStripMenuItem.Text = "Linked Memo";
            this.showLinkedMemoToolStripMenuItem.Click += new System.EventHandler(this.showLinkedMemoToolStripMenuItem_Click);
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.showToolStripMenuItem.Text = "Link Memo";
            // 
            // toolToolStripMenuItem
            // 
            this.toolToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionToolStripMenuItem});
            this.toolToolStripMenuItem.Name = "toolToolStripMenuItem";
            this.toolToolStripMenuItem.Size = new System.Drawing.Size(56, 22);
            this.toolToolStripMenuItem.Text = "ツール";
            // 
            // optionToolStripMenuItem
            // 
            this.optionToolStripMenuItem.Name = "optionToolStripMenuItem";
            this.optionToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.optionToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.optionToolStripMenuItem.Text = "オプション";
            this.optionToolStripMenuItem.Click += new System.EventHandler(this.optionToolStripMenuItem_Click);
            // 
            // FileListViewContextMenuStrip
            // 
            this.FileListViewContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFileToolStripMenuItem1,
            this.deleteFileToolStripMenuItem1,
            this.renameFileToolStripMenuItem1,
            this.toolStripSeparator9,
            this.upFileToolStripMenuItem,
            this.downFileToolStripMenuItem,
            this.toolStripSeparator8,
            this.emptyToolStripMenuItem});
            this.FileListViewContextMenuStrip.Name = "contextMenuStrip1";
            this.FileListViewContextMenuStrip.Size = new System.Drawing.Size(149, 148);
            this.FileListViewContextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.FileListViewContextMenuStrip_Opening);
            // 
            // newFileToolStripMenuItem1
            // 
            this.newFileToolStripMenuItem1.Name = "newFileToolStripMenuItem1";
            this.newFileToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.newFileToolStripMenuItem1.Text = "New File";
            this.newFileToolStripMenuItem1.Click += new System.EventHandler(this.newFileToolStripMenuItem_Click);
            // 
            // deleteFileToolStripMenuItem1
            // 
            this.deleteFileToolStripMenuItem1.Name = "deleteFileToolStripMenuItem1";
            this.deleteFileToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.deleteFileToolStripMenuItem1.Text = "Delete File";
            this.deleteFileToolStripMenuItem1.Click += new System.EventHandler(this.deleteFileToolStripMenuItem_Click);
            // 
            // renameFileToolStripMenuItem1
            // 
            this.renameFileToolStripMenuItem1.Name = "renameFileToolStripMenuItem1";
            this.renameFileToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.renameFileToolStripMenuItem1.Text = "Rename File";
            this.renameFileToolStripMenuItem1.Click += new System.EventHandler(this.renameFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(145, 6);
            // 
            // upFileToolStripMenuItem
            // 
            this.upFileToolStripMenuItem.Name = "upFileToolStripMenuItem";
            this.upFileToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.upFileToolStripMenuItem.Text = "Up File";
            this.upFileToolStripMenuItem.Click += new System.EventHandler(this.upFileToolStripMenuItem_Click);
            // 
            // downFileToolStripMenuItem
            // 
            this.downFileToolStripMenuItem.Name = "downFileToolStripMenuItem";
            this.downFileToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.downFileToolStripMenuItem.Text = "Down File";
            this.downFileToolStripMenuItem.Click += new System.EventHandler(this.downFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(145, 6);
            // 
            // emptyToolStripMenuItem
            // 
            this.emptyToolStripMenuItem.Name = "emptyToolStripMenuItem";
            this.emptyToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.emptyToolStripMenuItem.Text = "Empty";
            this.emptyToolStripMenuItem.Click += new System.EventHandler(this.emptyToolStripMenuItem1_Click);
            // 
            // ListViewContextMenuStrip3
            // 
            this.ListViewContextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newMemoToolStripMenuItem3,
            this.newMemoWithLinkToolStripMenuItem3,
            this.newMemoWithParentLinkToolStripMenuItem3,
            this.deleteMemoToolStripMenuItem3});
            this.ListViewContextMenuStrip3.Name = "TreeViewContextMenuStrip";
            this.ListViewContextMenuStrip3.Size = new System.Drawing.Size(238, 92);
            this.ListViewContextMenuStrip3.Opening += new System.ComponentModel.CancelEventHandler(this.ListViewContextMenuStrip3_Opening);
            // 
            // newMemoToolStripMenuItem3
            // 
            this.newMemoToolStripMenuItem3.Name = "newMemoToolStripMenuItem3";
            this.newMemoToolStripMenuItem3.Size = new System.Drawing.Size(237, 22);
            this.newMemoToolStripMenuItem3.Text = "New Memo";
            this.newMemoToolStripMenuItem3.Click += new System.EventHandler(this.newMemoToolStripMenuItem_Click);
            // 
            // newMemoWithLinkToolStripMenuItem3
            // 
            this.newMemoWithLinkToolStripMenuItem3.Name = "newMemoWithLinkToolStripMenuItem3";
            this.newMemoWithLinkToolStripMenuItem3.Size = new System.Drawing.Size(237, 22);
            this.newMemoWithLinkToolStripMenuItem3.Text = "New Memo with link";
            this.newMemoWithLinkToolStripMenuItem3.Click += new System.EventHandler(this.newMemoWithLinkToolStripMenuItem_Click);
            // 
            // newMemoWithParentLinkToolStripMenuItem3
            // 
            this.newMemoWithParentLinkToolStripMenuItem3.Name = "newMemoWithParentLinkToolStripMenuItem3";
            this.newMemoWithParentLinkToolStripMenuItem3.Size = new System.Drawing.Size(237, 22);
            this.newMemoWithParentLinkToolStripMenuItem3.Text = "New Memo with parent link";
            this.newMemoWithParentLinkToolStripMenuItem3.Click += new System.EventHandler(this.newMemoWithParentLinkToolStripMenuItem_Click);
            // 
            // deleteMemoToolStripMenuItem3
            // 
            this.deleteMemoToolStripMenuItem3.Name = "deleteMemoToolStripMenuItem3";
            this.deleteMemoToolStripMenuItem3.Size = new System.Drawing.Size(237, 22);
            this.deleteMemoToolStripMenuItem3.Text = "Delete Memo";
            this.deleteMemoToolStripMenuItem3.Click += new System.EventHandler(this.deleteMemoToolStripMenuItem_Click);
            // 
            // editorcontextMenuStrip
            // 
            this.editorcontextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undotoolStripMenuItem,
            this.redotoolStripMenuItem,
            this.toolStripSeparator6,
            this.cuttoolStripMenuItem,
            this.copytoolStripMenuItem,
            this.pastetoolStripMenuItem,
            this.pasteAsQuotationtoolStripMenuItem,
            this.toolStripSeparator7,
            this.selectAlltoolStripMenuItem,
            this.insertDatetoolStripMenuItem});
            this.editorcontextMenuStrip.Name = "EditorcontextMenuStrip";
            this.editorcontextMenuStrip.Size = new System.Drawing.Size(185, 192);
            this.editorcontextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.editorcontextMenuStrip_Opening);
            // 
            // undotoolStripMenuItem
            // 
            this.undotoolStripMenuItem.Name = "undotoolStripMenuItem";
            this.undotoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.undotoolStripMenuItem.Text = "Undo";
            this.undotoolStripMenuItem.Click += new System.EventHandler(this.undotoolStripMenuItem_Click);
            // 
            // redotoolStripMenuItem
            // 
            this.redotoolStripMenuItem.Name = "redotoolStripMenuItem";
            this.redotoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.redotoolStripMenuItem.Text = "Redo";
            this.redotoolStripMenuItem.Click += new System.EventHandler(this.redotoolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(181, 6);
            // 
            // cuttoolStripMenuItem
            // 
            this.cuttoolStripMenuItem.Name = "cuttoolStripMenuItem";
            this.cuttoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.cuttoolStripMenuItem.Text = "Cut";
            this.cuttoolStripMenuItem.Click += new System.EventHandler(this.cuttoolStripMenuItem_Click);
            // 
            // copytoolStripMenuItem
            // 
            this.copytoolStripMenuItem.Name = "copytoolStripMenuItem";
            this.copytoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.copytoolStripMenuItem.Text = "Copy";
            this.copytoolStripMenuItem.Click += new System.EventHandler(this.copytoolStripMenuItem_Click);
            // 
            // pastetoolStripMenuItem
            // 
            this.pastetoolStripMenuItem.Name = "pastetoolStripMenuItem";
            this.pastetoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.pastetoolStripMenuItem.Text = "Paste";
            this.pastetoolStripMenuItem.Click += new System.EventHandler(this.pastetoolStripMenuItem_Click);
            // 
            // pasteAsQuotationtoolStripMenuItem
            // 
            this.pasteAsQuotationtoolStripMenuItem.Name = "pasteAsQuotationtoolStripMenuItem";
            this.pasteAsQuotationtoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.pasteAsQuotationtoolStripMenuItem.Text = "Paste as quotation";
            this.pasteAsQuotationtoolStripMenuItem.Click += new System.EventHandler(this.pasteAsQuotationtoolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(181, 6);
            // 
            // selectAlltoolStripMenuItem
            // 
            this.selectAlltoolStripMenuItem.Name = "selectAlltoolStripMenuItem";
            this.selectAlltoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.selectAlltoolStripMenuItem.Text = "Select All";
            this.selectAlltoolStripMenuItem.Click += new System.EventHandler(this.selectAlltoolStripMenuItem_Click);
            // 
            // insertDatetoolStripMenuItem
            // 
            this.insertDatetoolStripMenuItem.Name = "insertDatetoolStripMenuItem";
            this.insertDatetoolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.insertDatetoolStripMenuItem.Text = "Date";
            this.insertDatetoolStripMenuItem.Click += new System.EventHandler(this.insertDatetoolStripMenuItem_Click);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.notifyIconcontextMenuStrip;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseClick);
            // 
            // notifyIconcontextMenuStrip
            // 
            this.notifyIconcontextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showToolStripMenuItem1,
            this.exitToolStripMenuItem1});
            this.notifyIconcontextMenuStrip.Name = "notifyIconcontextMenuStrip";
            this.notifyIconcontextMenuStrip.Size = new System.Drawing.Size(109, 48);
            // 
            // showToolStripMenuItem1
            // 
            this.showToolStripMenuItem1.Name = "showToolStripMenuItem1";
            this.showToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.showToolStripMenuItem1.Text = "Show";
            this.showToolStripMenuItem1.Click += new System.EventHandler(this.showToolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 538);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(735, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 560);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            this.splitContainer3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.FileListViewContextMenuStrip.ResumeLayout(false);
            this.ListViewContextMenuStrip3.ResumeLayout(false);
            this.editorcontextMenuStrip.ResumeLayout(false);
            this.notifyIconcontextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Panel MainEditorPanel;
        private System.Windows.Forms.ToolStripButton newMemotoolStripButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ContextMenuStrip FileListViewContextMenuStrip;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label DateTimeLabel;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.Panel TabPanel;
        private System.Windows.Forms.ToolStripButton newFiletoolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ContextMenuStrip ListViewContextMenuStrip3;
        private System.Windows.Forms.ToolStripButton listMemotoolStripButton;
        private System.Windows.Forms.ToolStripMenuItem toolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editDateTimeToolStripMenuItem;
        private System.Windows.Forms.ListView ThumbnailListView;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripButton thumbnailtoolStripButton;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStripButton showSubPaneltoolStripButton;
        private System.Windows.Forms.ToolStripButton WraptoolStripButton;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip editorcontextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem newFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renameFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newMemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteMemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subPanleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showMemoListtoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ThumbnailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showLinkedMemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newMemoWithLinkToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem copytoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cuttoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pastetoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteAsQuotationtoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertDatetoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undotoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redotoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAlltoolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ImageList FileimageList;
        private System.Windows.Forms.ToolStripMenuItem newFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deleteFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem renameFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem emptyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editorsearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emptyToolStripMenuItem1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip notifyIconcontextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newMemoWithParentLinkToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem newMemoWithLinkToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem newMemoToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem newMemoWithRootLinkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteMemoToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem wrapToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem upFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem downFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.StatusStrip statusStrip1;
    }
}

