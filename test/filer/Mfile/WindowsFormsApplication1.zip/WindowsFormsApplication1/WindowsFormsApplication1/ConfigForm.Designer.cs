﻿namespace WindowsFormsApplication1 {
    partial class ConfigForm {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent() {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.FontNameLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.TransparentCheckBox = new System.Windows.Forms.CheckBox();
            this.BackColorButton = new System.Windows.Forms.Button();
            this.ForeColorButton = new System.Windows.Forms.Button();
            this.PreviewEditorPanel = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.EnclosureStarttextBox4 = new System.Windows.Forms.TextBox();
            this.EnclosureCheckBox4 = new System.Windows.Forms.CheckBox();
            this.EnclosureCheckBox1 = new System.Windows.Forms.CheckBox();
            this.EnclosureStarttextBox0 = new System.Windows.Forms.TextBox();
            this.EnclosureEndtextBox0 = new System.Windows.Forms.TextBox();
            this.EnclosureColorcomboBox0 = new System.Windows.Forms.ComboBox();
            this.EnclosureStarttextBox1 = new System.Windows.Forms.TextBox();
            this.EnclosureCheckBox3 = new System.Windows.Forms.CheckBox();
            this.EnclosureCheckBox0 = new System.Windows.Forms.CheckBox();
            this.EnclosureCheckBox2 = new System.Windows.Forms.CheckBox();
            this.EnclosureStarttextBox2 = new System.Windows.Forms.TextBox();
            this.EnclosureStarttextBox3 = new System.Windows.Forms.TextBox();
            this.EnclosureEndtextBox1 = new System.Windows.Forms.TextBox();
            this.EnclosureEndtextBox4 = new System.Windows.Forms.TextBox();
            this.EnclosureEndtextBox2 = new System.Windows.Forms.TextBox();
            this.EnclosureEndtextBox3 = new System.Windows.Forms.TextBox();
            this.EnclosureColorcomboBox1 = new System.Windows.Forms.ComboBox();
            this.EnclosureColorcomboBox2 = new System.Windows.Forms.ComboBox();
            this.EnclosureColorcomboBox3 = new System.Windows.Forms.ComboBox();
            this.EnclosureColorcomboBox4 = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Cancelbutton = new System.Windows.Forms.Button();
            this.OKbutton = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(657, 495);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(649, 469);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(643, 463);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.tableLayoutPanel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(635, 437);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(6, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(370, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.checkBox1);
            this.flowLayoutPanel1.Controls.Add(this.checkBox6);
            this.flowLayoutPanel1.Controls.Add(this.checkBox2);
            this.flowLayoutPanel1.Controls.Add(this.checkBox4);
            this.flowLayoutPanel1.Controls.Add(this.checkBox3);
            this.flowLayoutPanel1.Controls.Add(this.checkBox5);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 15);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(364, 82);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(3, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(46, 16);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "EOF";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(55, 3);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(45, 16);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.Text = "EOL";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(106, 3);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(83, 16);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "WhiteSpace";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(195, 3);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(102, 16);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "FullWidthSpace";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(303, 3);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(43, 16);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "Tab";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(3, 25);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(88, 16);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "Line Number";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.FontNameLabel, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.numericUpDown1, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 21);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(392, 56);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // FontNameLabel
            // 
            this.FontNameLabel.AutoSize = true;
            this.FontNameLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FontNameLabel.Location = new System.Drawing.Point(58, 0);
            this.FontNameLabel.Name = "FontNameLabel";
            this.FontNameLabel.Size = new System.Drawing.Size(296, 29);
            this.FontNameLabel.TabIndex = 1;
            this.FontNameLabel.Text = "label2";
            this.FontNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(360, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Font";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tab num";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(58, 32);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 19);
            this.numericUpDown1.TabIndex = 5;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.TransparentCheckBox);
            this.tabPage4.Controls.Add(this.BackColorButton);
            this.tabPage4.Controls.Add(this.ForeColorButton);
            this.tabPage4.Controls.Add(this.PreviewEditorPanel);
            this.tabPage4.Controls.Add(this.listBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(635, 437);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Color";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // TransparentCheckBox
            // 
            this.TransparentCheckBox.AutoSize = true;
            this.TransparentCheckBox.Location = new System.Drawing.Point(277, 49);
            this.TransparentCheckBox.Name = "TransparentCheckBox";
            this.TransparentCheckBox.Size = new System.Drawing.Size(85, 16);
            this.TransparentCheckBox.TabIndex = 4;
            this.TransparentCheckBox.Text = "Transparent";
            this.TransparentCheckBox.UseVisualStyleBackColor = true;
            // 
            // BackColorButton
            // 
            this.BackColorButton.Location = new System.Drawing.Point(198, 47);
            this.BackColorButton.Name = "BackColorButton";
            this.BackColorButton.Size = new System.Drawing.Size(73, 29);
            this.BackColorButton.TabIndex = 3;
            this.BackColorButton.Text = "BackColor";
            this.BackColorButton.UseVisualStyleBackColor = true;
            // 
            // ForeColorButton
            // 
            this.ForeColorButton.Location = new System.Drawing.Point(199, 18);
            this.ForeColorButton.Name = "ForeColorButton";
            this.ForeColorButton.Size = new System.Drawing.Size(72, 23);
            this.ForeColorButton.TabIndex = 2;
            this.ForeColorButton.Text = "ForeColor";
            this.ForeColorButton.UseVisualStyleBackColor = true;
            // 
            // PreviewEditorPanel
            // 
            this.PreviewEditorPanel.Location = new System.Drawing.Point(30, 203);
            this.PreviewEditorPanel.Name = "PreviewEditorPanel";
            this.PreviewEditorPanel.Size = new System.Drawing.Size(200, 100);
            this.PreviewEditorPanel.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(3, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 88);
            this.listBox1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(635, 437);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel2);
            this.groupBox2.Location = new System.Drawing.Point(19, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(346, 204);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.EnclosureStarttextBox4, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureCheckBox4, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureCheckBox1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureStarttextBox0, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureEndtextBox0, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureColorcomboBox0, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureStarttextBox1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureCheckBox3, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureCheckBox0, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureCheckBox2, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureStarttextBox2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureStarttextBox3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureEndtextBox1, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureEndtextBox4, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureEndtextBox2, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureEndtextBox3, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureColorcomboBox1, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureColorcomboBox2, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureColorcomboBox3, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.EnclosureColorcomboBox4, 3, 4);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 15);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(296, 186);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // EnclosureStarttextBox4
            // 
            this.EnclosureStarttextBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureStarttextBox4.Location = new System.Drawing.Point(24, 157);
            this.EnclosureStarttextBox4.Name = "EnclosureStarttextBox4";
            this.EnclosureStarttextBox4.Size = new System.Drawing.Size(50, 19);
            this.EnclosureStarttextBox4.TabIndex = 16;
            // 
            // EnclosureCheckBox4
            // 
            this.EnclosureCheckBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureCheckBox4.AutoSize = true;
            this.EnclosureCheckBox4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EnclosureCheckBox4.Location = new System.Drawing.Point(3, 160);
            this.EnclosureCheckBox4.Name = "EnclosureCheckBox4";
            this.EnclosureCheckBox4.Size = new System.Drawing.Size(15, 14);
            this.EnclosureCheckBox4.TabIndex = 9;
            this.EnclosureCheckBox4.UseVisualStyleBackColor = true;
            this.EnclosureCheckBox4.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // EnclosureCheckBox1
            // 
            this.EnclosureCheckBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureCheckBox1.AutoSize = true;
            this.EnclosureCheckBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EnclosureCheckBox1.Location = new System.Drawing.Point(3, 48);
            this.EnclosureCheckBox1.Name = "EnclosureCheckBox1";
            this.EnclosureCheckBox1.Size = new System.Drawing.Size(15, 14);
            this.EnclosureCheckBox1.TabIndex = 4;
            this.EnclosureCheckBox1.UseVisualStyleBackColor = true;
            // 
            // EnclosureStarttextBox0
            // 
            this.EnclosureStarttextBox0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureStarttextBox0.Location = new System.Drawing.Point(24, 9);
            this.EnclosureStarttextBox0.Name = "EnclosureStarttextBox0";
            this.EnclosureStarttextBox0.Size = new System.Drawing.Size(50, 19);
            this.EnclosureStarttextBox0.TabIndex = 1;
            // 
            // EnclosureEndtextBox0
            // 
            this.EnclosureEndtextBox0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureEndtextBox0.Location = new System.Drawing.Point(80, 9);
            this.EnclosureEndtextBox0.Name = "EnclosureEndtextBox0";
            this.EnclosureEndtextBox0.Size = new System.Drawing.Size(50, 19);
            this.EnclosureEndtextBox0.TabIndex = 2;
            // 
            // EnclosureColorcomboBox0
            // 
            this.EnclosureColorcomboBox0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.EnclosureColorcomboBox0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnclosureColorcomboBox0.FormattingEnabled = true;
            this.EnclosureColorcomboBox0.Location = new System.Drawing.Point(136, 8);
            this.EnclosureColorcomboBox0.Name = "EnclosureColorcomboBox0";
            this.EnclosureColorcomboBox0.Size = new System.Drawing.Size(157, 20);
            this.EnclosureColorcomboBox0.TabIndex = 3;
            // 
            // EnclosureStarttextBox1
            // 
            this.EnclosureStarttextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureStarttextBox1.Location = new System.Drawing.Point(24, 46);
            this.EnclosureStarttextBox1.Name = "EnclosureStarttextBox1";
            this.EnclosureStarttextBox1.Size = new System.Drawing.Size(50, 19);
            this.EnclosureStarttextBox1.TabIndex = 7;
            // 
            // EnclosureCheckBox3
            // 
            this.EnclosureCheckBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureCheckBox3.AutoSize = true;
            this.EnclosureCheckBox3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EnclosureCheckBox3.Location = new System.Drawing.Point(3, 122);
            this.EnclosureCheckBox3.Name = "EnclosureCheckBox3";
            this.EnclosureCheckBox3.Size = new System.Drawing.Size(15, 14);
            this.EnclosureCheckBox3.TabIndex = 8;
            this.EnclosureCheckBox3.UseVisualStyleBackColor = true;
            // 
            // EnclosureCheckBox0
            // 
            this.EnclosureCheckBox0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureCheckBox0.AutoSize = true;
            this.EnclosureCheckBox0.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EnclosureCheckBox0.Location = new System.Drawing.Point(3, 11);
            this.EnclosureCheckBox0.Name = "EnclosureCheckBox0";
            this.EnclosureCheckBox0.Size = new System.Drawing.Size(15, 14);
            this.EnclosureCheckBox0.TabIndex = 10;
            this.EnclosureCheckBox0.UseVisualStyleBackColor = true;
            // 
            // EnclosureCheckBox2
            // 
            this.EnclosureCheckBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureCheckBox2.AutoSize = true;
            this.EnclosureCheckBox2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EnclosureCheckBox2.Location = new System.Drawing.Point(3, 85);
            this.EnclosureCheckBox2.Name = "EnclosureCheckBox2";
            this.EnclosureCheckBox2.Size = new System.Drawing.Size(15, 14);
            this.EnclosureCheckBox2.TabIndex = 11;
            this.EnclosureCheckBox2.UseVisualStyleBackColor = true;
            // 
            // EnclosureStarttextBox2
            // 
            this.EnclosureStarttextBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureStarttextBox2.Location = new System.Drawing.Point(24, 83);
            this.EnclosureStarttextBox2.Name = "EnclosureStarttextBox2";
            this.EnclosureStarttextBox2.Size = new System.Drawing.Size(50, 19);
            this.EnclosureStarttextBox2.TabIndex = 12;
            // 
            // EnclosureStarttextBox3
            // 
            this.EnclosureStarttextBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureStarttextBox3.Location = new System.Drawing.Point(24, 120);
            this.EnclosureStarttextBox3.Name = "EnclosureStarttextBox3";
            this.EnclosureStarttextBox3.Size = new System.Drawing.Size(50, 19);
            this.EnclosureStarttextBox3.TabIndex = 13;
            // 
            // EnclosureEndtextBox1
            // 
            this.EnclosureEndtextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureEndtextBox1.Location = new System.Drawing.Point(80, 46);
            this.EnclosureEndtextBox1.Name = "EnclosureEndtextBox1";
            this.EnclosureEndtextBox1.Size = new System.Drawing.Size(50, 19);
            this.EnclosureEndtextBox1.TabIndex = 14;
            // 
            // EnclosureEndtextBox4
            // 
            this.EnclosureEndtextBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureEndtextBox4.Location = new System.Drawing.Point(80, 157);
            this.EnclosureEndtextBox4.Name = "EnclosureEndtextBox4";
            this.EnclosureEndtextBox4.Size = new System.Drawing.Size(50, 19);
            this.EnclosureEndtextBox4.TabIndex = 15;
            // 
            // EnclosureEndtextBox2
            // 
            this.EnclosureEndtextBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureEndtextBox2.Location = new System.Drawing.Point(80, 83);
            this.EnclosureEndtextBox2.Name = "EnclosureEndtextBox2";
            this.EnclosureEndtextBox2.Size = new System.Drawing.Size(50, 19);
            this.EnclosureEndtextBox2.TabIndex = 17;
            // 
            // EnclosureEndtextBox3
            // 
            this.EnclosureEndtextBox3.AcceptsTab = true;
            this.EnclosureEndtextBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EnclosureEndtextBox3.Location = new System.Drawing.Point(80, 120);
            this.EnclosureEndtextBox3.Name = "EnclosureEndtextBox3";
            this.EnclosureEndtextBox3.Size = new System.Drawing.Size(50, 19);
            this.EnclosureEndtextBox3.TabIndex = 18;
            // 
            // EnclosureColorcomboBox1
            // 
            this.EnclosureColorcomboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.EnclosureColorcomboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnclosureColorcomboBox1.FormattingEnabled = true;
            this.EnclosureColorcomboBox1.Location = new System.Drawing.Point(136, 45);
            this.EnclosureColorcomboBox1.Name = "EnclosureColorcomboBox1";
            this.EnclosureColorcomboBox1.Size = new System.Drawing.Size(157, 20);
            this.EnclosureColorcomboBox1.TabIndex = 19;
            // 
            // EnclosureColorcomboBox2
            // 
            this.EnclosureColorcomboBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.EnclosureColorcomboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnclosureColorcomboBox2.FormattingEnabled = true;
            this.EnclosureColorcomboBox2.Location = new System.Drawing.Point(136, 82);
            this.EnclosureColorcomboBox2.Name = "EnclosureColorcomboBox2";
            this.EnclosureColorcomboBox2.Size = new System.Drawing.Size(157, 20);
            this.EnclosureColorcomboBox2.TabIndex = 20;
            // 
            // EnclosureColorcomboBox3
            // 
            this.EnclosureColorcomboBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.EnclosureColorcomboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnclosureColorcomboBox3.FormattingEnabled = true;
            this.EnclosureColorcomboBox3.Location = new System.Drawing.Point(136, 119);
            this.EnclosureColorcomboBox3.Name = "EnclosureColorcomboBox3";
            this.EnclosureColorcomboBox3.Size = new System.Drawing.Size(157, 20);
            this.EnclosureColorcomboBox3.TabIndex = 21;
            // 
            // EnclosureColorcomboBox4
            // 
            this.EnclosureColorcomboBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.EnclosureColorcomboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnclosureColorcomboBox4.FormattingEnabled = true;
            this.EnclosureColorcomboBox4.Location = new System.Drawing.Point(136, 157);
            this.EnclosureColorcomboBox4.Name = "EnclosureColorcomboBox4";
            this.EnclosureColorcomboBox4.Size = new System.Drawing.Size(157, 20);
            this.EnclosureColorcomboBox4.TabIndex = 22;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(649, 469);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Cancelbutton);
            this.panel1.Controls.Add(this.OKbutton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 495);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(657, 32);
            this.panel1.TabIndex = 2;
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Cancelbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancelbutton.Location = new System.Drawing.Point(575, 6);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(75, 23);
            this.Cancelbutton.TabIndex = 1;
            this.Cancelbutton.Text = "Cancel";
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // OKbutton
            // 
            this.OKbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.OKbutton.Location = new System.Drawing.Point(494, 6);
            this.OKbutton.Name = "OKbutton";
            this.OKbutton.Size = new System.Drawing.Size(75, 23);
            this.OKbutton.TabIndex = 0;
            this.OKbutton.Text = "OK";
            this.OKbutton.UseVisualStyleBackColor = true;
            this.OKbutton.Click += new System.EventHandler(this.OKbutton_Click);
            // 
            // ConfigForm
            // 
            this.AcceptButton = this.OKbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.Cancelbutton;
            this.ClientSize = new System.Drawing.Size(657, 527);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Name = "ConfigForm";
            this.Text = "ConfigForm";
            this.Load += new System.EventHandler(this.ConfigForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label FontNameLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Cancelbutton;
        private System.Windows.Forms.Button OKbutton;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Panel PreviewEditorPanel;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox TransparentCheckBox;
        private System.Windows.Forms.Button BackColorButton;
        private System.Windows.Forms.Button ForeColorButton;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox EnclosureStarttextBox0;
        private System.Windows.Forms.TextBox EnclosureEndtextBox0;
        private System.Windows.Forms.ComboBox EnclosureColorcomboBox0;
        private System.Windows.Forms.CheckBox EnclosureCheckBox1;
        private System.Windows.Forms.CheckBox EnclosureCheckBox2;
        private System.Windows.Forms.CheckBox EnclosureCheckBox4;
        private System.Windows.Forms.TextBox EnclosureStarttextBox1;
        private System.Windows.Forms.CheckBox EnclosureCheckBox3;
        private System.Windows.Forms.CheckBox EnclosureCheckBox0;
        private System.Windows.Forms.TextBox EnclosureStarttextBox4;
        private System.Windows.Forms.TextBox EnclosureStarttextBox2;
        private System.Windows.Forms.TextBox EnclosureStarttextBox3;
        private System.Windows.Forms.TextBox EnclosureEndtextBox1;
        private System.Windows.Forms.TextBox EnclosureEndtextBox4;
        private System.Windows.Forms.TextBox EnclosureEndtextBox2;
        private System.Windows.Forms.TextBox EnclosureEndtextBox3;
        private System.Windows.Forms.ComboBox EnclosureColorcomboBox1;
        private System.Windows.Forms.ComboBox EnclosureColorcomboBox2;
        private System.Windows.Forms.ComboBox EnclosureColorcomboBox3;
        private System.Windows.Forms.ComboBox EnclosureColorcomboBox4;
    }
}