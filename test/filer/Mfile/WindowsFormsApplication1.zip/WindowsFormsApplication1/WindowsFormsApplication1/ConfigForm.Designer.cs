﻿namespace WindowsFormsApplication1 {
    partial class ConfigForm {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent() {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.EditorFontInfoLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.SpecialCharaColorPanel = new System.Windows.Forms.Panel();
            this.SpecialCharaColorbutton = new System.Windows.Forms.Button();
            this.TransparentCheckBox = new System.Windows.Forms.CheckBox();
            this.BackColorButton = new System.Windows.Forms.Button();
            this.ForeColorButton = new System.Windows.Forms.Button();
            this.PreviewEditorPanel = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.SingleLineDownbutton = new System.Windows.Forms.Button();
            this.SingleLineUpbutton = new System.Windows.Forms.Button();
            this.SingleLineDeletebutton = new System.Windows.Forms.Button();
            this.SingleLineAddbutton = new System.Windows.Forms.Button();
            this.SingleLinelistView = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.SingleLinetextBox = new System.Windows.Forms.TextBox();
            this.SingleLineColorcomboBox = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.EncDownbutton = new System.Windows.Forms.Button();
            this.EncUpbutton = new System.Windows.Forms.Button();
            this.EnclistView = new System.Windows.Forms.ListView();
            this.EncStartcolumnHeader = new System.Windows.Forms.ColumnHeader();
            this.EncEndcolumnHeader = new System.Windows.Forms.ColumnHeader();
            this.EncColorcolumnHeader = new System.Windows.Forms.ColumnHeader();
            this.EncDeletebutton = new System.Windows.Forms.Button();
            this.EncAddbutton = new System.Windows.Forms.Button();
            this.EncStarttextBox = new System.Windows.Forms.TextBox();
            this.EncColorcomboBox = new System.Windows.Forms.ComboBox();
            this.EncEndtextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ThumbnailHnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ThumbnailWnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.listHeaderPatterntextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.linkPatterntextBox = new System.Windows.Forms.TextBox();
            this.DatePatterntextBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Cancelbutton = new System.Windows.Forms.Button();
            this.OKbutton = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailHnumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailWnumericUpDown)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(607, 473);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(599, 447);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "エディタ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(593, 441);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.tableLayoutPanel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(585, 415);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "表示";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(12, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(392, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.checkBox1);
            this.flowLayoutPanel1.Controls.Add(this.checkBox6);
            this.flowLayoutPanel1.Controls.Add(this.checkBox2);
            this.flowLayoutPanel1.Controls.Add(this.checkBox4);
            this.flowLayoutPanel1.Controls.Add(this.checkBox3);
            this.flowLayoutPanel1.Controls.Add(this.checkBox5);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 15);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(386, 82);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(3, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(46, 16);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "EOF";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(55, 3);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(45, 16);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.Text = "EOL";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(106, 3);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(83, 16);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "WhiteSpace";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(195, 3);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(102, 16);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "FullWidthSpace";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(303, 3);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(43, 16);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "Tab";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(3, 25);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(88, 16);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "Line Number";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.EditorFontInfoLabel, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.numericUpDown1, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 21);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(392, 56);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // EditorFontInfoLabel
            // 
            this.EditorFontInfoLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.EditorFontInfoLabel.AutoSize = true;
            this.EditorFontInfoLabel.Location = new System.Drawing.Point(58, 8);
            this.EditorFontInfoLabel.Name = "EditorFontInfoLabel";
            this.EditorFontInfoLabel.Size = new System.Drawing.Size(35, 12);
            this.EditorFontInfoLabel.TabIndex = 1;
            this.EditorFontInfoLabel.Text = "label2";
            this.EditorFontInfoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(360, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "Font";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tab num";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(58, 32);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 19);
            this.numericUpDown1.TabIndex = 5;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.SpecialCharaColorPanel);
            this.tabPage4.Controls.Add(this.SpecialCharaColorbutton);
            this.tabPage4.Controls.Add(this.TransparentCheckBox);
            this.tabPage4.Controls.Add(this.BackColorButton);
            this.tabPage4.Controls.Add(this.ForeColorButton);
            this.tabPage4.Controls.Add(this.PreviewEditorPanel);
            this.tabPage4.Controls.Add(this.listBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(585, 415);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "色";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // SpecialCharaColorPanel
            // 
            this.SpecialCharaColorPanel.Location = new System.Drawing.Point(317, 266);
            this.SpecialCharaColorPanel.Name = "SpecialCharaColorPanel";
            this.SpecialCharaColorPanel.Size = new System.Drawing.Size(74, 31);
            this.SpecialCharaColorPanel.TabIndex = 6;
            // 
            // SpecialCharaColorbutton
            // 
            this.SpecialCharaColorbutton.Location = new System.Drawing.Point(398, 266);
            this.SpecialCharaColorbutton.Name = "SpecialCharaColorbutton";
            this.SpecialCharaColorbutton.Size = new System.Drawing.Size(72, 32);
            this.SpecialCharaColorbutton.TabIndex = 5;
            this.SpecialCharaColorbutton.Text = "button2";
            this.SpecialCharaColorbutton.UseVisualStyleBackColor = true;
            // 
            // TransparentCheckBox
            // 
            this.TransparentCheckBox.AutoSize = true;
            this.TransparentCheckBox.Location = new System.Drawing.Point(398, 58);
            this.TransparentCheckBox.Name = "TransparentCheckBox";
            this.TransparentCheckBox.Size = new System.Drawing.Size(85, 16);
            this.TransparentCheckBox.TabIndex = 4;
            this.TransparentCheckBox.Text = "Transparent";
            this.TransparentCheckBox.UseVisualStyleBackColor = true;
            // 
            // BackColorButton
            // 
            this.BackColorButton.Location = new System.Drawing.Point(319, 53);
            this.BackColorButton.Name = "BackColorButton";
            this.BackColorButton.Size = new System.Drawing.Size(73, 29);
            this.BackColorButton.TabIndex = 3;
            this.BackColorButton.Text = "BackColor";
            this.BackColorButton.UseVisualStyleBackColor = true;
            // 
            // ForeColorButton
            // 
            this.ForeColorButton.Location = new System.Drawing.Point(320, 18);
            this.ForeColorButton.Name = "ForeColorButton";
            this.ForeColorButton.Size = new System.Drawing.Size(72, 29);
            this.ForeColorButton.TabIndex = 2;
            this.ForeColorButton.Text = "ForeColor";
            this.ForeColorButton.UseVisualStyleBackColor = true;
            // 
            // PreviewEditorPanel
            // 
            this.PreviewEditorPanel.Location = new System.Drawing.Point(18, 304);
            this.PreviewEditorPanel.Name = "PreviewEditorPanel";
            this.PreviewEditorPanel.Size = new System.Drawing.Size(283, 100);
            this.PreviewEditorPanel.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(18, 18);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(283, 280);
            this.listBox1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox3);
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(585, 415);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "コメント";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.SingleLineDownbutton);
            this.groupBox3.Controls.Add(this.SingleLineUpbutton);
            this.groupBox3.Controls.Add(this.SingleLineDeletebutton);
            this.groupBox3.Controls.Add(this.SingleLineAddbutton);
            this.groupBox3.Controls.Add(this.SingleLinelistView);
            this.groupBox3.Controls.Add(this.SingleLinetextBox);
            this.groupBox3.Controls.Add(this.SingleLineColorcomboBox);
            this.groupBox3.Location = new System.Drawing.Point(17, 216);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(549, 192);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // SingleLineDownbutton
            // 
            this.SingleLineDownbutton.Location = new System.Drawing.Point(278, 148);
            this.SingleLineDownbutton.Name = "SingleLineDownbutton";
            this.SingleLineDownbutton.Size = new System.Drawing.Size(63, 23);
            this.SingleLineDownbutton.TabIndex = 13;
            this.SingleLineDownbutton.Text = "Down";
            this.SingleLineDownbutton.UseVisualStyleBackColor = true;
            this.SingleLineDownbutton.Click += new System.EventHandler(this.SingleLineDownbutton_Click);
            // 
            // SingleLineUpbutton
            // 
            this.SingleLineUpbutton.Location = new System.Drawing.Point(278, 119);
            this.SingleLineUpbutton.Name = "SingleLineUpbutton";
            this.SingleLineUpbutton.Size = new System.Drawing.Size(63, 23);
            this.SingleLineUpbutton.TabIndex = 12;
            this.SingleLineUpbutton.Text = "Up";
            this.SingleLineUpbutton.UseVisualStyleBackColor = true;
            this.SingleLineUpbutton.Click += new System.EventHandler(this.SingleLineUpbutton_Click);
            // 
            // SingleLineDeletebutton
            // 
            this.SingleLineDeletebutton.Location = new System.Drawing.Point(347, 66);
            this.SingleLineDeletebutton.Name = "SingleLineDeletebutton";
            this.SingleLineDeletebutton.Size = new System.Drawing.Size(63, 24);
            this.SingleLineDeletebutton.TabIndex = 11;
            this.SingleLineDeletebutton.Text = "delete";
            this.SingleLineDeletebutton.UseVisualStyleBackColor = true;
            this.SingleLineDeletebutton.Click += new System.EventHandler(this.SingleLineDeletebutton_Click);
            // 
            // SingleLineAddbutton
            // 
            this.SingleLineAddbutton.Location = new System.Drawing.Point(278, 66);
            this.SingleLineAddbutton.Name = "SingleLineAddbutton";
            this.SingleLineAddbutton.Size = new System.Drawing.Size(63, 24);
            this.SingleLineAddbutton.TabIndex = 10;
            this.SingleLineAddbutton.Text = "add";
            this.SingleLineAddbutton.UseVisualStyleBackColor = true;
            this.SingleLineAddbutton.Click += new System.EventHandler(this.SingleLineAddbutton_Click);
            // 
            // SingleLinelistView
            // 
            this.SingleLinelistView.CheckBoxes = true;
            this.SingleLinelistView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader3});
            this.SingleLinelistView.FullRowSelect = true;
            this.SingleLinelistView.HideSelection = false;
            this.SingleLinelistView.Location = new System.Drawing.Point(6, 18);
            this.SingleLinelistView.MultiSelect = false;
            this.SingleLinelistView.Name = "SingleLinelistView";
            this.SingleLinelistView.Size = new System.Drawing.Size(266, 161);
            this.SingleLinelistView.TabIndex = 2;
            this.SingleLinelistView.UseCompatibleStateImageBehavior = false;
            this.SingleLinelistView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Start";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Color";
            this.columnHeader3.Width = 121;
            // 
            // SingleLinetextBox
            // 
            this.SingleLinetextBox.Location = new System.Drawing.Point(278, 41);
            this.SingleLinetextBox.Name = "SingleLinetextBox";
            this.SingleLinetextBox.Size = new System.Drawing.Size(63, 19);
            this.SingleLinetextBox.TabIndex = 3;
            // 
            // SingleLineColorcomboBox
            // 
            this.SingleLineColorcomboBox.FormattingEnabled = true;
            this.SingleLineColorcomboBox.Location = new System.Drawing.Point(347, 40);
            this.SingleLineColorcomboBox.Name = "SingleLineColorcomboBox";
            this.SingleLineColorcomboBox.Size = new System.Drawing.Size(120, 20);
            this.SingleLineColorcomboBox.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.EncDownbutton);
            this.groupBox2.Controls.Add(this.EncUpbutton);
            this.groupBox2.Controls.Add(this.EnclistView);
            this.groupBox2.Controls.Add(this.EncDeletebutton);
            this.groupBox2.Controls.Add(this.EncAddbutton);
            this.groupBox2.Controls.Add(this.EncStarttextBox);
            this.groupBox2.Controls.Add(this.EncColorcomboBox);
            this.groupBox2.Controls.Add(this.EncEndtextBox);
            this.groupBox2.Location = new System.Drawing.Point(17, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(549, 192);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // EncDownbutton
            // 
            this.EncDownbutton.Location = new System.Drawing.Point(278, 148);
            this.EncDownbutton.Name = "EncDownbutton";
            this.EncDownbutton.Size = new System.Drawing.Size(63, 23);
            this.EncDownbutton.TabIndex = 9;
            this.EncDownbutton.Text = "Down";
            this.EncDownbutton.UseVisualStyleBackColor = true;
            this.EncDownbutton.Click += new System.EventHandler(this.EncDownbutton_Click);
            // 
            // EncUpbutton
            // 
            this.EncUpbutton.Location = new System.Drawing.Point(278, 119);
            this.EncUpbutton.Name = "EncUpbutton";
            this.EncUpbutton.Size = new System.Drawing.Size(63, 23);
            this.EncUpbutton.TabIndex = 8;
            this.EncUpbutton.Text = "Up";
            this.EncUpbutton.UseVisualStyleBackColor = true;
            this.EncUpbutton.Click += new System.EventHandler(this.EncUpbutton_Click);
            // 
            // EnclistView
            // 
            this.EnclistView.CheckBoxes = true;
            this.EnclistView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.EncStartcolumnHeader,
            this.EncEndcolumnHeader,
            this.EncColorcolumnHeader});
            this.EnclistView.FullRowSelect = true;
            this.EnclistView.HideSelection = false;
            this.EnclistView.Location = new System.Drawing.Point(6, 18);
            this.EnclistView.MultiSelect = false;
            this.EnclistView.Name = "EnclistView";
            this.EnclistView.Size = new System.Drawing.Size(266, 161);
            this.EnclistView.TabIndex = 2;
            this.EnclistView.UseCompatibleStateImageBehavior = false;
            this.EnclistView.View = System.Windows.Forms.View.Details;
            // 
            // EncStartcolumnHeader
            // 
            this.EncStartcolumnHeader.Text = "Start";
            // 
            // EncEndcolumnHeader
            // 
            this.EncEndcolumnHeader.Text = "End";
            // 
            // EncColorcolumnHeader
            // 
            this.EncColorcolumnHeader.Text = "Color";
            this.EncColorcolumnHeader.Width = 121;
            // 
            // EncDeletebutton
            // 
            this.EncDeletebutton.Location = new System.Drawing.Point(347, 66);
            this.EncDeletebutton.Name = "EncDeletebutton";
            this.EncDeletebutton.Size = new System.Drawing.Size(63, 24);
            this.EncDeletebutton.TabIndex = 7;
            this.EncDeletebutton.Text = "delete";
            this.EncDeletebutton.UseVisualStyleBackColor = true;
            this.EncDeletebutton.Click += new System.EventHandler(this.EncDeletebutton_Click);
            // 
            // EncAddbutton
            // 
            this.EncAddbutton.Location = new System.Drawing.Point(278, 66);
            this.EncAddbutton.Name = "EncAddbutton";
            this.EncAddbutton.Size = new System.Drawing.Size(63, 24);
            this.EncAddbutton.TabIndex = 6;
            this.EncAddbutton.Text = "add";
            this.EncAddbutton.UseVisualStyleBackColor = true;
            this.EncAddbutton.Click += new System.EventHandler(this.EncAddbutton_Click);
            // 
            // EncStarttextBox
            // 
            this.EncStarttextBox.Location = new System.Drawing.Point(278, 41);
            this.EncStarttextBox.Name = "EncStarttextBox";
            this.EncStarttextBox.Size = new System.Drawing.Size(63, 19);
            this.EncStarttextBox.TabIndex = 3;
            // 
            // EncColorcomboBox
            // 
            this.EncColorcomboBox.FormattingEnabled = true;
            this.EncColorcomboBox.Location = new System.Drawing.Point(416, 41);
            this.EncColorcomboBox.Name = "EncColorcomboBox";
            this.EncColorcomboBox.Size = new System.Drawing.Size(120, 20);
            this.EncColorcomboBox.TabIndex = 5;
            // 
            // EncEndtextBox
            // 
            this.EncEndtextBox.Location = new System.Drawing.Point(347, 41);
            this.EncEndtextBox.Name = "EncEndtextBox";
            this.EncEndtextBox.Size = new System.Drawing.Size(63, 19);
            this.EncEndtextBox.TabIndex = 4;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(599, 447);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.ThumbnailHnumericUpDown);
            this.groupBox5.Controls.Add(this.ThumbnailWnumericUpDown);
            this.groupBox5.Location = new System.Drawing.Point(18, 202);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(267, 64);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Thumbnail Size";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(143, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "Height";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "Width";
            // 
            // ThumbnailHnumericUpDown
            // 
            this.ThumbnailHnumericUpDown.Location = new System.Drawing.Point(184, 25);
            this.ThumbnailHnumericUpDown.Name = "ThumbnailHnumericUpDown";
            this.ThumbnailHnumericUpDown.Size = new System.Drawing.Size(70, 19);
            this.ThumbnailHnumericUpDown.TabIndex = 4;
            // 
            // ThumbnailWnumericUpDown
            // 
            this.ThumbnailWnumericUpDown.Location = new System.Drawing.Point(51, 25);
            this.ThumbnailWnumericUpDown.Name = "ThumbnailWnumericUpDown";
            this.ThumbnailWnumericUpDown.Size = new System.Drawing.Size(70, 19);
            this.ThumbnailWnumericUpDown.TabIndex = 3;
            this.ThumbnailWnumericUpDown.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.listHeaderPatterntextBox);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.linkPatterntextBox);
            this.groupBox4.Controls.Add(this.DatePatterntextBox);
            this.groupBox4.Location = new System.Drawing.Point(18, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(462, 171);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Format";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(11, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(443, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "メモ連結表示のヘッダ(%id%=item id, %title%=item title, %date%=item  date)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(11, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "日付(defaut=yyyy/MM/dd hh:mmm)";
            // 
            // listHeaderPatterntextBox
            // 
            this.listHeaderPatterntextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.listHeaderPatterntextBox.Location = new System.Drawing.Point(13, 30);
            this.listHeaderPatterntextBox.Name = "listHeaderPatterntextBox";
            this.listHeaderPatterntextBox.Size = new System.Drawing.Size(177, 19);
            this.listHeaderPatterntextBox.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(11, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(359, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "リンク(%id%=item id, %title%=item title, %date%=item  date)";
            // 
            // linkPatterntextBox
            // 
            this.linkPatterntextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.linkPatterntextBox.Location = new System.Drawing.Point(13, 85);
            this.linkPatterntextBox.Name = "linkPatterntextBox";
            this.linkPatterntextBox.Size = new System.Drawing.Size(177, 19);
            this.linkPatterntextBox.TabIndex = 1;
            // 
            // DatePatterntextBox
            // 
            this.DatePatterntextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.DatePatterntextBox.Location = new System.Drawing.Point(13, 135);
            this.DatePatterntextBox.Name = "DatePatterntextBox";
            this.DatePatterntextBox.Size = new System.Drawing.Size(177, 19);
            this.DatePatterntextBox.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Cancelbutton);
            this.panel1.Controls.Add(this.OKbutton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 473);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(607, 32);
            this.panel1.TabIndex = 2;
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Cancelbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancelbutton.Location = new System.Drawing.Point(525, 6);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(75, 23);
            this.Cancelbutton.TabIndex = 1;
            this.Cancelbutton.Text = "Cancel";
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // OKbutton
            // 
            this.OKbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.OKbutton.Location = new System.Drawing.Point(444, 6);
            this.OKbutton.Name = "OKbutton";
            this.OKbutton.Size = new System.Drawing.Size(75, 23);
            this.OKbutton.TabIndex = 0;
            this.OKbutton.Text = "OK";
            this.OKbutton.UseVisualStyleBackColor = true;
            this.OKbutton.Click += new System.EventHandler(this.OKbutton_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader4});
            this.listView1.Location = new System.Drawing.Point(15, 18);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(236, 119);
            this.listView1.TabIndex = 10;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Width = 99;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Width = 102;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.button2);
            this.groupBox6.Controls.Add(this.textBox2);
            this.groupBox6.Controls.Add(this.textBox1);
            this.groupBox6.Controls.Add(this.listView1);
            this.groupBox6.Location = new System.Drawing.Point(15, 282);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(515, 152);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "groupBox6";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(257, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(124, 19);
            this.textBox1.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(387, 28);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(113, 19);
            this.textBox2.TabIndex = 12;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(257, 53);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(61, 32);
            this.button2.TabIndex = 13;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(324, 53);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(62, 32);
            this.button3.TabIndex = 14;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // ConfigForm
            // 
            this.AcceptButton = this.OKbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.Cancelbutton;
            this.ClientSize = new System.Drawing.Size(607, 505);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Name = "ConfigForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "オプション";
            this.Load += new System.EventHandler(this.ConfigForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailHnumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailWnumericUpDown)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label EditorFontInfoLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Cancelbutton;
        private System.Windows.Forms.Button OKbutton;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Panel PreviewEditorPanel;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox TransparentCheckBox;
        private System.Windows.Forms.Button BackColorButton;
        private System.Windows.Forms.Button ForeColorButton;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button SpecialCharaColorbutton;
        private System.Windows.Forms.Panel SpecialCharaColorPanel;
        private System.Windows.Forms.ComboBox EncColorcomboBox;
        private System.Windows.Forms.TextBox EncEndtextBox;
        private System.Windows.Forms.TextBox EncStarttextBox;
        private System.Windows.Forms.ListView EnclistView;
        private System.Windows.Forms.ColumnHeader EncStartcolumnHeader;
        private System.Windows.Forms.ColumnHeader EncEndcolumnHeader;
        private System.Windows.Forms.ColumnHeader EncColorcolumnHeader;
        private System.Windows.Forms.Button EncDeletebutton;
        private System.Windows.Forms.Button EncAddbutton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView SingleLinelistView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.TextBox SingleLinetextBox;
        private System.Windows.Forms.ComboBox SingleLineColorcomboBox;
        private System.Windows.Forms.TextBox listHeaderPatterntextBox;
        private System.Windows.Forms.TextBox linkPatterntextBox;
        private System.Windows.Forms.TextBox DatePatterntextBox;
        private System.Windows.Forms.NumericUpDown ThumbnailHnumericUpDown;
        private System.Windows.Forms.NumericUpDown ThumbnailWnumericUpDown;
        private System.Windows.Forms.Button EncDownbutton;
        private System.Windows.Forms.Button EncUpbutton;
        private System.Windows.Forms.Button SingleLineDownbutton;
        private System.Windows.Forms.Button SingleLineUpbutton;
        private System.Windows.Forms.Button SingleLineDeletebutton;
        private System.Windows.Forms.Button SingleLineAddbutton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }
}