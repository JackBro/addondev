﻿namespace WindowsFormsApplication1 {
    partial class ConfigForm {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent() {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.EditorFontInfoLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.DrawEOFcheckBox = new System.Windows.Forms.CheckBox();
            this.DrawEOLcheckBox = new System.Windows.Forms.CheckBox();
            this.DrawWhiteSpacecheckBox = new System.Windows.Forms.CheckBox();
            this.DrawFullWhiteSpacecheckBox = new System.Windows.Forms.CheckBox();
            this.DrawTabcheckBox = new System.Windows.Forms.CheckBox();
            this.DrawLineNumbercheckBox = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.TabNumnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.EditorFontbutton = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.EOLEOFColorpanel = new System.Windows.Forms.Panel();
            this.EOLEOFColorbutton = new System.Windows.Forms.Button();
            this.SpecialCharaColorPanel = new System.Windows.Forms.Panel();
            this.SpecialCharaColorbutton = new System.Windows.Forms.Button();
            this.TransparentCheckBox = new System.Windows.Forms.CheckBox();
            this.BackColorButton = new System.Windows.Forms.Button();
            this.ForeColorButton = new System.Windows.Forms.Button();
            this.PreviewEditorPanel = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.SingleLineDownbutton = new System.Windows.Forms.Button();
            this.SingleLineUpbutton = new System.Windows.Forms.Button();
            this.SingleLineDeletebutton = new System.Windows.Forms.Button();
            this.SingleLineAddbutton = new System.Windows.Forms.Button();
            this.SingleLinelistView = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.SingleLinetextBox = new System.Windows.Forms.TextBox();
            this.SingleLineColorcomboBox = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.EncDownbutton = new System.Windows.Forms.Button();
            this.EncUpbutton = new System.Windows.Forms.Button();
            this.EnclistView = new System.Windows.Forms.ListView();
            this.EncStartcolumnHeader = new System.Windows.Forms.ColumnHeader();
            this.EncEndcolumnHeader = new System.Windows.Forms.ColumnHeader();
            this.EncColorcolumnHeader = new System.Windows.Forms.ColumnHeader();
            this.EncDeletebutton = new System.Windows.Forms.Button();
            this.EncAddbutton = new System.Windows.Forms.Button();
            this.EncStarttextBox = new System.Windows.Forms.TextBox();
            this.EncColorcomboBox = new System.Windows.Forms.ComboBox();
            this.EncEndtextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.repDeletebutton = new System.Windows.Forms.Button();
            this.repAddbutton = new System.Windows.Forms.Button();
            this.repValuetextBox = new System.Windows.Forms.TextBox();
            this.repsymboltextBox = new System.Windows.Forms.TextBox();
            this.replistView = new System.Windows.Forms.ListView();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ThumbnailBackColorbutton = new System.Windows.Forms.Button();
            this.ThumbnailBackColorpanel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ThumbnailHnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ThumbnailWnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.listHeaderPatterntextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.linkPatterntextBox = new System.Windows.Forms.TextBox();
            this.DatePatterntextBox = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.FileListFontbutton = new System.Windows.Forms.Button();
            this.MemoListFontbutton = new System.Windows.Forms.Button();
            this.FileListFontlabel = new System.Windows.Forms.Label();
            this.MemoListFontlabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Cancelbutton = new System.Windows.Forms.Button();
            this.OKbutton = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TabNumnumericUpDown)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailHnumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailWnumericUpDown)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(607, 473);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(599, 448);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "エディタ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(593, 442);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.tableLayoutPanel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(585, 417);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "表示";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // EditorFontInfoLabel
            // 
            this.EditorFontInfoLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.EditorFontInfoLabel.AutoSize = true;
            this.EditorFontInfoLabel.Location = new System.Drawing.Point(58, 9);
            this.EditorFontInfoLabel.Name = "EditorFontInfoLabel";
            this.EditorFontInfoLabel.Size = new System.Drawing.Size(35, 12);
            this.EditorFontInfoLabel.TabIndex = 1;
            this.EditorFontInfoLabel.Text = "label2";
            this.EditorFontInfoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(9, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(392, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.DrawEOFcheckBox);
            this.flowLayoutPanel1.Controls.Add(this.DrawEOLcheckBox);
            this.flowLayoutPanel1.Controls.Add(this.DrawWhiteSpacecheckBox);
            this.flowLayoutPanel1.Controls.Add(this.DrawFullWhiteSpacecheckBox);
            this.flowLayoutPanel1.Controls.Add(this.DrawTabcheckBox);
            this.flowLayoutPanel1.Controls.Add(this.DrawLineNumbercheckBox);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 15);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(386, 82);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // DrawEOFcheckBox
            // 
            this.DrawEOFcheckBox.AutoSize = true;
            this.DrawEOFcheckBox.Location = new System.Drawing.Point(3, 3);
            this.DrawEOFcheckBox.Name = "DrawEOFcheckBox";
            this.DrawEOFcheckBox.Size = new System.Drawing.Size(46, 16);
            this.DrawEOFcheckBox.TabIndex = 0;
            this.DrawEOFcheckBox.Text = "EOF";
            this.DrawEOFcheckBox.UseVisualStyleBackColor = true;
            // 
            // DrawEOLcheckBox
            // 
            this.DrawEOLcheckBox.AutoSize = true;
            this.DrawEOLcheckBox.Location = new System.Drawing.Point(55, 3);
            this.DrawEOLcheckBox.Name = "DrawEOLcheckBox";
            this.DrawEOLcheckBox.Size = new System.Drawing.Size(45, 16);
            this.DrawEOLcheckBox.TabIndex = 5;
            this.DrawEOLcheckBox.Text = "EOL";
            this.DrawEOLcheckBox.UseVisualStyleBackColor = true;
            // 
            // DrawWhiteSpacecheckBox
            // 
            this.DrawWhiteSpacecheckBox.AutoSize = true;
            this.DrawWhiteSpacecheckBox.Location = new System.Drawing.Point(106, 3);
            this.DrawWhiteSpacecheckBox.Name = "DrawWhiteSpacecheckBox";
            this.DrawWhiteSpacecheckBox.Size = new System.Drawing.Size(83, 16);
            this.DrawWhiteSpacecheckBox.TabIndex = 1;
            this.DrawWhiteSpacecheckBox.Text = "WhiteSpace";
            this.DrawWhiteSpacecheckBox.UseVisualStyleBackColor = true;
            // 
            // DrawFullWhiteSpacecheckBox
            // 
            this.DrawFullWhiteSpacecheckBox.AutoSize = true;
            this.DrawFullWhiteSpacecheckBox.Location = new System.Drawing.Point(195, 3);
            this.DrawFullWhiteSpacecheckBox.Name = "DrawFullWhiteSpacecheckBox";
            this.DrawFullWhiteSpacecheckBox.Size = new System.Drawing.Size(102, 16);
            this.DrawFullWhiteSpacecheckBox.TabIndex = 3;
            this.DrawFullWhiteSpacecheckBox.Text = "FullWidthSpace";
            this.DrawFullWhiteSpacecheckBox.UseVisualStyleBackColor = true;
            // 
            // DrawTabcheckBox
            // 
            this.DrawTabcheckBox.AutoSize = true;
            this.DrawTabcheckBox.Location = new System.Drawing.Point(303, 3);
            this.DrawTabcheckBox.Name = "DrawTabcheckBox";
            this.DrawTabcheckBox.Size = new System.Drawing.Size(43, 16);
            this.DrawTabcheckBox.TabIndex = 2;
            this.DrawTabcheckBox.Text = "Tab";
            this.DrawTabcheckBox.UseVisualStyleBackColor = true;
            // 
            // DrawLineNumbercheckBox
            // 
            this.DrawLineNumbercheckBox.AutoSize = true;
            this.DrawLineNumbercheckBox.Location = new System.Drawing.Point(3, 25);
            this.DrawLineNumbercheckBox.Name = "DrawLineNumbercheckBox";
            this.DrawLineNumbercheckBox.Size = new System.Drawing.Size(88, 16);
            this.DrawLineNumbercheckBox.TabIndex = 4;
            this.DrawLineNumbercheckBox.Text = "Line Number";
            this.DrawLineNumbercheckBox.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.TabNumnumericUpDown, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.EditorFontInfoLabel, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.EditorFontbutton, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(9, 6);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(392, 55);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tab num";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TabNumnumericUpDown
            // 
            this.TabNumnumericUpDown.Location = new System.Drawing.Point(58, 33);
            this.TabNumnumericUpDown.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.TabNumnumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.TabNumnumericUpDown.Name = "TabNumnumericUpDown";
            this.TabNumnumericUpDown.Size = new System.Drawing.Size(119, 19);
            this.TabNumnumericUpDown.TabIndex = 5;
            this.TabNumnumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TabNumnumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // EditorFontbutton
            // 
            this.EditorFontbutton.Location = new System.Drawing.Point(3, 3);
            this.EditorFontbutton.Name = "EditorFontbutton";
            this.EditorFontbutton.Size = new System.Drawing.Size(49, 23);
            this.EditorFontbutton.TabIndex = 2;
            this.EditorFontbutton.Text = "フォント";
            this.EditorFontbutton.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.EOLEOFColorpanel);
            this.tabPage4.Controls.Add(this.EOLEOFColorbutton);
            this.tabPage4.Controls.Add(this.SpecialCharaColorPanel);
            this.tabPage4.Controls.Add(this.SpecialCharaColorbutton);
            this.tabPage4.Controls.Add(this.TransparentCheckBox);
            this.tabPage4.Controls.Add(this.BackColorButton);
            this.tabPage4.Controls.Add(this.ForeColorButton);
            this.tabPage4.Controls.Add(this.PreviewEditorPanel);
            this.tabPage4.Controls.Add(this.listBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(585, 416);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "色";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // EOLEOFColorpanel
            // 
            this.EOLEOFColorpanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.EOLEOFColorpanel.Location = new System.Drawing.Point(318, 267);
            this.EOLEOFColorpanel.Name = "EOLEOFColorpanel";
            this.EOLEOFColorpanel.Size = new System.Drawing.Size(74, 31);
            this.EOLEOFColorpanel.TabIndex = 8;
            // 
            // EOLEOFColorbutton
            // 
            this.EOLEOFColorbutton.AutoSize = true;
            this.EOLEOFColorbutton.Location = new System.Drawing.Point(398, 267);
            this.EOLEOFColorbutton.Name = "EOLEOFColorbutton";
            this.EOLEOFColorbutton.Size = new System.Drawing.Size(75, 32);
            this.EOLEOFColorbutton.TabIndex = 7;
            this.EOLEOFColorbutton.Text = "EOL,EOF色";
            this.EOLEOFColorbutton.UseVisualStyleBackColor = true;
            // 
            // SpecialCharaColorPanel
            // 
            this.SpecialCharaColorPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SpecialCharaColorPanel.Location = new System.Drawing.Point(318, 230);
            this.SpecialCharaColorPanel.Name = "SpecialCharaColorPanel";
            this.SpecialCharaColorPanel.Size = new System.Drawing.Size(74, 31);
            this.SpecialCharaColorPanel.TabIndex = 6;
            // 
            // SpecialCharaColorbutton
            // 
            this.SpecialCharaColorbutton.AutoSize = true;
            this.SpecialCharaColorbutton.Location = new System.Drawing.Point(398, 230);
            this.SpecialCharaColorbutton.Name = "SpecialCharaColorbutton";
            this.SpecialCharaColorbutton.Size = new System.Drawing.Size(75, 32);
            this.SpecialCharaColorbutton.TabIndex = 5;
            this.SpecialCharaColorbutton.Text = "特殊文字色";
            this.SpecialCharaColorbutton.UseVisualStyleBackColor = true;
            // 
            // TransparentCheckBox
            // 
            this.TransparentCheckBox.AutoSize = true;
            this.TransparentCheckBox.Location = new System.Drawing.Point(398, 58);
            this.TransparentCheckBox.Name = "TransparentCheckBox";
            this.TransparentCheckBox.Size = new System.Drawing.Size(67, 16);
            this.TransparentCheckBox.TabIndex = 4;
            this.TransparentCheckBox.Text = "透過する";
            this.TransparentCheckBox.UseVisualStyleBackColor = true;
            // 
            // BackColorButton
            // 
            this.BackColorButton.Location = new System.Drawing.Point(319, 53);
            this.BackColorButton.Name = "BackColorButton";
            this.BackColorButton.Size = new System.Drawing.Size(73, 29);
            this.BackColorButton.TabIndex = 3;
            this.BackColorButton.Text = "BackColor";
            this.BackColorButton.UseVisualStyleBackColor = true;
            // 
            // ForeColorButton
            // 
            this.ForeColorButton.Location = new System.Drawing.Point(320, 18);
            this.ForeColorButton.Name = "ForeColorButton";
            this.ForeColorButton.Size = new System.Drawing.Size(72, 29);
            this.ForeColorButton.TabIndex = 2;
            this.ForeColorButton.Text = "ForeColor";
            this.ForeColorButton.UseVisualStyleBackColor = true;
            // 
            // PreviewEditorPanel
            // 
            this.PreviewEditorPanel.Location = new System.Drawing.Point(18, 304);
            this.PreviewEditorPanel.Name = "PreviewEditorPanel";
            this.PreviewEditorPanel.Size = new System.Drawing.Size(283, 100);
            this.PreviewEditorPanel.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(18, 18);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(283, 280);
            this.listBox1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox3);
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 21);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(585, 416);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "コメント";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.SingleLineDownbutton);
            this.groupBox3.Controls.Add(this.SingleLineUpbutton);
            this.groupBox3.Controls.Add(this.SingleLineDeletebutton);
            this.groupBox3.Controls.Add(this.SingleLineAddbutton);
            this.groupBox3.Controls.Add(this.SingleLinelistView);
            this.groupBox3.Controls.Add(this.SingleLinetextBox);
            this.groupBox3.Controls.Add(this.SingleLineColorcomboBox);
            this.groupBox3.Location = new System.Drawing.Point(17, 216);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(549, 192);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // SingleLineDownbutton
            // 
            this.SingleLineDownbutton.Location = new System.Drawing.Point(278, 148);
            this.SingleLineDownbutton.Name = "SingleLineDownbutton";
            this.SingleLineDownbutton.Size = new System.Drawing.Size(63, 23);
            this.SingleLineDownbutton.TabIndex = 13;
            this.SingleLineDownbutton.Text = "Down";
            this.SingleLineDownbutton.UseVisualStyleBackColor = true;
            this.SingleLineDownbutton.Click += new System.EventHandler(this.SingleLineDownbutton_Click);
            // 
            // SingleLineUpbutton
            // 
            this.SingleLineUpbutton.Location = new System.Drawing.Point(278, 119);
            this.SingleLineUpbutton.Name = "SingleLineUpbutton";
            this.SingleLineUpbutton.Size = new System.Drawing.Size(63, 23);
            this.SingleLineUpbutton.TabIndex = 12;
            this.SingleLineUpbutton.Text = "Up";
            this.SingleLineUpbutton.UseVisualStyleBackColor = true;
            this.SingleLineUpbutton.Click += new System.EventHandler(this.SingleLineUpbutton_Click);
            // 
            // SingleLineDeletebutton
            // 
            this.SingleLineDeletebutton.Location = new System.Drawing.Point(347, 66);
            this.SingleLineDeletebutton.Name = "SingleLineDeletebutton";
            this.SingleLineDeletebutton.Size = new System.Drawing.Size(63, 24);
            this.SingleLineDeletebutton.TabIndex = 11;
            this.SingleLineDeletebutton.Text = "delete";
            this.SingleLineDeletebutton.UseVisualStyleBackColor = true;
            this.SingleLineDeletebutton.Click += new System.EventHandler(this.SingleLineDeletebutton_Click);
            // 
            // SingleLineAddbutton
            // 
            this.SingleLineAddbutton.Location = new System.Drawing.Point(278, 66);
            this.SingleLineAddbutton.Name = "SingleLineAddbutton";
            this.SingleLineAddbutton.Size = new System.Drawing.Size(63, 24);
            this.SingleLineAddbutton.TabIndex = 10;
            this.SingleLineAddbutton.Text = "add";
            this.SingleLineAddbutton.UseVisualStyleBackColor = true;
            this.SingleLineAddbutton.Click += new System.EventHandler(this.SingleLineAddbutton_Click);
            // 
            // SingleLinelistView
            // 
            this.SingleLinelistView.CheckBoxes = true;
            this.SingleLinelistView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader3});
            this.SingleLinelistView.FullRowSelect = true;
            this.SingleLinelistView.HideSelection = false;
            this.SingleLinelistView.Location = new System.Drawing.Point(6, 18);
            this.SingleLinelistView.MultiSelect = false;
            this.SingleLinelistView.Name = "SingleLinelistView";
            this.SingleLinelistView.Size = new System.Drawing.Size(266, 161);
            this.SingleLinelistView.TabIndex = 2;
            this.SingleLinelistView.UseCompatibleStateImageBehavior = false;
            this.SingleLinelistView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Start";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Color";
            this.columnHeader3.Width = 121;
            // 
            // SingleLinetextBox
            // 
            this.SingleLinetextBox.Location = new System.Drawing.Point(278, 41);
            this.SingleLinetextBox.Name = "SingleLinetextBox";
            this.SingleLinetextBox.Size = new System.Drawing.Size(63, 19);
            this.SingleLinetextBox.TabIndex = 3;
            // 
            // SingleLineColorcomboBox
            // 
            this.SingleLineColorcomboBox.FormattingEnabled = true;
            this.SingleLineColorcomboBox.Location = new System.Drawing.Point(347, 40);
            this.SingleLineColorcomboBox.Name = "SingleLineColorcomboBox";
            this.SingleLineColorcomboBox.Size = new System.Drawing.Size(120, 20);
            this.SingleLineColorcomboBox.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.EncDownbutton);
            this.groupBox2.Controls.Add(this.EncUpbutton);
            this.groupBox2.Controls.Add(this.EnclistView);
            this.groupBox2.Controls.Add(this.EncDeletebutton);
            this.groupBox2.Controls.Add(this.EncAddbutton);
            this.groupBox2.Controls.Add(this.EncStarttextBox);
            this.groupBox2.Controls.Add(this.EncColorcomboBox);
            this.groupBox2.Controls.Add(this.EncEndtextBox);
            this.groupBox2.Location = new System.Drawing.Point(17, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(549, 192);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // EncDownbutton
            // 
            this.EncDownbutton.Location = new System.Drawing.Point(278, 148);
            this.EncDownbutton.Name = "EncDownbutton";
            this.EncDownbutton.Size = new System.Drawing.Size(63, 23);
            this.EncDownbutton.TabIndex = 9;
            this.EncDownbutton.Text = "Down";
            this.EncDownbutton.UseVisualStyleBackColor = true;
            this.EncDownbutton.Click += new System.EventHandler(this.EncDownbutton_Click);
            // 
            // EncUpbutton
            // 
            this.EncUpbutton.Location = new System.Drawing.Point(278, 119);
            this.EncUpbutton.Name = "EncUpbutton";
            this.EncUpbutton.Size = new System.Drawing.Size(63, 23);
            this.EncUpbutton.TabIndex = 8;
            this.EncUpbutton.Text = "Up";
            this.EncUpbutton.UseVisualStyleBackColor = true;
            this.EncUpbutton.Click += new System.EventHandler(this.EncUpbutton_Click);
            // 
            // EnclistView
            // 
            this.EnclistView.CheckBoxes = true;
            this.EnclistView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.EncStartcolumnHeader,
            this.EncEndcolumnHeader,
            this.EncColorcolumnHeader});
            this.EnclistView.FullRowSelect = true;
            this.EnclistView.HideSelection = false;
            this.EnclistView.Location = new System.Drawing.Point(6, 18);
            this.EnclistView.MultiSelect = false;
            this.EnclistView.Name = "EnclistView";
            this.EnclistView.Size = new System.Drawing.Size(266, 161);
            this.EnclistView.TabIndex = 2;
            this.EnclistView.UseCompatibleStateImageBehavior = false;
            this.EnclistView.View = System.Windows.Forms.View.Details;
            // 
            // EncStartcolumnHeader
            // 
            this.EncStartcolumnHeader.Text = "Start";
            // 
            // EncEndcolumnHeader
            // 
            this.EncEndcolumnHeader.Text = "End";
            // 
            // EncColorcolumnHeader
            // 
            this.EncColorcolumnHeader.Text = "Color";
            this.EncColorcolumnHeader.Width = 121;
            // 
            // EncDeletebutton
            // 
            this.EncDeletebutton.Location = new System.Drawing.Point(347, 66);
            this.EncDeletebutton.Name = "EncDeletebutton";
            this.EncDeletebutton.Size = new System.Drawing.Size(63, 24);
            this.EncDeletebutton.TabIndex = 7;
            this.EncDeletebutton.Text = "delete";
            this.EncDeletebutton.UseVisualStyleBackColor = true;
            this.EncDeletebutton.Click += new System.EventHandler(this.EncDeletebutton_Click);
            // 
            // EncAddbutton
            // 
            this.EncAddbutton.Location = new System.Drawing.Point(278, 66);
            this.EncAddbutton.Name = "EncAddbutton";
            this.EncAddbutton.Size = new System.Drawing.Size(63, 24);
            this.EncAddbutton.TabIndex = 6;
            this.EncAddbutton.Text = "add";
            this.EncAddbutton.UseVisualStyleBackColor = true;
            this.EncAddbutton.Click += new System.EventHandler(this.EncAddbutton_Click);
            // 
            // EncStarttextBox
            // 
            this.EncStarttextBox.Location = new System.Drawing.Point(278, 41);
            this.EncStarttextBox.Name = "EncStarttextBox";
            this.EncStarttextBox.Size = new System.Drawing.Size(63, 19);
            this.EncStarttextBox.TabIndex = 3;
            // 
            // EncColorcomboBox
            // 
            this.EncColorcomboBox.FormattingEnabled = true;
            this.EncColorcomboBox.Location = new System.Drawing.Point(416, 41);
            this.EncColorcomboBox.Name = "EncColorcomboBox";
            this.EncColorcomboBox.Size = new System.Drawing.Size(120, 20);
            this.EncColorcomboBox.TabIndex = 5;
            // 
            // EncEndtextBox
            // 
            this.EncEndtextBox.Location = new System.Drawing.Point(347, 41);
            this.EncEndtextBox.Name = "EncEndtextBox";
            this.EncEndtextBox.Size = new System.Drawing.Size(63, 19);
            this.EncEndtextBox.TabIndex = 4;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(599, 448);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.repDeletebutton);
            this.groupBox6.Controls.Add(this.repAddbutton);
            this.groupBox6.Controls.Add(this.repValuetextBox);
            this.groupBox6.Controls.Add(this.repsymboltextBox);
            this.groupBox6.Controls.Add(this.replistView);
            this.groupBox6.Location = new System.Drawing.Point(15, 282);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(515, 152);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "groupBox6";
            // 
            // repDeletebutton
            // 
            this.repDeletebutton.Location = new System.Drawing.Point(324, 53);
            this.repDeletebutton.Name = "repDeletebutton";
            this.repDeletebutton.Size = new System.Drawing.Size(62, 32);
            this.repDeletebutton.TabIndex = 14;
            this.repDeletebutton.Text = "削除";
            this.repDeletebutton.UseVisualStyleBackColor = true;
            this.repDeletebutton.Click += new System.EventHandler(this.repDeletebutton_Click);
            // 
            // repAddbutton
            // 
            this.repAddbutton.Location = new System.Drawing.Point(257, 53);
            this.repAddbutton.Name = "repAddbutton";
            this.repAddbutton.Size = new System.Drawing.Size(61, 32);
            this.repAddbutton.TabIndex = 13;
            this.repAddbutton.Text = "追加";
            this.repAddbutton.UseVisualStyleBackColor = true;
            this.repAddbutton.Click += new System.EventHandler(this.repAddbutton_Click);
            // 
            // repValuetextBox
            // 
            this.repValuetextBox.Location = new System.Drawing.Point(387, 28);
            this.repValuetextBox.Name = "repValuetextBox";
            this.repValuetextBox.Size = new System.Drawing.Size(113, 19);
            this.repValuetextBox.TabIndex = 12;
            // 
            // repsymboltextBox
            // 
            this.repsymboltextBox.Location = new System.Drawing.Point(257, 28);
            this.repsymboltextBox.Name = "repsymboltextBox";
            this.repsymboltextBox.Size = new System.Drawing.Size(124, 19);
            this.repsymboltextBox.TabIndex = 11;
            // 
            // replistView
            // 
            this.replistView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader4});
            this.replistView.Location = new System.Drawing.Point(15, 18);
            this.replistView.Name = "replistView";
            this.replistView.Size = new System.Drawing.Size(236, 119);
            this.replistView.TabIndex = 10;
            this.replistView.UseCompatibleStateImageBehavior = false;
            this.replistView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Width = 99;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Width = 102;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ThumbnailBackColorbutton);
            this.groupBox5.Controls.Add(this.ThumbnailBackColorpanel);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.ThumbnailHnumericUpDown);
            this.groupBox5.Controls.Add(this.ThumbnailWnumericUpDown);
            this.groupBox5.Location = new System.Drawing.Point(18, 203);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(463, 64);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Thumbnail";
            // 
            // ThumbnailBackColorbutton
            // 
            this.ThumbnailBackColorbutton.Location = new System.Drawing.Point(367, 25);
            this.ThumbnailBackColorbutton.Name = "ThumbnailBackColorbutton";
            this.ThumbnailBackColorbutton.Size = new System.Drawing.Size(55, 19);
            this.ThumbnailBackColorbutton.TabIndex = 8;
            this.ThumbnailBackColorbutton.Text = "背景色";
            this.ThumbnailBackColorbutton.UseVisualStyleBackColor = true;
            this.ThumbnailBackColorbutton.Click += new System.EventHandler(this.ThumbnailBackColorbutton_Click);
            // 
            // ThumbnailBackColorpanel
            // 
            this.ThumbnailBackColorpanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ThumbnailBackColorpanel.Location = new System.Drawing.Point(284, 25);
            this.ThumbnailBackColorpanel.Name = "ThumbnailBackColorpanel";
            this.ThumbnailBackColorpanel.Size = new System.Drawing.Size(69, 19);
            this.ThumbnailBackColorpanel.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(143, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "Height";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "Width";
            // 
            // ThumbnailHnumericUpDown
            // 
            this.ThumbnailHnumericUpDown.Location = new System.Drawing.Point(184, 25);
            this.ThumbnailHnumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ThumbnailHnumericUpDown.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ThumbnailHnumericUpDown.Name = "ThumbnailHnumericUpDown";
            this.ThumbnailHnumericUpDown.Size = new System.Drawing.Size(70, 19);
            this.ThumbnailHnumericUpDown.TabIndex = 4;
            this.ThumbnailHnumericUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // ThumbnailWnumericUpDown
            // 
            this.ThumbnailWnumericUpDown.Location = new System.Drawing.Point(51, 25);
            this.ThumbnailWnumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ThumbnailWnumericUpDown.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ThumbnailWnumericUpDown.Name = "ThumbnailWnumericUpDown";
            this.ThumbnailWnumericUpDown.Size = new System.Drawing.Size(70, 19);
            this.ThumbnailWnumericUpDown.TabIndex = 3;
            this.ThumbnailWnumericUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ThumbnailWnumericUpDown.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.listHeaderPatterntextBox);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.linkPatterntextBox);
            this.groupBox4.Controls.Add(this.DatePatterntextBox);
            this.groupBox4.Location = new System.Drawing.Point(18, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(463, 171);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Format";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(11, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(443, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "メモ連結表示のヘッダ(%id%=item id, %title%=item title, %date%=item  date)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(11, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "日付(defaut=yyyy/MM/dd hh:mmm)";
            // 
            // listHeaderPatterntextBox
            // 
            this.listHeaderPatterntextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.listHeaderPatterntextBox.Location = new System.Drawing.Point(13, 39);
            this.listHeaderPatterntextBox.Name = "listHeaderPatterntextBox";
            this.listHeaderPatterntextBox.Size = new System.Drawing.Size(177, 19);
            this.listHeaderPatterntextBox.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(11, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(359, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "リンク(%id%=item id, %title%=item title, %date%=item  date)";
            // 
            // linkPatterntextBox
            // 
            this.linkPatterntextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.linkPatterntextBox.Location = new System.Drawing.Point(13, 85);
            this.linkPatterntextBox.Name = "linkPatterntextBox";
            this.linkPatterntextBox.Size = new System.Drawing.Size(177, 19);
            this.linkPatterntextBox.TabIndex = 1;
            // 
            // DatePatterntextBox
            // 
            this.DatePatterntextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.DatePatterntextBox.Location = new System.Drawing.Point(13, 135);
            this.DatePatterntextBox.Name = "DatePatterntextBox";
            this.DatePatterntextBox.Size = new System.Drawing.Size(177, 19);
            this.DatePatterntextBox.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tableLayoutPanel2);
            this.tabPage6.Location = new System.Drawing.Point(4, 21);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(599, 448);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.FileListFontbutton, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.MemoListFontbutton, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.FileListFontlabel, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.MemoListFontlabel, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(17, 20);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(565, 60);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // FileListFontbutton
            // 
            this.FileListFontbutton.Location = new System.Drawing.Point(3, 3);
            this.FileListFontbutton.Name = "FileListFontbutton";
            this.FileListFontbutton.Size = new System.Drawing.Size(75, 23);
            this.FileListFontbutton.TabIndex = 0;
            this.FileListFontbutton.Text = "ファイルリスト";
            this.FileListFontbutton.UseVisualStyleBackColor = true;
            // 
            // MemoListFontbutton
            // 
            this.MemoListFontbutton.Location = new System.Drawing.Point(3, 32);
            this.MemoListFontbutton.Name = "MemoListFontbutton";
            this.MemoListFontbutton.Size = new System.Drawing.Size(75, 23);
            this.MemoListFontbutton.TabIndex = 1;
            this.MemoListFontbutton.Text = "メモリスト";
            this.MemoListFontbutton.UseVisualStyleBackColor = true;
            // 
            // FileListFontlabel
            // 
            this.FileListFontlabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.FileListFontlabel.AutoSize = true;
            this.FileListFontlabel.Location = new System.Drawing.Point(84, 0);
            this.FileListFontlabel.Name = "FileListFontlabel";
            this.FileListFontlabel.Size = new System.Drawing.Size(35, 29);
            this.FileListFontlabel.TabIndex = 2;
            this.FileListFontlabel.Text = "label8";
            this.FileListFontlabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MemoListFontlabel
            // 
            this.MemoListFontlabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.MemoListFontlabel.AutoSize = true;
            this.MemoListFontlabel.Location = new System.Drawing.Point(84, 29);
            this.MemoListFontlabel.Name = "MemoListFontlabel";
            this.MemoListFontlabel.Size = new System.Drawing.Size(35, 31);
            this.MemoListFontlabel.TabIndex = 3;
            this.MemoListFontlabel.Text = "label9";
            this.MemoListFontlabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Cancelbutton);
            this.panel1.Controls.Add(this.OKbutton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 473);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(607, 32);
            this.panel1.TabIndex = 2;
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Cancelbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancelbutton.Location = new System.Drawing.Point(525, 6);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(75, 23);
            this.Cancelbutton.TabIndex = 1;
            this.Cancelbutton.Text = "Cancel";
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // OKbutton
            // 
            this.OKbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.OKbutton.Location = new System.Drawing.Point(444, 6);
            this.OKbutton.Name = "OKbutton";
            this.OKbutton.Size = new System.Drawing.Size(75, 23);
            this.OKbutton.TabIndex = 0;
            this.OKbutton.Text = "OK";
            this.OKbutton.UseVisualStyleBackColor = true;
            this.OKbutton.Click += new System.EventHandler(this.OKbutton_Click);
            // 
            // ConfigForm
            // 
            this.AcceptButton = this.OKbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.Cancelbutton;
            this.ClientSize = new System.Drawing.Size(607, 505);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Name = "ConfigForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "オプション";
            this.Load += new System.EventHandler(this.ConfigForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TabNumnumericUpDown)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailHnumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThumbnailWnumericUpDown)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label EditorFontInfoLabel;
        private System.Windows.Forms.Button EditorFontbutton;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.CheckBox DrawEOFcheckBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown TabNumnumericUpDown;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Cancelbutton;
        private System.Windows.Forms.Button OKbutton;
        private System.Windows.Forms.CheckBox DrawWhiteSpacecheckBox;
        private System.Windows.Forms.CheckBox DrawTabcheckBox;
        private System.Windows.Forms.Panel PreviewEditorPanel;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.CheckBox DrawFullWhiteSpacecheckBox;
        private System.Windows.Forms.CheckBox DrawLineNumbercheckBox;
        private System.Windows.Forms.CheckBox DrawEOLcheckBox;
        private System.Windows.Forms.CheckBox TransparentCheckBox;
        private System.Windows.Forms.Button BackColorButton;
        private System.Windows.Forms.Button ForeColorButton;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button SpecialCharaColorbutton;
        private System.Windows.Forms.Panel SpecialCharaColorPanel;
        private System.Windows.Forms.ComboBox EncColorcomboBox;
        private System.Windows.Forms.TextBox EncEndtextBox;
        private System.Windows.Forms.TextBox EncStarttextBox;
        private System.Windows.Forms.ListView EnclistView;
        private System.Windows.Forms.ColumnHeader EncStartcolumnHeader;
        private System.Windows.Forms.ColumnHeader EncEndcolumnHeader;
        private System.Windows.Forms.ColumnHeader EncColorcolumnHeader;
        private System.Windows.Forms.Button EncDeletebutton;
        private System.Windows.Forms.Button EncAddbutton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView SingleLinelistView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.TextBox SingleLinetextBox;
        private System.Windows.Forms.ComboBox SingleLineColorcomboBox;
        private System.Windows.Forms.TextBox listHeaderPatterntextBox;
        private System.Windows.Forms.TextBox linkPatterntextBox;
        private System.Windows.Forms.TextBox DatePatterntextBox;
        private System.Windows.Forms.NumericUpDown ThumbnailHnumericUpDown;
        private System.Windows.Forms.NumericUpDown ThumbnailWnumericUpDown;
        private System.Windows.Forms.Button EncDownbutton;
        private System.Windows.Forms.Button EncUpbutton;
        private System.Windows.Forms.Button SingleLineDownbutton;
        private System.Windows.Forms.Button SingleLineUpbutton;
        private System.Windows.Forms.Button SingleLineDeletebutton;
        private System.Windows.Forms.Button SingleLineAddbutton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListView replistView;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button repDeletebutton;
        private System.Windows.Forms.Button repAddbutton;
        private System.Windows.Forms.TextBox repValuetextBox;
        private System.Windows.Forms.TextBox repsymboltextBox;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button FileListFontbutton;
        private System.Windows.Forms.Button MemoListFontbutton;
        private System.Windows.Forms.Label FileListFontlabel;
        private System.Windows.Forms.Label MemoListFontlabel;
        private System.Windows.Forms.Panel EOLEOFColorpanel;
        private System.Windows.Forms.Button EOLEOFColorbutton;
        private System.Windows.Forms.Button ThumbnailBackColorbutton;
        private System.Windows.Forms.Panel ThumbnailBackColorpanel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}