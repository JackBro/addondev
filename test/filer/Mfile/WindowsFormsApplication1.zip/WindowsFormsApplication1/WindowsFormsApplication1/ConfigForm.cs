﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Sgry.Azuki;
using Sgry.Azuki.WinForms;

namespace WindowsFormsApplication1 {

    public partial class ConfigForm : Form {
        Dictionary<CharClass, EditorColor> editorcolors;
        AzukiControl previeweditor;

        Config _config;
        Font editorFont;

        public ColorScheme getColorScheme()
        {
            var cs = ColorScheme.Default;
            foreach (var key in editorcolors.Keys)
            {
                cs.SetColor(key, editorcolors[key].ForeColor, editorcolors[key].BackColor);
            }
            return cs;
        }

        public ConfigForm(Config config) {
            _config = config;
            InitializeComponent();
            this.FormClosing += (s,e) => {
                if (editorFont != null) {
                    editorFont.Dispose();
                }
            };
           
            previeweditor=new AzukiControl();
            previeweditor.IsReadOnly = true;
            previeweditor.DrawingOption = DrawingOption.DrawsEof | DrawingOption.DrawsEol | DrawingOption.DrawsFullWidthSpace
                | DrawingOption.DrawsSpace | DrawingOption.DrawsTab;
            previeweditor.Text = @"abc ABC +-=;:[]<>/?_^\|!""#$%&'()
" + "\t　file://test";
            previeweditor.ShowsHScrollBar = false;
            previeweditor.Dock = DockStyle.Fill;
            PreviewEditorPanel.AutoScroll = false;
            PreviewEditorPanel.Controls.Add(previeweditor);

            //editor font
            EditorFontInfoLabel.Text = config.editorconfig.FontName + " " + config.editorconfig.FontSize.ToString();
            button1.Click+=(s,e)=>{
                //ColorDialog cd = new ColorDialog();
                //cd.ShowDialog();

                FontDialog fd = new FontDialog();

                fd.Font =new Font(config.editorconfig.FontName, config.editorconfig.FontSize);
                var ret = fd.ShowDialog();
                if (ret == DialogResult.OK) {
                    editorFont = fd.Font;
                    EditorFontInfoLabel.Text = fd.Font.Name + " " + fd.Font.Size.ToString();
                    //Font h = new Font(
                    //editorFont = new FontInfo(fd.Font);
                }
            };

            editorcolors = new Dictionary<CharClass, EditorColor>();
            config.editorconfig.colors.ForEach(x => {
                editorcolors.Add(x.cc, new EditorColor() { cc = x.cc, ForeColor = x.ForeColor, BackColor = x.BackColor });
                listBox1.Items.Add(x.cc);
            });

            bool ch = false;
            //listBox1.Items.Add(CharClass.Value);
            listBox1.SelectedIndexChanged += (s, e) =>
            {
                CharClass cc = (CharClass)(listBox1.SelectedItem);
                previeweditor.ForeColor = editorcolors[cc].ForeColor;
                ch = false;
                if (cc == CharClass.Normal)
                {
                    TransparentCheckBox.Enabled = false;
                    previeweditor.BackColor = editorcolors[cc].BackColor;
                }
                else
                {
                    TransparentCheckBox.Enabled = true;

                    if (editorcolors[cc].BackColor == Color.Transparent)
                    {
                        TransparentCheckBox.Checked = true;
                        previeweditor.BackColor = editorcolors[CharClass.Normal].BackColor;
                    }
                    else
                    {
                        TransparentCheckBox.Checked = false;
                        previeweditor.BackColor = editorcolors[cc].BackColor;
                    }
                }
                ch = true;

                previeweditor.Refresh();
            };
            ForeColorButton.Click += (s, e) =>
            {
                var cd = new ColorDialog();
                var ret = cd.ShowDialog();
                if (ret == DialogResult.OK)
                {
                    CharClass cc = (CharClass)(listBox1.SelectedItem);
                    setColor(cc, cd.Color, editorcolors[cc].BackColor);
                }
            };
            BackColorButton.Click += (s, e) =>
            {
                var cd = new ColorDialog();
                var ret = cd.ShowDialog();
                if (ret == DialogResult.OK)
                {
                    CharClass cc = (CharClass)(listBox1.SelectedItem);
                    setColor(cc, editorcolors[cc].ForeColor, cd.Color);

                    ch = false;
                    TransparentCheckBox.Checked = false;
                    ch = true;
                }
            };
            TransparentCheckBox.CheckedChanged += (s, e) =>
            {
                if (!ch) return;
                CharClass cc = (CharClass)(listBox1.SelectedItem);
                var ec = editorcolors[cc];
                if (TransparentCheckBox.Checked)
                {
                    setColor(cc, ec.ForeColor, Color.Transparent);
                }
                else
                {
                    setColor(cc, ec.ForeColor, ec.BackColor);
                }
            };

            SpecialCharaColorbutton.Click += (s, e) => {
                ColorDialog cd = new ColorDialog();
                var ret = cd.ShowDialog();
                if (ret == DialogResult.OK) {
                    var c = cd.Color;
                    SpecialCharaColorPanel.BackColor = c;
                    previeweditor.ColorScheme.EofColor= c;
                    previeweditor.ColorScheme.EolColor = c;
                    previeweditor.ColorScheme.WhiteSpaceColor = c;
                    previeweditor.Refresh();
                }
            };

            //enc
            foreach (CharClass cc in Enum.GetValues(typeof(CharClass))) {
                EncColorcomboBox.Items.Add(cc);
                SingleLineColorcomboBox.Items.Add(cc);
            }

            for (int i = 0; i < _config.editorconfig.enclosurs.Count; i++)
            {
                var enc = _config.editorconfig.enclosurs[i];
                var item = new ListViewItem(new string[]{enc.start, enc.end, enc.cc.ToString()});
                EnclistView.Items.Add(item);       
            }
            EnclistView.ItemSelectionChanged += (s, e) => {
                if (e.IsSelected) {
                    EncStarttextBox.Text = e.Item.SubItems[0].Text;
                    EncEndtextBox.Text = e.Item.SubItems[1].Text;
                    EncColorcomboBox.SelectedItem = Enum.Parse(typeof(CharClass), e.Item.SubItems[2].Text);
                }
            };
            EncStarttextBox.TextChanged += (s, e) => {
                if (EnclistView.SelectedItems.Count == 1) {
                    var item = EnclistView.SelectedItems[0];
                    item.SubItems[0].Text = EncStarttextBox.Text;
                }
            };
            EncEndtextBox.TextChanged += (s, e) => {
                if (EnclistView.SelectedItems.Count == 1) {
                    var item = EnclistView.SelectedItems[0];
                    item.SubItems[1].Text = EncEndtextBox.Text;
                }
            };
            EncColorcomboBox.SelectionChangeCommitted += (s, e) => {
                if (EnclistView.SelectedItems.Count == 1) {
                    var item = EnclistView.SelectedItems[0];
                    item.SubItems[2].Text = EncColorcomboBox.Text;
                }
            };

            for (int i = 0; i < _config.editorconfig.singleLines.Count; i++) {
                var single = _config.editorconfig.singleLines[i];
                var item = new ListViewItem(new string[] { single.start, single.cc.ToString() });
                SingleLinelistView.Items.Add(item);
            }
            SingleLinelistView.ItemSelectionChanged += (s, e) => {
                if (e.IsSelected) {
                    SingleLinetextBox.Text = e.Item.SubItems[0].Text;
                    SingleLineColorcomboBox.SelectedItem = Enum.Parse(typeof(CharClass), e.Item.SubItems[1].Text);
                }
            };
            SingleLinetextBox.TextChanged += (s, e) => {
                if (SingleLinelistView.SelectedItems.Count == 1) {
                    var item = SingleLinelistView.SelectedItems[0];
                    item.SubItems[0].Text = SingleLinetextBox.Text;
                }
            };
            SingleLineColorcomboBox.SelectionChangeCommitted += (s, e) => {
                if (SingleLinelistView.SelectedItems.Count == 1) {
                    var item = SingleLinelistView.SelectedItems[0];
                    item.SubItems[1].Text = SingleLineColorcomboBox.Text;
                }
            };

            listHeaderPatterntextBox.Text = config.ListHeaderPattern;
            linkPatterntextBox.Text = config.LinkPattern;
            DatePatterntextBox.Text = config.DatePattern;

            ThumbnailWnumericUpDown.Value = config.ThumbnailSize.Width;
            ThumbnailHnumericUpDown.Value = config.ThumbnailSize.Height;
        }

        private void setColor(CharClass cc, Color fore, Color back)
        {
            editorcolors[cc].ForeColor = fore;
            editorcolors[cc].BackColor = back;
            
            previeweditor.ForeColor = editorcolors[cc].ForeColor;

            if (cc == CharClass.Normal)
            {
                previeweditor.BackColor = editorcolors[cc].BackColor;
            }
            else
            {
                if (editorcolors[cc].BackColor == Color.Transparent)
                {

                    previeweditor.BackColor = editorcolors[CharClass.Normal].BackColor;
                }
                else
                {
                    previeweditor.BackColor = editorcolors[cc].BackColor;
                }
            }

            previeweditor.Refresh();
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            if (editorFont != null) {
                _config.editorconfig.FontName = editorFont.Name;
                _config.editorconfig.FontSize = editorFont.Size;
            }

            _config.editorconfig.enclosurs.Clear();
            var encs = _config.editorconfig.enclosurs;
            for (int i = 0; i < EnclistView.Items.Count; i++) {
                var item = EnclistView.Items[i];
                var start = item.SubItems[0].Text;
                var end = item.SubItems[1].Text;
                var cc = (CharClass)Enum.Parse(typeof(CharClass), item.SubItems[2].Text);
                if (start.Length > 0 && end.Length > 0 ) {
                    encs.Add(new Enclosur() { start = start, end = end, cc = cc });
                }
            }

            _config.editorconfig.singleLines.Clear();
            var single = _config.editorconfig.singleLines;
            for (int i = 0; i < SingleLinelistView.Items.Count; i++) {
                var item = SingleLinelistView.Items[i];
                var start = item.SubItems[0].Text;
                var cc = (CharClass)Enum.Parse(typeof(CharClass), item.SubItems[1].Text);
                if (start.Length > 0) {
                    single.Add(new SingleLine() { start = start, cc = cc });
                }
            }

            _config.ThumbnailSize = new Size(int.Parse(ThumbnailWnumericUpDown.Value.ToString())
                , int.Parse(ThumbnailHnumericUpDown.Value.ToString()));
        }

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ConfigForm_Load(object sender, EventArgs e)
        {

        }

        private void EncAddbutton_Click(object sender, EventArgs e) {
            EnclistView.Items.Add(new ListViewItem(new string[] { EncStarttextBox.Text, EncEndtextBox.Text, EncColorcomboBox.Text}));   
        }

        private void EncDeletebutton_Click(object sender, EventArgs e) {
            if (EnclistView.SelectedItems.Count == 1) {
                EnclistView.Items.Remove(EnclistView.SelectedItems[0]);
            }
        }

        private void EncUpbutton_Click(object sender, EventArgs e) {
            if (EnclistView.SelectedItems.Count == 1 && EnclistView.SelectedItems[0].Index > 0) {
                var item = EnclistView.SelectedItems[0];
                var index = EnclistView.SelectedItems[0].Index ;
                EnclistView.Items.Remove(item);
                EnclistView.Items.Insert(index - 1, item);
                item.Selected = true;
            }
        }

        private void EncDownbutton_Click(object sender, EventArgs e) {
            if (EnclistView.SelectedItems.Count == 1 && EnclistView.SelectedItems[0].Index < EnclistView.SelectedItems.Count) {
                var item = EnclistView.SelectedItems[0];
                var index = EnclistView.SelectedItems[0].Index;
                EnclistView.Items.Remove(item);
                EnclistView.Items.Insert(index + 1, item);
                item.Selected = true;
            }
        }

        private void SingleLineAddbutton_Click(object sender, EventArgs e) {
            SingleLinelistView.Items.Add(new ListViewItem(new string[] { SingleLinetextBox.Text, SingleLineColorcomboBox.Text }));   
        }

        private void SingleLineDeletebutton_Click(object sender, EventArgs e) {
            if (SingleLinelistView.SelectedItems.Count == 1) {
                SingleLinelistView.Items.Remove(SingleLinelistView.SelectedItems[0]);
            }
        }

        private void SingleLineUpbutton_Click(object sender, EventArgs e) {
            if (SingleLinelistView.SelectedItems.Count == 1 && SingleLinelistView.SelectedItems[0].Index > 0) {
                var item = SingleLinelistView.SelectedItems[0];
                var index = SingleLinelistView.SelectedItems[0].Index;
                SingleLinelistView.Items.Remove(item);
                SingleLinelistView.Items.Insert(index - 1, item);
                item.Selected = true;
            }
        }

        private void SingleLineDownbutton_Click(object sender, EventArgs e) {
            if (SingleLinelistView.SelectedItems.Count == 1 && SingleLinelistView.SelectedItems[0].Index < SingleLinelistView.SelectedItems.Count) {
                var item = SingleLinelistView.SelectedItems[0];
                var index = SingleLinelistView.SelectedItems[0].Index;
                SingleLinelistView.Items.Remove(item);
                SingleLinelistView.Items.Insert(index + 1, item);
                item.Selected = true;
            }
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e) {

        }
    }
}
