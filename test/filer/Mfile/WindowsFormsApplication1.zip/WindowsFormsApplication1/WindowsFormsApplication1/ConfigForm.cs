﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Sgry.Azuki;
using Sgry.Azuki.WinForms;

namespace WindowsFormsApplication1 {

    public partial class ConfigForm : Form {
        Dictionary<CharClass, EditorColor> editorcolors;
        AzukiControl previeweditor;

        class EnclosurControl
        {
            public TextBox start;
            public TextBox end;
            public ComboBox cc;
        }

        Config _config;
        List<EnclosurControl> enclist = new List<EnclosurControl>();
        public ColorScheme getColorScheme()
        {
            var cs = ColorScheme.Default;
            foreach (var key in editorcolors.Keys)
            {
                cs.SetColor(key, editorcolors[key].ForeColor, editorcolors[key].BackColor);
            }
            return cs;
        }

        public ConfigForm(Config config) {
            _config = config;
            InitializeComponent();

           
            previeweditor=new AzukiControl();
            previeweditor.IsReadOnly = true;
            previeweditor.Text = @"abc ABC +-=;:[]<>/?_^\|!""#$%&'()";
            previeweditor.Dock = DockStyle.Fill;
            PreviewEditorPanel.Controls.Add(previeweditor);


            button1.Click+=(s,e)=>{
                ColorDialog cd = new ColorDialog();
                cd.ShowDialog();

                //FontDialog fd = new FontDialog();
                //var ret = fd.ShowDialog();
                //if (ret == DialogResult.OK) {
                //    var font = fd.Font;
                //    FontNameLabel.Text = font.FontFamily.Name;
                //}
            };

            editorcolors = new Dictionary<CharClass, EditorColor>();
            config.editorconfig.colors.ForEach(x => {
                editorcolors.Add(x.cc, new EditorColor() { cc = x.cc, ForeColor = x.ForeColor, BackColor = x.BackColor });
                listBox1.Items.Add(x.cc);
            });

            bool ch = false;
            //listBox1.Items.Add(CharClass.Value);
            listBox1.SelectedIndexChanged += (s, e) =>
            {
                CharClass cc = (CharClass)(listBox1.SelectedItem);
                previeweditor.ForeColor = editorcolors[cc].ForeColor;
                ch = false;
                if (cc == CharClass.Normal)
                {
                    TransparentCheckBox.Enabled = false;
                    previeweditor.BackColor = editorcolors[cc].BackColor;
                }
                else
                {
                    TransparentCheckBox.Enabled = true;

                    if (editorcolors[cc].BackColor == Color.Transparent)
                    {
                        TransparentCheckBox.Checked = true;
                        previeweditor.BackColor = editorcolors[CharClass.Normal].BackColor;
                    }
                    else
                    {
                        TransparentCheckBox.Checked = false;
                        previeweditor.BackColor = editorcolors[cc].BackColor;
                    }
                }
                ch = true;

                previeweditor.Refresh();
            };
            ForeColorButton.Click += (s, e) =>
            {
                var cd = new ColorDialog();
                var ret = cd.ShowDialog();
                if (ret == DialogResult.OK)
                {
                    CharClass cc = (CharClass)(listBox1.SelectedItem);
                    setColor(cc, cd.Color, editorcolors[cc].BackColor);
                }
            };
            BackColorButton.Click += (s, e) =>
            {
                var cd = new ColorDialog();
                var ret = cd.ShowDialog();
                if (ret == DialogResult.OK)
                {
                    CharClass cc = (CharClass)(listBox1.SelectedItem);
                    setColor(cc, editorcolors[cc].ForeColor, cd.Color);

                    ch = false;
                    TransparentCheckBox.Checked = false;
                    ch = true;
                }
            };
            TransparentCheckBox.CheckedChanged += (s, e) =>
            {
                if (!ch) return;
                CharClass cc = (CharClass)(listBox1.SelectedItem);
                var ec = editorcolors[cc];
                if (TransparentCheckBox.Checked)
                {
                    setColor(cc, ec.ForeColor, Color.Transparent);
                }
                else
                {
                    setColor(cc, ec.ForeColor, ec.BackColor);
                }
            };
        }

        private void setColor(CharClass cc, Color fore, Color back)
        {
            editorcolors[cc].ForeColor = fore;
            editorcolors[cc].BackColor = back;
            
            previeweditor.ForeColor = editorcolors[cc].ForeColor;

            if (cc == CharClass.Normal)
            {
                previeweditor.BackColor = editorcolors[cc].BackColor;
            }
            else
            {
                if (editorcolors[cc].BackColor == Color.Transparent)
                {

                    previeweditor.BackColor = editorcolors[CharClass.Normal].BackColor;
                }
                else
                {
                    previeweditor.BackColor = editorcolors[cc].BackColor;
                }
            }

            previeweditor.Refresh();
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;

            _config.editorconfig.enclosurs.Clear();
            var encs = _config.editorconfig.enclosurs;
            enclist.ForEach(x =>
            {
                if (x.start.Text.Length > 0 && x.end.Text.Length > 0 && x.cc.SelectedItem != null)
                {
                    encs.Add(new Enclosur() { start = x.start.Text, end = x.end.Text, cc = (CharClass)x.cc.SelectedItem });
                }
            });
        }

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ConfigForm_Load(object sender, EventArgs e)
        {
            var enctextstart = "EnclosureStarttextBox";
            var enctextend = "EnclosureEndtextBox";
            var enccombobox = "EnclosureColorcomboBox";
            for (int i = 0; i < 5; i++)
            {
                var s = tableLayoutPanel2.Controls[enctextstart + i.ToString()] as TextBox;
                var en = tableLayoutPanel2.Controls[enctextend + i.ToString()] as TextBox;
                var c = tableLayoutPanel2.Controls[enccombobox + i.ToString()] as ComboBox;

                foreach (CharClass cc in Enum.GetValues(typeof(CharClass)))
                {
                    c.Items.Add(cc);
                }

                enclist.Add(new EnclosurControl()
                {
                    start = s,
                    end = en,
                    cc = c
                });
            }
            for (int i = 0; i < _config.editorconfig.enclosurs.Count; i++)
            {
                var enc = _config.editorconfig.enclosurs[i];
                enclist[i].start.Text = enc.start;
                enclist[i].end.Text = enc.end;
                enclist[i].cc.Text = enc.cc.ToString();
            }
        }
    }
}
