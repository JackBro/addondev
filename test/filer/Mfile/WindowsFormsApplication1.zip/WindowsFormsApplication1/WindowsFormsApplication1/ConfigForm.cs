﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Sgry.Azuki;

namespace WindowsFormsApplication1 {
    public partial class ConfigForm : Form {
        public ConfigForm() {
            InitializeComponent();
            
            button1.Click+=(s,e)=>{
                FontDialog fd = new FontDialog();
                var ret = fd.ShowDialog();
                if (ret == DialogResult.OK) {
                    var font = fd.Font;
                    FontNameLabel.Text = font.FontFamily.Name;
                }
            };

            List<CharClass> ccs = new List<CharClass> {
                CharClass.Normal, CharClass.Value, CharClass.Comment, 
                CharClass.Keyword,  CharClass.Keyword2, CharClass.Keyword3,
                CharClass.String, CharClass.DocComment
            };
            listBox1.Items.Add(CharClass.Value);
            listBox1.SelectedIndexChanged += (s, e) =>
            {
                
            };
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
