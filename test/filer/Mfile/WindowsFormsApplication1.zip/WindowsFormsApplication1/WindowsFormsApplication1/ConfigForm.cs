﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Sgry.Azuki;
using Sgry.Azuki.WinForms;

namespace WindowsFormsApplication1 {
    public partial class ConfigForm : Form {
        Dictionary<CharClass, EditorColor> editorcolors;
        AzukiControl previeweditor;

        public ConfigForm(Config config) {
            InitializeComponent();
            previeweditor=new AzukiControl();
            previeweditor.Dock = DockStyle.Fill;
            PreviewEditorPanel.Controls.Add(previeweditor);


            button1.Click+=(s,e)=>{
                FontDialog fd = new FontDialog();
                var ret = fd.ShowDialog();
                if (ret == DialogResult.OK) {
                    var font = fd.Font;
                    FontNameLabel.Text = font.FontFamily.Name;
                }
            };

            editorcolor = new Dictionary<CharClass, EditorColor>();
            config.editorconfig.colors.ForEach(x => {
                editorcolor.Add(x.cc, new EditorColor() { cc = x.cc, ForeColor = x.ForeColor, BackColor = x.BackColor });
                listBox1.Items.Add(x.cc);
            });
            //listBox1.Items.Add(CharClass.Value);
            listBox1.SelectedIndexChanged += (s, e) =>
            {
                CharClass cc = (CharClass)(listBox1.SelectedItem);
                previeweditor.ForeColor = editorcolors[cc].ForeColor;
                previeweditor.BackColor = editorcolors[cc].BackColor;

            };
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
