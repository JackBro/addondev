﻿namespace WindowsFormsApplication1 {
    partial class Editor {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナで生成されたコード

        /// <summary> 
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent() {
            this.EditorPanel = new System.Windows.Forms.Panel();
            this.MarkerPanel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // EditorPanel
            // 
            this.EditorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EditorPanel.Location = new System.Drawing.Point(20, 0);
            this.EditorPanel.Name = "EditorPanel";
            this.EditorPanel.Size = new System.Drawing.Size(392, 399);
            this.EditorPanel.TabIndex = 3;
            // 
            // MarkerPanel
            // 
            this.MarkerPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.MarkerPanel.Location = new System.Drawing.Point(0, 0);
            this.MarkerPanel.Name = "MarkerPanel";
            this.MarkerPanel.Size = new System.Drawing.Size(20, 399);
            this.MarkerPanel.TabIndex = 2;
            // 
            // Editor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.EditorPanel);
            this.Controls.Add(this.MarkerPanel);
            this.Name = "Editor";
            this.Size = new System.Drawing.Size(412, 399);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel EditorPanel;
        private System.Windows.Forms.Panel MarkerPanel;
    }
}
