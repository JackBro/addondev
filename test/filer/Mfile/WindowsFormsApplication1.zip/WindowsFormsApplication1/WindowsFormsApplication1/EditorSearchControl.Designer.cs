﻿namespace WindowsFormsApplication1
{
    partial class EditorSearchControl
    {
        /// <summary> 
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナで生成されたコード

        /// <summary> 
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.editorSearchcomboBox = new System.Windows.Forms.ComboBox();
            this.nextbutton = new System.Windows.Forms.Button();
            this.upbutton = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.closebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // editorSearchcomboBox
            // 
            this.editorSearchcomboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.editorSearchcomboBox.FormattingEnabled = true;
            this.editorSearchcomboBox.Location = new System.Drawing.Point(3, 7);
            this.editorSearchcomboBox.Name = "editorSearchcomboBox";
            this.editorSearchcomboBox.Size = new System.Drawing.Size(146, 20);
            this.editorSearchcomboBox.TabIndex = 0;
            // 
            // nextbutton
            // 
            this.nextbutton.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.nextbutton.Location = new System.Drawing.Point(155, 5);
            this.nextbutton.Name = "nextbutton";
            this.nextbutton.Size = new System.Drawing.Size(64, 23);
            this.nextbutton.TabIndex = 1;
            this.nextbutton.Text = "Next";
            this.nextbutton.UseVisualStyleBackColor = true;
            // 
            // upbutton
            // 
            this.upbutton.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.upbutton.Location = new System.Drawing.Point(225, 5);
            this.upbutton.Name = "upbutton";
            this.upbutton.Size = new System.Drawing.Size(63, 23);
            this.upbutton.TabIndex = 2;
            this.upbutton.Text = "Up";
            this.upbutton.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(294, 10);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 16);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // closebutton
            // 
            this.closebutton.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.closebutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.closebutton.Location = new System.Drawing.Point(372, 7);
            this.closebutton.Name = "closebutton";
            this.closebutton.Size = new System.Drawing.Size(26, 23);
            this.closebutton.TabIndex = 4;
            this.closebutton.Text = "button1";
            this.closebutton.UseVisualStyleBackColor = true;
            // 
            // EditorSearchControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.closebutton);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.upbutton);
            this.Controls.Add(this.nextbutton);
            this.Controls.Add(this.editorSearchcomboBox);
            this.Name = "EditorSearchControl";
            this.Size = new System.Drawing.Size(400, 39);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ComboBox editorSearchcomboBox;
        internal System.Windows.Forms.Button nextbutton;
        internal System.Windows.Forms.Button upbutton;
        internal System.Windows.Forms.CheckBox checkBox1;
        internal System.Windows.Forms.Button closebutton;

    }
}
