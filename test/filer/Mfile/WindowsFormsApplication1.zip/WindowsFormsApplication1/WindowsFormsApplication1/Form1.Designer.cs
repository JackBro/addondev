﻿namespace WindowsFormsApplication1 {
    partial class Form1 {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.RuntoolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.steptoolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.stoptoolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.markpanel = new System.Windows.Forms.Panel();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RuntoolStripButton1,
            this.steptoolStripButton1,
            this.stoptoolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(292, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // RuntoolStripButton1
            // 
            this.RuntoolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.RuntoolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("RuntoolStripButton1.Image")));
            this.RuntoolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RuntoolStripButton1.Name = "RuntoolStripButton1";
            this.RuntoolStripButton1.Size = new System.Drawing.Size(25, 22);
            this.RuntoolStripButton1.Text = "run";
            this.RuntoolStripButton1.Click += new System.EventHandler(this.RuntoolStripButton1_Click);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(20, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(272, 248);
            this.panel1.TabIndex = 1;
            // 
            // steptoolStripButton1
            // 
            this.steptoolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.steptoolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("steptoolStripButton1.Image")));
            this.steptoolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.steptoolStripButton1.Name = "steptoolStripButton1";
            this.steptoolStripButton1.Size = new System.Drawing.Size(31, 22);
            this.steptoolStripButton1.Text = "step";
            this.steptoolStripButton1.Click += new System.EventHandler(this.steptoolStripButton1_Click);
            // 
            // stoptoolStripButton1
            // 
            this.stoptoolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.stoptoolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("stoptoolStripButton1.Image")));
            this.stoptoolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stoptoolStripButton1.Name = "stoptoolStripButton1";
            this.stoptoolStripButton1.Size = new System.Drawing.Size(31, 22);
            this.stoptoolStripButton1.Text = "stop";
            this.stoptoolStripButton1.Click += new System.EventHandler(this.stoptoolStripButton1_Click);
            // 
            // markpanel
            // 
            this.markpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.markpanel.Location = new System.Drawing.Point(0, 25);
            this.markpanel.Name = "markpanel";
            this.markpanel.Size = new System.Drawing.Size(20, 248);
            this.markpanel.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.markpanel);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton RuntoolStripButton1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripButton steptoolStripButton1;
        private System.Windows.Forms.ToolStripButton stoptoolStripButton1;
        private System.Windows.Forms.Panel markpanel;
    }
}

