﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel3 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.FileimageList = new System.Windows.Forms.ImageList(this.components);
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.TabPanel = new System.Windows.Forms.Panel();
            this.MainEditorPanel = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.DateTimeLabel = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ThumbnailListView = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newFiletoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.newMemotoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.listMemotoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.thumbnailtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.WraptoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.showSubPaneltoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renameFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.newMemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newLinkedMemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wrapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subPanleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThumbnailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showMemoListtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showLinkedMemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FileListViewContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.renameFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ListViewContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CreateLinkItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorcontextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.undotoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redotoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.cuttoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copytoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pastetoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteAsQuotationtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAlltoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertDatetoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emptyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.FileListViewContextMenuStrip.SuspendLayout();
            this.ListViewContextMenuStrip.SuspendLayout();
            this.editorcontextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 49);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(735, 511);
            this.splitContainer1.SplitterDistance = 102;
            this.splitContainer1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.listView1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(102, 511);
            this.panel3.TabIndex = 0;
            // 
            // listView1
            // 
            this.listView1.AllowDrop = true;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.LargeImageList = this.FileimageList;
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(102, 511);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView1_DragDrop);
            this.listView1.DragOver += new System.Windows.Forms.DragEventHandler(this.listView1_DragOver);
            // 
            // FileimageList
            // 
            this.FileimageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("FileimageList.ImageStream")));
            this.FileimageList.TransparentColor = System.Drawing.Color.Transparent;
            this.FileimageList.Images.SetKeyName(0, "newfile24.png");
            this.FileimageList.Images.SetKeyName(1, "trust24.png");
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer2.Size = new System.Drawing.Size(629, 511);
            this.splitContainer2.SplitterDistance = 329;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.TabPanel);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.MainEditorPanel);
            this.splitContainer3.Panel2.Controls.Add(this.panel4);
            this.splitContainer3.Size = new System.Drawing.Size(629, 329);
            this.splitContainer3.SplitterDistance = 118;
            this.splitContainer3.TabIndex = 0;
            // 
            // TabPanel
            // 
            this.TabPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabPanel.Location = new System.Drawing.Point(0, 0);
            this.TabPanel.Margin = new System.Windows.Forms.Padding(0);
            this.TabPanel.Name = "TabPanel";
            this.TabPanel.Size = new System.Drawing.Size(629, 118);
            this.TabPanel.TabIndex = 0;
            // 
            // MainEditorPanel
            // 
            this.MainEditorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainEditorPanel.Location = new System.Drawing.Point(0, 25);
            this.MainEditorPanel.Name = "MainEditorPanel";
            this.MainEditorPanel.Size = new System.Drawing.Size(629, 182);
            this.MainEditorPanel.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.Controls.Add(this.DateTimeLabel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(5);
            this.panel4.Size = new System.Drawing.Size(629, 25);
            this.panel4.TabIndex = 0;
            // 
            // DateTimeLabel
            // 
            this.DateTimeLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.DateTimeLabel.AutoSize = true;
            this.DateTimeLabel.Location = new System.Drawing.Point(5, 5);
            this.DateTimeLabel.Margin = new System.Windows.Forms.Padding(3);
            this.DateTimeLabel.Name = "DateTimeLabel";
            this.DateTimeLabel.Size = new System.Drawing.Size(35, 12);
            this.DateTimeLabel.TabIndex = 0;
            this.DateTimeLabel.Text = "label1";
            this.DateTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(629, 178);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(621, 153);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ThumbnailListView);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(597, 153);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ThumbnailListView
            // 
            this.ThumbnailListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThumbnailListView.LargeImageList = this.imageList1;
            this.ThumbnailListView.Location = new System.Drawing.Point(3, 3);
            this.ThumbnailListView.Name = "ThumbnailListView";
            this.ThumbnailListView.Size = new System.Drawing.Size(591, 147);
            this.ThumbnailListView.TabIndex = 0;
            this.ThumbnailListView.UseCompatibleStateImageBehavior = false;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFiletoolStripButton,
            this.toolStripSeparator1,
            this.newMemotoolStripButton,
            this.toolStripSeparator2,
            this.listMemotoolStripButton,
            this.thumbnailtoolStripButton,
            this.WraptoolStripButton,
            this.toolStripSeparator3,
            this.showSubPaneltoolStripButton,
            this.toolStripComboBox1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(735, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newFiletoolStripButton
            // 
            this.newFiletoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newFiletoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newFiletoolStripButton.Image")));
            this.newFiletoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newFiletoolStripButton.Name = "newFiletoolStripButton";
            this.newFiletoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.newFiletoolStripButton.Text = "New File";
            this.newFiletoolStripButton.Click += new System.EventHandler(this.newFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // newMemotoolStripButton
            // 
            this.newMemotoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newMemotoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newMemotoolStripButton.Image")));
            this.newMemotoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newMemotoolStripButton.Name = "newMemotoolStripButton";
            this.newMemotoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.newMemotoolStripButton.Text = "New Memo";
            this.newMemotoolStripButton.Click += new System.EventHandler(this.newMemoToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // listMemotoolStripButton
            // 
            this.listMemotoolStripButton.BackColor = System.Drawing.SystemColors.Control;
            this.listMemotoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.listMemotoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("listMemotoolStripButton.Image")));
            this.listMemotoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.listMemotoolStripButton.Name = "listMemotoolStripButton";
            this.listMemotoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.listMemotoolStripButton.Text = "List";
            this.listMemotoolStripButton.Click += new System.EventHandler(this.showMemoListtoolStripMenuItem_Click);
            // 
            // thumbnailtoolStripButton
            // 
            this.thumbnailtoolStripButton.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.thumbnailtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.thumbnailtoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("thumbnailtoolStripButton.Image")));
            this.thumbnailtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.thumbnailtoolStripButton.Name = "thumbnailtoolStripButton";
            this.thumbnailtoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.thumbnailtoolStripButton.Text = "Thumbnail";
            this.thumbnailtoolStripButton.Click += new System.EventHandler(this.ThumbnailToolStripMenuItem_Click);
            // 
            // WraptoolStripButton
            // 
            this.WraptoolStripButton.CheckOnClick = true;
            this.WraptoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.WraptoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("WraptoolStripButton.Image")));
            this.WraptoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.WraptoolStripButton.Name = "WraptoolStripButton";
            this.WraptoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.WraptoolStripButton.Text = "toolStripButton1";
            this.WraptoolStripButton.Click += new System.EventHandler(this.WraptoolStripButton_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // showSubPaneltoolStripButton
            // 
            this.showSubPaneltoolStripButton.CheckOnClick = true;
            this.showSubPaneltoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.showSubPaneltoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("showSubPaneltoolStripButton.Image")));
            this.showSubPaneltoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.showSubPaneltoolStripButton.Name = "showSubPaneltoolStripButton";
            this.showSubPaneltoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.showSubPaneltoolStripButton.Text = "toolStripButton1";
            this.showSubPaneltoolStripButton.Click += new System.EventHandler(this.showSubPaneltoolStripButton_Click);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 25);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.toolToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(735, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFileToolStripMenuItem,
            this.deleteFileToolStripMenuItem,
            this.renameFileToolStripMenuItem,
            this.toolStripSeparator5,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(36, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newFileToolStripMenuItem
            // 
            this.newFileToolStripMenuItem.Name = "newFileToolStripMenuItem";
            this.newFileToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.newFileToolStripMenuItem.Text = "New File";
            this.newFileToolStripMenuItem.Click += new System.EventHandler(this.newFileToolStripMenuItem_Click);
            // 
            // deleteFileToolStripMenuItem
            // 
            this.deleteFileToolStripMenuItem.Name = "deleteFileToolStripMenuItem";
            this.deleteFileToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.deleteFileToolStripMenuItem.Text = "Delete File";
            this.deleteFileToolStripMenuItem.Click += new System.EventHandler(this.deleteFileToolStripMenuItem_Click);
            // 
            // renameFileToolStripMenuItem
            // 
            this.renameFileToolStripMenuItem.Name = "renameFileToolStripMenuItem";
            this.renameFileToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.renameFileToolStripMenuItem.Text = "Rename File";
            this.renameFileToolStripMenuItem.Click += new System.EventHandler(this.renameFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(131, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem1,
            this.toolStripSeparator4,
            this.newMemoToolStripMenuItem,
            this.deleteMemoToolStripMenuItem,
            this.dateTimeToolStripMenuItem,
            this.newLinkedMemoToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyToolStripMenuItem1
            // 
            this.copyToolStripMenuItem1.Name = "copyToolStripMenuItem1";
            this.copyToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.copyToolStripMenuItem1.Text = "Copy";
            this.copyToolStripMenuItem1.Click += new System.EventHandler(this.copyToolStripMenuItem1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(160, 6);
            // 
            // newMemoToolStripMenuItem
            // 
            this.newMemoToolStripMenuItem.Name = "newMemoToolStripMenuItem";
            this.newMemoToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.newMemoToolStripMenuItem.Text = "New Memo";
            this.newMemoToolStripMenuItem.Click += new System.EventHandler(this.newMemoToolStripMenuItem_Click);
            // 
            // deleteMemoToolStripMenuItem
            // 
            this.deleteMemoToolStripMenuItem.Name = "deleteMemoToolStripMenuItem";
            this.deleteMemoToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.deleteMemoToolStripMenuItem.Text = "Delete Memo";
            this.deleteMemoToolStripMenuItem.Click += new System.EventHandler(this.deleteMemoToolStripMenuItem_Click);
            // 
            // dateTimeToolStripMenuItem
            // 
            this.dateTimeToolStripMenuItem.Name = "dateTimeToolStripMenuItem";
            this.dateTimeToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.dateTimeToolStripMenuItem.Text = "Edit Date";
            this.dateTimeToolStripMenuItem.Click += new System.EventHandler(this.dateTimeToolStripMenuItem_Click);
            // 
            // newLinkedMemoToolStripMenuItem
            // 
            this.newLinkedMemoToolStripMenuItem.Name = "newLinkedMemoToolStripMenuItem";
            this.newLinkedMemoToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.newLinkedMemoToolStripMenuItem.Text = "New Linked Memo";
            this.newLinkedMemoToolStripMenuItem.Click += new System.EventHandler(this.newLinkedMemoToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editorToolStripMenuItem,
            this.subPanleToolStripMenuItem,
            this.ThumbnailToolStripMenuItem,
            this.showMemoListtoolStripMenuItem,
            this.showLinkedMemoToolStripMenuItem,
            this.showToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // editorToolStripMenuItem
            // 
            this.editorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wrapToolStripMenuItem});
            this.editorToolStripMenuItem.Name = "editorToolStripMenuItem";
            this.editorToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.editorToolStripMenuItem.Text = "Editor";
            // 
            // wrapToolStripMenuItem
            // 
            this.wrapToolStripMenuItem.CheckOnClick = true;
            this.wrapToolStripMenuItem.Name = "wrapToolStripMenuItem";
            this.wrapToolStripMenuItem.Size = new System.Drawing.Size(95, 22);
            this.wrapToolStripMenuItem.Text = "Wrap";
            this.wrapToolStripMenuItem.Click += new System.EventHandler(this.wrapToolStripMenuItem_Click);
            // 
            // subPanleToolStripMenuItem
            // 
            this.subPanleToolStripMenuItem.CheckOnClick = true;
            this.subPanleToolStripMenuItem.Name = "subPanleToolStripMenuItem";
            this.subPanleToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.subPanleToolStripMenuItem.Text = "Sub Panle";
            this.subPanleToolStripMenuItem.Click += new System.EventHandler(this.subPanleToolStripMenuItem_Click);
            // 
            // ThumbnailToolStripMenuItem
            // 
            this.ThumbnailToolStripMenuItem.Name = "ThumbnailToolStripMenuItem";
            this.ThumbnailToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.ThumbnailToolStripMenuItem.Text = "Thumbnail";
            this.ThumbnailToolStripMenuItem.Click += new System.EventHandler(this.ThumbnailToolStripMenuItem_Click);
            // 
            // showMemoListtoolStripMenuItem
            // 
            this.showMemoListtoolStripMenuItem.Name = "showMemoListtoolStripMenuItem";
            this.showMemoListtoolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.showMemoListtoolStripMenuItem.Text = "Memo List";
            this.showMemoListtoolStripMenuItem.Click += new System.EventHandler(this.showMemoListtoolStripMenuItem_Click);
            // 
            // showLinkedMemoToolStripMenuItem
            // 
            this.showLinkedMemoToolStripMenuItem.Name = "showLinkedMemoToolStripMenuItem";
            this.showLinkedMemoToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.showLinkedMemoToolStripMenuItem.Text = "Linked Memo";
            this.showLinkedMemoToolStripMenuItem.Click += new System.EventHandler(this.showLinkedMemoToolStripMenuItem_Click);
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.showToolStripMenuItem.Text = "Link Memo";
            // 
            // toolToolStripMenuItem
            // 
            this.toolToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionToolStripMenuItem});
            this.toolToolStripMenuItem.Name = "toolToolStripMenuItem";
            this.toolToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.toolToolStripMenuItem.Text = "Tool";
            // 
            // optionToolStripMenuItem
            // 
            this.optionToolStripMenuItem.Name = "optionToolStripMenuItem";
            this.optionToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.optionToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.optionToolStripMenuItem.Text = "Option";
            this.optionToolStripMenuItem.Click += new System.EventHandler(this.optionToolStripMenuItem_Click);
            // 
            // FileListViewContextMenuStrip
            // 
            this.FileListViewContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFileToolStripMenuItem1,
            this.deleteFileToolStripMenuItem1,
            this.renameFileToolStripMenuItem1,
            this.emptyToolStripMenuItem});
            this.FileListViewContextMenuStrip.Name = "contextMenuStrip1";
            this.FileListViewContextMenuStrip.Size = new System.Drawing.Size(135, 92);
            this.FileListViewContextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.FileListViewContextMenuStrip_Opening);
            // 
            // newFileToolStripMenuItem1
            // 
            this.newFileToolStripMenuItem1.Name = "newFileToolStripMenuItem1";
            this.newFileToolStripMenuItem1.Size = new System.Drawing.Size(134, 22);
            this.newFileToolStripMenuItem1.Text = "New File";
            this.newFileToolStripMenuItem1.Click += new System.EventHandler(this.newFileToolStripMenuItem_Click);
            // 
            // deleteFileToolStripMenuItem1
            // 
            this.deleteFileToolStripMenuItem1.Name = "deleteFileToolStripMenuItem1";
            this.deleteFileToolStripMenuItem1.Size = new System.Drawing.Size(134, 22);
            this.deleteFileToolStripMenuItem1.Text = "Delete File";
            this.deleteFileToolStripMenuItem1.Click += new System.EventHandler(this.deleteFileToolStripMenuItem_Click);
            // 
            // renameFileToolStripMenuItem1
            // 
            this.renameFileToolStripMenuItem1.Name = "renameFileToolStripMenuItem1";
            this.renameFileToolStripMenuItem1.Size = new System.Drawing.Size(134, 22);
            this.renameFileToolStripMenuItem1.Text = "Rename File";
            this.renameFileToolStripMenuItem1.Click += new System.EventHandler(this.renameFileToolStripMenuItem_Click);
            // 
            // ListViewContextMenuStrip
            // 
            this.ListViewContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreateLinkItemToolStripMenuItem});
            this.ListViewContextMenuStrip.Name = "TreeViewContextMenuStrip";
            this.ListViewContextMenuStrip.Size = new System.Drawing.Size(169, 26);
            // 
            // CreateLinkItemToolStripMenuItem
            // 
            this.CreateLinkItemToolStripMenuItem.Name = "CreateLinkItemToolStripMenuItem";
            this.CreateLinkItemToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.CreateLinkItemToolStripMenuItem.Text = "toolStripMenuItem2";
            // 
            // editorcontextMenuStrip
            // 
            this.editorcontextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undotoolStripMenuItem,
            this.redotoolStripMenuItem,
            this.toolStripSeparator6,
            this.cuttoolStripMenuItem,
            this.copytoolStripMenuItem,
            this.pastetoolStripMenuItem,
            this.pasteAsQuotationtoolStripMenuItem,
            this.toolStripSeparator7,
            this.selectAlltoolStripMenuItem,
            this.insertDatetoolStripMenuItem});
            this.editorcontextMenuStrip.Name = "EditorcontextMenuStrip";
            this.editorcontextMenuStrip.Size = new System.Drawing.Size(167, 192);
            this.editorcontextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.editorcontextMenuStrip_Opening);
            // 
            // undotoolStripMenuItem
            // 
            this.undotoolStripMenuItem.Name = "undotoolStripMenuItem";
            this.undotoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.undotoolStripMenuItem.Text = "Undo";
            this.undotoolStripMenuItem.Click += new System.EventHandler(this.undotoolStripMenuItem_Click);
            // 
            // redotoolStripMenuItem
            // 
            this.redotoolStripMenuItem.Name = "redotoolStripMenuItem";
            this.redotoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.redotoolStripMenuItem.Text = "Redo";
            this.redotoolStripMenuItem.Click += new System.EventHandler(this.redotoolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(163, 6);
            // 
            // cuttoolStripMenuItem
            // 
            this.cuttoolStripMenuItem.Name = "cuttoolStripMenuItem";
            this.cuttoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.cuttoolStripMenuItem.Text = "Cut";
            this.cuttoolStripMenuItem.Click += new System.EventHandler(this.cuttoolStripMenuItem_Click);
            // 
            // copytoolStripMenuItem
            // 
            this.copytoolStripMenuItem.Name = "copytoolStripMenuItem";
            this.copytoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.copytoolStripMenuItem.Text = "Copy";
            this.copytoolStripMenuItem.Click += new System.EventHandler(this.copytoolStripMenuItem_Click);
            // 
            // pastetoolStripMenuItem
            // 
            this.pastetoolStripMenuItem.Name = "pastetoolStripMenuItem";
            this.pastetoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.pastetoolStripMenuItem.Text = "Paste";
            this.pastetoolStripMenuItem.Click += new System.EventHandler(this.pastetoolStripMenuItem_Click);
            // 
            // pasteAsQuotationtoolStripMenuItem
            // 
            this.pasteAsQuotationtoolStripMenuItem.Name = "pasteAsQuotationtoolStripMenuItem";
            this.pasteAsQuotationtoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.pasteAsQuotationtoolStripMenuItem.Text = "Paste as quotation";
            this.pasteAsQuotationtoolStripMenuItem.Click += new System.EventHandler(this.pasteAsQuotationtoolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(163, 6);
            // 
            // selectAlltoolStripMenuItem
            // 
            this.selectAlltoolStripMenuItem.Name = "selectAlltoolStripMenuItem";
            this.selectAlltoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.selectAlltoolStripMenuItem.Text = "Select All";
            this.selectAlltoolStripMenuItem.Click += new System.EventHandler(this.selectAlltoolStripMenuItem_Click);
            // 
            // insertDatetoolStripMenuItem
            // 
            this.insertDatetoolStripMenuItem.Name = "insertDatetoolStripMenuItem";
            this.insertDatetoolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.insertDatetoolStripMenuItem.Text = "Date";
            this.insertDatetoolStripMenuItem.Click += new System.EventHandler(this.insertDatetoolStripMenuItem_Click);
            // 
            // emptyToolStripMenuItem
            // 
            this.emptyToolStripMenuItem.Name = "emptyToolStripMenuItem";
            this.emptyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.emptyToolStripMenuItem.Text = "Empty";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 560);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            this.splitContainer3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.FileListViewContextMenuStrip.ResumeLayout(false);
            this.ListViewContextMenuStrip.ResumeLayout(false);
            this.editorcontextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Panel MainEditorPanel;
        private System.Windows.Forms.ToolStripButton newMemotoolStripButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ContextMenuStrip FileListViewContextMenuStrip;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label DateTimeLabel;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.Panel TabPanel;
        private System.Windows.Forms.ToolStripButton newFiletoolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ContextMenuStrip ListViewContextMenuStrip;
        private System.Windows.Forms.ToolStripButton listMemotoolStripButton;
        private System.Windows.Forms.ToolStripMenuItem CreateLinkItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dateTimeToolStripMenuItem;
        private System.Windows.Forms.ListView ThumbnailListView;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripButton thumbnailtoolStripButton;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStripButton showSubPaneltoolStripButton;
        private System.Windows.Forms.ToolStripButton WraptoolStripButton;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip editorcontextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem newFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renameFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newMemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteMemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subPanleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showMemoListtoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ThumbnailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wrapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showLinkedMemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newLinkedMemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem copytoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cuttoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pastetoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteAsQuotationtoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertDatetoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undotoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redotoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAlltoolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ImageList FileimageList;
        private System.Windows.Forms.ToolStripMenuItem newFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deleteFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem renameFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem emptyToolStripMenuItem;
    }
}

