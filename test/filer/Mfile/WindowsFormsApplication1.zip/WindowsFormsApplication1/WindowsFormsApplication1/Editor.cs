﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1 {
    public partial class Editor : UserControl {
        private Sgry.Azuki.WinForms.AzukiControl editor;
        private List<int> bks = new List<int>();
        public Editor() {
            InitializeComponent();

            editor = new Sgry.Azuki.WinForms.AzukiControl();
            editor.Dock = DockStyle.Fill;
            EditorPanel.Controls.Add(editor);

            MarkerPanel.MouseClick += (s, e) => {
                var l = editor.GetIndexFromPosition(e.Location);
                var line = editor.GetLineIndexFromCharIndex(l);
                if (bks.Contains(line)) {
                    bks.Remove(line);
                } else {
                    bks.Add(line);
                }
                editor.Invalidate();
                //azuki.Refresh();
            };
            editor.LineDrawn += (sender, e) => {
                if (bks.Contains(e.LineIndex)) {
                    e.Graphics.ForeColor = Color.Red;
                    e.Graphics.BackColor = Color.Red;
                    e.Graphics.FillRectangle(0, e.Position.Y, 10, 10);
                }
            };

        }
    }
}
