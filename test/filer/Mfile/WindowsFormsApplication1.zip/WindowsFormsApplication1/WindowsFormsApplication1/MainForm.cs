﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;
using Sgry.Azuki;
using Microsoft.VisualBasic.FileIO;
using WindowsFormsApplication1.Properties;
using Sgry.Azuki.WinForms;

namespace WindowsFormsApplication1
{
    enum LinkType {
        None,
        Goto,
        ComeFrom
    }

    public partial class MainForm : Form
    {
        private Sgry.Azuki.WinForms.AzukiControl _mainEditor, _subEditor;

        private Config _config;
        private List<FileList> _filelists;
        private manager _m;
        private Dictionary<string, TabControl> tabcontrols = new Dictionary<string, TabControl>();

        private FileListView filelistiew;
        private EditorSearchControl searchmain, searchsub;

        private ViewPanelManager _panelManager;

        Regex regcomefrom = new Regex(@"<<<([0-9]+)[^0-9]*", RegexOptions.Compiled);
        Regex reggoto = new Regex(@">>>([0-9]+)[^0-9]*", RegexOptions.Compiled);

        Regex regpath = new Regex(@">>>([a-zA-Z]:\\[^/:\*\?<>\|]*)", RegexOptions.Compiled);
        
        Regex _regMark1 = new Regex(@"(>>>|<<<)(\S+)", RegexOptions.Compiled);
        Regex _regImage = new Regex(@".*(\.jpg|\.jepg|\.png|\.gif|\.bmp)$", RegexOptions.Compiled);

        public string getDatePath(string file) {
            return Path.Combine(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "data"), file);
        }

        private string convetPath2URI(string prefix, string path) {
            _config.symbols.ForEach(x => {
                path = path.Replace(x.value, x.symbol);
            });
            return string.Format("{0}{1}", prefix, path.Replace(" ", "%20"));
        }
        private string convetURI2Path(string uri) {
            uri =  uri.Replace("file:///", "").Replace("<<<", "").Replace(">>>", "");
            _config.symbols.ForEach(x => {
                uri = uri.Replace(x.symbol, x.value);
            });
            return string.Format(@"{0}", uri.Replace("%20", " "));
        }

        public MainForm()
        {
            InitializeComponent();

            filelistiew = new FileListView();
            filelistiew.View = View.LargeIcon;
            filelistiew.LargeImageList = FileimageList;
            filelistiew.AutoArrange = true;
            filelistiew.Dock = DockStyle.Fill;
            filelistiew.DragOver += new DragEventHandler(filelistiew_DragOver);
            filelistiew.DragDrop += new DragEventHandler(filelistiew_DragDrop);
            splitContainer1.Panel1.Controls.Add(filelistiew);

            _m = new manager();
            _m.dataDir = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "data");

            ConfigLoad();


            _panelManager = new ViewPanelManager(_config.ThumbnailSize, _config.ThumbnailBackColor);

            splitContainer1.SplitterDistance = _config.FileListViewW == 0 ? splitContainer1.SplitterDistance: _config.FileListViewW;
            splitContainer3.SplitterDistance = _config.MemoListViewW == 0 ? splitContainer3.SplitterDistance : _config.MemoListViewW;
            splitContainer2.SplitterDistance = _config.SubPanelW == 0 ? splitContainer2.SplitterDistance : _config.SubPanelW;

            this.Load += (s, e) => {
                if (filelistiew.Items.Count > 0) {
                    filelistiew.Items[0].Selected = true;
                }
                WraptoolStripButton.Checked = _config.Editor.IsWrap;
                wrapToolStripMenuItem.Checked = _config.Editor.IsWrap;
            };

            Marking.Register(new MarkingInfo(1, "_link", MouseCursor.Hand));
            _mainEditor = createEditor();

            MainEditorPanel.Controls.Add(_mainEditor);
            _mainEditor.AllowDrop = true;
            _mainEditor.SetKeyBind(Keys.Control | Keys.C, (x) => {
                if (_mainEditor.GetSelectedText() != string.Empty) {
                    _mainEditor.Copy();
                }
            });
            _mainEditor.SetKeyBind(Keys.Control | Keys.X, (x) => {
                if (_mainEditor.GetSelectedText() != string.Empty) {
                    _mainEditor.Cut();
                }
            });
           
            _mainEditor.SetKeyBind(Keys.Control | Keys.V, (x) => {
                pastetoolStripMenuItem_Click(null, null);
            });

            _mainEditor.GotFocus += (s, e) => {
                _mainEditor.ContextMenuStrip = EditorContextMenuStrip;

            };

            _mainEditor.DragOver += (s, e) => {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)){
                    e.Effect = DragDropEffects.Copy;

                    if(!_mainEditor.Focused){
                        _mainEditor.Focus();
                    }

                    int l, c, index; 
                    index = _mainEditor.GetIndexFromPosition(_mainEditor.PointToClient(new Point(e.X, e.Y)));
                    var pos = _mainEditor.GetPositionFromIndex(index);
                    _mainEditor.Document.GetLineColumnIndexFromCharIndex(index, out l, out c);
                    _mainEditor.Document.SetCaretIndex(l, c);
                }
            };
            _mainEditor.DragDrop += (s, e) => {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop, false);
                    //var sb = new StringBuilder();
                    //foreach (var file in fileNames){
                    //   //sb.AppendLine(string.Format("file:///{0}", file));
                    //   //sb.AppendLine(convetPath2URI(file));
                    //}        
                    //var point = _mainEditor.PointToClient(new Point(e.X, e.Y));
                    //var index = _mainEditor.GetIndexFromPosition(point);
                    //_mainEditor.Document.Replace(sb.ToString(), index, index);
                    //int l, c;
                    //_mainEditor.Document.GetLineColumnIndexFromCharIndex(index + sb.Length, out l, out c);
                    //_mainEditor.Document.SetCaretIndex(l, c);

                    EditorContextMenuStrip2.Tag = fileNames;
                    EditorContextMenuStrip2.Show(_mainEditor, e.X, e.Y);  
                }
            };

            _mainEditor.LostFocus += (s, e) => {
                if (_mainEditor.Document.IsDirty) {
                    var tb = getTabControl(filelistiew.SelectedItems[0].Text); 
                    if (tb.SelectedTab.Controls[0] is ListViewEx)
                    {
                        var lv = tb.SelectedTab.Controls[0] as ListViewEx;
                        if(lv.SelectedIndices.Count>0){
                            var item = lv.DataItems[lv.SelectedIndices[0]];
                            item.text = _mainEditor.Text;
                        }
                    }
                    SaveFile(filelistiew.SelectedItems[0].Text);
                }
            };

            toolStripComboBox1.KeyDown += (s, e) => {
                ToolStripComboBox cb = s as ToolStripComboBox;
                if (e.KeyData == Keys.Return) {
                    createListView(filelistiew.SelectedItems[0].Text, cb.Text);
                }
            };

            filelistiew.AfterLabelEdit += (s, e) => {
                if (filelistiew.Items.IndexOfKey(e.Label) >= 0 || e.Label == string.Empty) {
                    e.CancelEdit = true;
                }else{
                    try {
                        RenameFile(filelistiew.Items[e.Item].Text, e.Label);
                    }
                    catch (Exception ex) {
                        MessageBox.Show(ex.Message);
                        e.CancelEdit = true;           
                    }           
                }
            };

            filelistiew.ItemSelectionChanged += (s, e) =>{
                if (e.IsSelected ) {
                    var filename =e.Item.Text;
                    Item item=null;
                    if (!tabcontrols.ContainsKey(filename)) {
                        var tb = getTabControl(filename);
                        var cl = _m.getClass(filename);
                        var lv = getAllListView(tb);
                        lv.DataItems = cl._items.OrderByDescending((x) => x.Date).ToList<Item>();
     
                        tb.BringToFront();
                        if (lv.DataItems.Count>0) {
                            lv.Items[0].Selected = true;
                            item = lv.DataItems[0];
                        }
                    } else {
                        var tb = getTabControl(filename);
                        var lv = getAllListView(tb);
                        tb.BringToFront();
                        if (lv.DataItems.Count > 0){
                            if (lv.SelectedIndices.Count == 0) {
                                lv.Items[0].Selected = true;
                                item = lv.DataItems[0];
                            } else {
                                item = lv.DataItems[lv.SelectedIndices[0]];
                            }
                            SetMainEditorText(item);  
                        }
                    }
                    if (item == null) {
                        SetMainEditorText(item);  
                    }
                }
            };

            filelistiew.ContextMenuStrip = FileListViewContextMenuStrip;

            _subEditor = createEditor();
            _subEditor.IsReadOnly = true;
            tabPage1.Controls.Add(_subEditor);
            _subEditor.GotFocus += (s, e) => {
                _subEditor.ContextMenuStrip = EditorContextMenuStrip;
            };

            DateTimeLabel.DoubleClick += (s, e) => {
                editDateTimeToolStripMenuItem_Click(null, null);
            };

            splitContainer2.Panel2Collapsed = true;

            //m.Load(config.FileList);
        }

        void filelistiew_DragDrop(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(typeof(ListViewItem))) {
                ListView lv = (ListView)sender;
                ListViewItem source = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                if (target != null) {
                    var srclvex = source.ListView as ListViewEx;
                    var item = srclvex.DataItems[source.Index];
                    var fromtb = getTabControl(lv.SelectedItems[0].Text);
                    for (int i = 0; i < fromtb.TabPages.Count; i++) {
                        var tbp = fromtb.TabPages[i];
                        var fromlvex = tbp.Controls[0] as ListViewEx;
                        fromlvex.DeleteItem(item);
                    }
                    if (srclvex.DataItems.Count > 0) {
                        if (source.Index > 0) {
                            srclvex.Items[source.Index - 1].Selected = true;
                        } else {
                            srclvex.Items[0].Selected = true;
                        }
                    }

                    var targetlv = getAllListView(getTabControl(target.Text));
                    targetlv.AddItem(item,false);
                } else
                    e.Effect = DragDropEffects.None;
            } else
                e.Effect = DragDropEffects.None;
        }

        void filelistiew_DragOver(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(typeof(ListViewItem))) {
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                    e.Effect = DragDropEffects.Move;
            } else {
                e.Effect = DragDropEffects.None;
            }

            if (e.Effect != DragDropEffects.None) {
                ListView lv = (ListView)sender;
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                ListViewItem source = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                if (target != null && !target.Text.Equals(lv.SelectedItems[0].Text)) {
                } else
                    e.Effect = DragDropEffects.None;
            }
        }


        //#region IUserInterface - Scroll
        //public event ScrollEventHandler ScrollEvent;
        ///// <summary>
        ///// Scrolls a portion of the window.
        ///// </summary>
        //public void Scroll(Rectangle rect, int vOffset, int hOffset) {
        //    WinApi.ScrollWindow(Handle, vOffset, hOffset, rect);
        //    WinApi.SetScrollPos(Handle, false, _Impl.View.FirstVisibleLine);
        //    WinApi.SetScrollPos(Handle, true, _Impl.View.ScrollPosX);
        //    UpdateCaretGraphic();

        //    if (ScrollEvent != null) {
        //        if (vOffset != 0) {
        //            ScrollEvent(this, new ScrollEventArgs(ScrollEventType.SmallIncrement, vOffset, ScrollOrientation.VerticalScroll));
        //        } else {
        //            ScrollEvent(this, new ScrollEventArgs(ScrollEventType.SmallIncrement, hOffset, ScrollOrientation.HorizontalScroll));
        //        }
        //    }
        //}

        private Sgry.Azuki.WinForms.AzukiControl createEditor() {

            var editor = new Sgry.Azuki.WinForms.AzukiControl();

            editor.Dock = DockStyle.Fill;

            _config.Editor.setOption(editor);
            editor.Highlighter = new MemoHighlighter(_config);
            editor.ColorScheme.SetMarkingDecoration(1, new UnderlineTextDecoration(LineStyle.Solid, Color.Transparent));
            editor.Font = new Font(_config.Editor.FontName, _config.Editor.FontSize);

            _panelManager.setPanel(editor);

            editor.Document.ContentChanged += (s, e) => {
                if (editor.Document.Length == 0) {
                    _panelManager.removePanel(editor, y => {
                        return true;
                    });
                    return;
                }

                var LineIndex = editor.Document.GetLineIndexFromCharIndex(e.Index);

                var nsa = (e.NewText.Length - e.NewText.Replace("\n", "").Length);
                var osa = (e.OldText.Length - e.OldText.Replace("\n", "").Length);

                _panelManager.removePanel(editor, y => {
                    return (y.Line > LineIndex && y.Line < LineIndex + Math.Abs(nsa - osa));
                });
                var LineHeadIndex = editor.Document.GetLineHeadIndexFromCharIndex(e.Index);
                var textlen = editor.Document.GetLineContentWithEolCode(LineIndex).Length;
                for (int i = osa + 1; i <= nsa; i++) {
                    textlen += editor.Document.GetLineContentWithEolCode(LineIndex + i).Length;
                }

                int b, en;
                if (e.Index < editor.Document.Length
                    && editor.Document.GetMarkedRange(e.Index, 1, out b, out en)) {
                    editor.Document.Unmark(b, en, 1);
                }

                var kk = editor.GetTextInRange(LineHeadIndex, LineHeadIndex + textlen);
                var ms = _regMark1.Matches(kk);

                _panelManager.removePanel(editor, x => {
                    return x.Line == LineIndex;
                });

                int lastline = LineIndex;
                for (int i = 0; i < ms.Count; i++) {
                    editor.Document.Mark(LineHeadIndex + ms[i].Index, LineHeadIndex + ms[i].Index + ms[i].Length, 1);

                    var imgpath = ms[i].Groups[2].Value;
                    if (_regImage.IsMatch(imgpath)) {
                        var pp = editor.GetPositionFromIndex(LineHeadIndex + ms[i].Index);
                        var line = editor.GetLineIndexFromCharIndex(LineHeadIndex + ms[i].Index);
                        var panel = _panelManager.addPanel(editor, imgpath, line, new Point(pp.X, pp.Y + editor.LineHeight));
                        panel.MouseDoubleClick += (s2, e2) => {
                            execute(imgpath);
                        };

                        lastline = line;
                    }
                }
                var panels = _panelManager.getPanels(editor);
                panels.ForEach(x => {
                    if (x.Line > lastline) {
                        x.Line += (nsa - osa);
                        var yy = editor.GetPositionFromIndex(x.Line, 0);
                        x.panel.Location = new Point(x.panel.Location.X, yy.Y + editor.LineHeight);
                    }
                });
            };

            editor.SizeChanged += (s, e) => {
                if (editor.ViewType == ViewType.WrappedProportional) {
                    
                }
            };
  
            editor.ScrollEvent += (s, e) => {
                if (e.ScrollOrientation != ScrollOrientation.VerticalScroll) {
                    var panels = _panelManager.getPanels(editor);
                    panels.ForEach(x => {
                        x.panel.Location = new Point(x.panel.Location.X, x.panel.Location.Y + e.NewValue);
                    });
                }
            };

            Func<Document, EventArgs, List<int>> markFunc = ((d, e)=>{
                IMouseEventArgs mea = (IMouseEventArgs)e;
                int urlBegin, urlEnd, selBegin, selEnd;
                var marklist = new List<int>(){0,1};
                foreach (var m in marklist){
                    if (mea.Index < d.Length && d.IsMarked(mea.Index, m)
                        && editor.View.TextAreaRectangle.Contains(mea.Location)) {
                        d.GetMarkedRange(mea.Index, m, out urlBegin, out urlEnd);
                        d.GetSelection(out selBegin, out selEnd);
                        if (selBegin != urlBegin && selEnd != urlEnd) {
                            d.SetSelection(urlBegin, urlEnd);
                        } else {
                            d.SetSelection(mea.Index, mea.Index);
                        }
                        mea.Handled = true;
                        return new List<int>(){m, urlBegin, urlEnd};
                    } 
                }

                return null;
            });
            editor.MouseDown += (s, e) => {
                int l, c, index;
                index = editor.GetIndexFromPosition((new Point(e.X, e.Y)));
                editor.Document.GetLineColumnIndexFromCharIndex(index, out l, out c);
                editor.Document.SetCaretIndex(l, c);
            };
            editor.MouseClick += (s, e) => {
                var doc = editor.Document;
                IMouseEventArgs mea = (IMouseEventArgs)e;
                int urlBegin, urlEnd, selBegin, selEnd;
                if (mea.Index < doc.Length && doc.IsMarked(mea.Index, Marking.Uri)
                    && editor.View.TextAreaRectangle.Contains(mea.Location)) {
                    // select entire URI if not selected, or deselect if selected.
                    doc.GetMarkedRange(mea.Index, Marking.Uri, out urlBegin, out urlEnd);
                    doc.GetSelection(out selBegin, out selEnd);
                    if (selBegin != urlBegin && selEnd != urlEnd) {
                        doc.SetSelection(urlBegin, urlEnd);
                    } else {
                        doc.SetSelection(mea.Index, mea.Index);
                    }
                    mea.Handled = true;
                } else {
                    if (e.Button == MouseButtons.Middle) {
                        Item item;
                        var lt = getItemFromLink(editor, out item);
                        if (lt == LinkType.Goto) {
                            setSubEditor(item.text, true);
                        } else if (lt == LinkType.ComeFrom) {

                        }
                    }
                }

            };
            editor.DoubleClick += (s, e) => {
                var res = markFunc(editor.Document, e);
                if (res == null) return;

                if (res[0] == 1) {
                    var match =reggoto.Match(editor.Document.GetTextInRange(res[1], res[2]));
                    if (match.Success) {
                        var t = match.Groups[1].Value;
                        var id = int.Parse(t);
                        string name;
                        var item = _m.getItem(id, out name);
                        if (item != null) {
                            getAllListView(getTabControl(name)).SetSelect(item);
                        }
                        return;
                    }
                    //var tt = convetURI2Path(editor.Document.GetTextInRange(res[1], res[2]));
                    match = regpath.Match(convetURI2Path(editor.Document.GetTextInRange(res[1], res[2])));
                    if (match.Success) {
                        var p = (match.Groups[1].Value);
                        if (File.Exists(p)) {

                        } else if (Directory.Exists(p)) {
                            //System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select," + p);
                        } else {
                            if (MessageBox.Show(string.Format("make {0}?", p), "Make Folder", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                                try {
                                    Directory.CreateDirectory(p);
                                } catch (Exception ex) {
                                    MessageBox.Show(ex.Message,"ERROR", MessageBoxButtons.OK,MessageBoxIcon.Error);
                                }
                            }
                        }
                        return;
                    }
                }
            };

            return editor;
        }

        private Item createItem(string text) {
            if (filelistiew.SelectedItems.Count > 0) {
                var name = filelistiew.SelectedItems[0].Text;
                var tb = getTabControl(name);
                var sellv = getSelectedListView(tb);
                var item = _m.createItem();
                item.text = item.text + Environment.NewLine + text;
                _m.getClass(name).Add(item);
                if (sellv.Name.Equals("all")) {
                    sellv.AddItem(item, true);
                } else {
                    var lv = getAllListView(tb);
                    //var item = m.createItem();
                    lv.AddItem(item,false);
                    sellv.AddItem(item, true);
                }
                if (sellv.SelectedIndices[0] == 0) {
                    SetMainEditorText(sellv.DataItems[0]);
                } else {
                    sellv.Items[0].Selected = true;
                }
                SaveFile(name);
                return item;
            }
            return null;
        }

        private LinkType getItemFromLink(Sgry.Azuki.WinForms.AzukiControl editor, out Item item) {
            item = null;
            var doc = editor.Document;
            var lineindex = doc.GetLineIndexFromCharIndex(editor.CaretIndex);
            string line = doc.GetLineContent(lineindex);
            var match = regcomefrom.Match(line);
            if (match.Success && match.Groups.Count == 3) {
                var id = int.Parse(match.Groups[2].Value);
                item = _m.getItem(id);
                return LinkType.ComeFrom;
            }

            match = reggoto.Match(line);
            if (match.Success && match.Groups.Count == 3) {
                var id = int.Parse(match.Groups[2].Value);
                item = _m.getItem(id);
                return LinkType.Goto;
            }

            return LinkType.None;
        }

        private List<Item> getLinkedItem(int id)
        {
            var items = new List<Item>();
            Regex reg = new Regex(@">>>" + id.ToString() + @"\s", RegexOptions.Compiled);
            _m.acts.ForEach(x =>
            {
                items.AddRange(x._items.FindAll(y =>
                {
                    return reg.IsMatch(y.text);
                }));
            });
            return items;
        }
        private List<Item> getLinkItem(Item item) {
            var list = new List<Item>();
            var matchs = reggoto.Matches(item.text);
            for (int i = 0; i < matchs.Count; i++) {
                var match = matchs[i];
                if (match.Groups.Count == 3) {
                    var id = int.Parse(match.Groups[2].Value);
                    item = _m.getItem(id);
                    if (item != null) list.Add(item);
                }
            }
            return list;
        }
        private List<Item> getLinkeItem(int id)
        {
            var items = new List<Item>();
            _m.acts.ForEach(x =>
            {
                items.AddRange(x._items.FindAll(y =>
                {
                    return y.ID == id;
                }));
            });
            return items;
        }

        //private string makeLink(Item item) {
        //    return String.Format(">>>{0} {1} {2}", item.id, item.title, item.date.ToString("yyyy/MM/dd_hh:mmm"));
        //}

        private void SaveFile(string name) {
            _m.Save(name);
        }

        private ListViewEx getSelectedListView(TabControl tb) {

            return tb.SelectedTab.Controls[0] as ListViewEx;
        }

        private ListViewEx getAllListView(TabControl tb) {
            for (int i = 0; i < tb.TabPages.Count; i++) {
                ListViewEx lv = tb.TabPages[i].Controls[0] as ListViewEx;
                if (lv.Name.Equals("all")) {
                    return lv;
                }
            }
            return null;
        }

        private void setSubEditor(string text, bool stack) {
            if (stack) {
                _subEditor.Text = text + Environment.NewLine + _subEditor.Text;
            } else {
                _subEditor.Text = text;
            }
        }

        private void createListView(string name, string title, List<Item> items) {
            var tb = getTabControl(name);
            tb.BringToFront();

            var tbp = new TabPage();
            tbp.Text = title;

            var lv = new ListViewEx(_config);
            lv.ContextMenuStrip = ListViewContextMenuStrip3;
            lv.Dock = DockStyle.Fill;
            lv.Margin = new Padding(0);
            lv.ItemSelectionChanged += (s, e) => {

                if (e.IsSelected) {
                    var item = lv.DataItems[e.ItemIndex];
                    SetMainEditorText(item, false);
                }
            };
            lv.MouseDoubleClick += (s, e) => {

            };
            lv.GotFocus += (s, e) => {
                copyToolStripMenuItem1.Enabled = true;
            };
            lv.LostFocus += (s, e) => {
                copyToolStripMenuItem1.Enabled = false;
            };
            lv.ItemDrag += new ItemDragEventHandler(lv_ItemDrag);

            lv.ClearItem();
            lv.DataItems = items;
            tbp.Controls.Add(lv);
            tb.TabPages.Add(tbp);
            tb.SelectedTab = tbp;
        }

        private void createListView(string name, string word) {
            //var tb = getTabControl(name);
            //tb.BringToFront();

            //var tbp = new TabPage();
            //tbp.Text = word;
            //var lv = new ListViewEx();
            //lv.ContextMenuStrip = ListViewContextMenuStrip3;
            //lv.Dock= DockStyle.Fill;
            //lv.Margin = new Padding(0);
            //lv.ItemSelectionChanged += (s, e) => {

            //    if (e.IsSelected) {
            //        var item = lv.DataItems[e.ItemIndex];
            //        SetMainEditorText(item, false);
            //    }
            //};
            //lv.MouseDoubleClick += (s, e) =>
            //{

            //};
            //lv.GotFocus += (s, e) => {
            //    copyToolStripMenuItem1.Enabled = true;
            //};
            //lv.LostFocus += (s, e) => {
            //    copyToolStripMenuItem1.Enabled = false;
            //};

            Regex rg = new Regex(word, RegexOptions.IgnoreCase | RegexOptions.Compiled);
            var lists = _m.getClass(name)._items.FindAll(x => {
                return rg.IsMatch(x.text);
            });
            
            //lv.ClearItem();
            //lv.DataItems = lists;
            //tbp.Controls.Add(lv);
            //tb.TabPages.Add(tbp);
            //tb.SelectedTab = tbp;

            createListView(name, word, lists);
        }

        private TabControl getSelectedTabControl(){
            return getTabControl(filelistiew.SelectedItems[0].Text);
        }

        private TabControl getTabControl(string name) {
            if (!tabcontrols.ContainsKey(name)) {
                TabControl tb = new TabControl();
                tb.Dock = DockStyle.Fill;
                tb.Selected += (s,e) =>
                {
                    if (tb.SelectedTab.Controls[0] is ListView)
                    {
                        var lv = tb.SelectedTab.Controls[0] as ListView;
                        if (lv.SelectedIndices.Count == 0 && lv.Items.Count>0)
                        {
                            lv.Items[0].Selected = true;
                        }
                    }
                };

                var lvex = new ListViewEx(_config);
                lvex.ContextMenuStrip = ListViewContextMenuStrip3;
                lvex.AllowDrop = true;
                lvex.Dock = DockStyle.Fill;
                lvex.Name = "all";
                lvex.ItemSelectionChanged += (s, e) => {
                    if (e.IsSelected) {
                        SetMainEditorText(lvex.DataItems[e.ItemIndex]);
                    }
                };
                lvex.SelectedIndexChanged += (s, e) => {
                    if (lvex.SelectedIndices.Count == 0) {
                        SetMainEditorText(null, true);
                    } 
                };
                lvex.GotFocus += (s, e) => {
                    copyToolStripMenuItem1.Enabled = true;
                };
                lvex.LostFocus += (s, e) => {
                    copyToolStripMenuItem1.Enabled = false;
                };
                lvex.ItemDrag += new ItemDragEventHandler(lv_ItemDrag);

                var tbp = new TabPage();
                tbp.Name="all";
                tbp.Controls.Add(lvex);
                tb.TabPages.Add(tbp);
                tb.SendToBack();
                TabPanel.Controls.Add(tb);

                tabcontrols.Add(name, tb);

                var list = _filelists.Find(x => {
                    return x.FileName.Equals(name);
                });
                if (list != null) {
                    list.Words.ForEach(x => {
                        createListView(name, x);
                    });
                    tb.SelectedTab = tbp;
                }

            }
            return tabcontrols[name];
        }

        void lv_ItemDrag(object sender, ItemDragEventArgs e) {
            var lv = sender as ListView;
            lv.DoDragDrop((ListViewItem)e.Item, DragDropEffects.Copy | DragDropEffects.Move);   
        }

        private void SetMainEditorText(Item item){

            SetMainEditorText(item, false);
            //if (item.text.Length > 3)
            //{
            //    editor.Document.Mark(0, 2, 1);
            //}
        }

        private void SetMainEditorText(Item item, bool isreadonly) {
            if (item == null){
                DateTimeLabel.Text = "";
                _mainEditor.Text = "";
                _mainEditor.Document.IsDirty = false;
                _mainEditor.Document.IsReadOnly = true;
            }
            else
            {
                DateTimeLabel.Text = item.Date.ToString();
                _mainEditor.Text = string.Empty;
                _mainEditor.Text = item.text;
                _mainEditor.Document.IsDirty = false;
                _mainEditor.Document.IsReadOnly = isreadonly;

                //setMark(mainEditor);
            }
            _mainEditor.Document.ClearHistory();
            //if (mainEditor.Text.Length > 2) {
            //    mainEditor.Document.Mark(0, 2, 1);
            //}
        }

        private void setMark(Sgry.Azuki.WinForms.AzukiControl editor) {
            _panelManager.removePanel(editor, x => {
                return true;
            });
            var ms = _regMark1.Matches(editor.Text);
            for (int i = 0; i < ms.Count; i++) {
                editor.Document.Mark(ms[i].Index, ms[i].Index + ms[i].Length, 1);

                var imgpath = ms[i].Groups[2].Value;
                if (_regImage.IsMatch(imgpath)) {
                    var pp = editor.GetPositionFromIndex(ms[i].Index);
                    var line = editor.GetLineIndexFromCharIndex(ms[i].Index);
                    var panel = _panelManager.addPanel(editor, imgpath, line, new Point(pp.X, pp.Y + editor.LineHeight));
                    panel.MouseDoubleClick += (s2, e2) => {
                        execute(imgpath);
                    };
                }
            } 
        }

        private void ConfigLoad() {
            if (!Directory.Exists("data")) {
                Directory.CreateDirectory("data");
            }
            try {
                _config = XMLSerializer.Deserialize<Config>("config.xml");
            } catch (Exception) {

                _config = new Config();
                _config.setDefault();
            }

            LoadFileList();
        }
        private void ConfigSave() {
            _config.Editor.IsWrap = WraptoolStripButton.Checked;
            _config.FileListViewW = splitContainer1.SplitterDistance;
            _config.MemoListViewW = splitContainer3.SplitterDistance;
            _config.SubPanelW = splitContainer2.SplitterDistance;

            XMLSerializer.Serialize<Config>("config.xml", _config);

            SaveFileList();
        }

        private void LoadFileList() {
            _filelists = null;
            try {
                _filelists = XMLSerializer.Deserialize<List<FileList>>(getDatePath("FileList.xml"));
            }
            catch (Exception) {
                _filelists = new List<FileList>();
            }

            if (_filelists.Count == 0) {
                _filelists.Add(new FileList() { FileName = _config.NewFileName });
                _filelists.Add(new FileList() { FileName = _config.TrustFileName });
                _filelists.ForEach(x => {
                    XMLSerializer.Serialize<Class1>(getDatePath(x.FileName), _m.getClass(x.FileName));
                });
            } else if (_filelists.Find(x => { return _config.TrustFileName.Equals(x.FileName); }) == null) {
                _filelists.Add(new FileList() { FileName = _config.TrustFileName });
                _filelists.ForEach(x => {
                    XMLSerializer.Serialize<Class1>(getDatePath(x.FileName), _m.getClass(x.FileName));
                });
            }

            _filelists.ForEach(x => {
                var item = new ListViewItem(x.FileName);
                item.ImageIndex = x.FileName != _config.TrustFileName ? 0 : 1;
                item.Name = x.FileName;
                filelistiew.Items.Add(item);
            });
        }
        private void SaveFileList() {
            var filelists = new List<FileList>();
            var items = filelistiew.Items;
            for (int i = 0; i < items.Count; i++) {
                var text = items[i].Text;
                var fl = new FileList() { FileName = text };
                if (tabcontrols.ContainsKey(text)) {
                    var tb = tabcontrols[text];
                    for (int j = 1; j < tb.TabPages.Count; j++) {
                        fl.Words.Add(tb.TabPages[j].Text);
                    }        
                }
                filelists.Add(fl);
            }
            XMLSerializer.Serialize<List<FileList>>(getDatePath("FileList.xml"), filelists);            
        }

        public void RenameFile(string from, string to) {
            if (_config.FileListName.Equals(to)) {
                throw new Exception("can't create FileList.xml");
            }
            File.Move(getDatePath(from), getDatePath(to));
            if (tabcontrols.ContainsKey(from)) {
                var tb = tabcontrols[from];
                tabcontrols.Remove(from);
                tabcontrols.Add(to, tb);
            }
        }

        private bool editenable = true;
        private bool EnableEdit {
            get { return editenable; }
            set {
                editenable = value;
                if (editenable) {

                } else {

                }
            }
        }

        private void moveFileListViewItem(int updawn) {
            if (filelistiew.SelectedItems.Count != 1) return;
            if (updawn > 0) {
                if (filelistiew.SelectedItems[0].Index == 0) {
                    return;
                }
            }
            if (updawn < 0) {
                if (filelistiew.SelectedItems[0].Index >= filelistiew.SelectedItems.Count) {
                    return;
                }
            }

            var name = filelistiew.SelectedItems[0].Text;
            var index = filelistiew.SelectedItems[0].Index;

            filelistiew.BeginUpdate();
            filelistiew.Items.Clear();

            var c = _m.getClass(name);
            _m.acts.Remove(c);
            _m.acts.Insert(index + updawn, c);
            _m.acts.ForEach(x => {
                var item = new ListViewItem(x.name);
                item.Name = x.name;
                item.ImageIndex = x.name != _config.TrustFileName ? 0 : 1;
                filelistiew.Items.Add(item);
            });

            filelistiew.EndUpdate();

            filelistiew.Items[index + updawn].Selected = true;
        }

        private void newFileToolStripMenuItem_Click(object sender, EventArgs e) {
            var name = _config.NewFileName;
            var n = Path.GetFileNameWithoutExtension(name);
            var ext = Path.GetExtension(name);
            var cnt = 1;

            while (filelistiew.Items.IndexOfKey(name) >= 0) {
                name = string.Format("{0}{1}.{2}", n, cnt.ToString(), ext);
                cnt++;
            }
            //m.Add(name);
            _m.Insert(0, name);
            XMLSerializer.Serialize<Class1>(getDatePath(name), _m.getClass(name));

            filelistiew.BeginUpdate();
            filelistiew.Items.Clear();

            var newitem = new ListViewItem(name);
            newitem.Name = name;
            newitem.ImageIndex = name != _config.TrustFileName ? 0 : 1;
            filelistiew.Items.Add(newitem);
            newitem.Selected = true;

            _m.acts.ForEach(x => {
                if (!x.name.Equals(newitem.Name)) {
                    var item = new ListViewItem(x.name);
                    item.Name = x.name;
                    item.ImageIndex = x.name != _config.TrustFileName ? 0 : 1;
                    filelistiew.Items.Add(item);
                }
            });
            filelistiew.EndUpdate();
        }

        private void deleteFileToolStripMenuItem_Click(object sender, EventArgs e) {
            if (filelistiew.SelectedItems.Count > 0 && filelistiew.SelectedItems[0].Text != _config.TrustFileName) {
                var name = filelistiew.SelectedItems[0].Text;
                _m.Remove(name);
                string filePath = getDatePath(name);
                FileSystem.DeleteFile(
                  filePath,
                  UIOption.OnlyErrorDialogs,
                  RecycleOption.SendToRecycleBin);
            }
        }

        private void renameFileToolStripMenuItem_Click(object sender, EventArgs e) {
            if (filelistiew.SelectedItems.Count > 0) {
                filelistiew.SelectedItems[0].BeginEdit();
            }
        }

        private void upFileToolStripMenuItem_Click(object sender, EventArgs e) {
            moveFileListViewItem(1);
        }

        private void downFileToolStripMenuItem_Click(object sender, EventArgs e) {
            moveFileListViewItem(-1);
        }

        private void newMemoToolStripMenuItem_Click(object sender, EventArgs e) {
            if (!EnableEdit) return;
            createItem(string.Empty);
        }
        
        //TODO
        private void newMemoWithLinkToolStripMenuItem_Click(object sender, EventArgs e) {
            var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
            if (item != null) {
                createItem(_config.makeLink(item));
            }
        }
        private void newMemoWithParentLinkToolStripMenuItem_Click(object sender, EventArgs e) {
            var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
            if (item != null) {
                var list = getLinkItem(item);
                if (list.Count > 1) {

                    var f = new ItemListForm();
                    list.ForEach(x => {
                        f.listBox1.Items.Add(_config.makeLink(x));
                    });
                    var link = string.Empty;
                    f.KeyDown += (s2, e2) => {
                        if (e2.KeyCode == Keys.Return && f.listBox1.SelectedItem != null) {
                            link = f.listBox1.SelectedItem.ToString();
                            f.DialogResult = DialogResult.OK;
                        }
                    };
                    f.listBox1.MouseDoubleClick += (s2, e2) => {
                        if (f.listBox1.SelectedItem != null) {
                            link = f.listBox1.SelectedItem.ToString();
                            f.DialogResult = DialogResult.OK;
                        }
                    };
                    if (f.ShowDialog() == DialogResult.OK) {
                        if (link != string.Empty) {
                            createItem(link);
                        }
                    }
                    f.Close();
                } else {
                    var sb = new StringBuilder();
                    list.ForEach(x => {
                        sb.AppendLine(_config.makeLink(x));
                    });
                    createItem(sb.ToString());
                }
            }
        }

        private void deleteMemoToolStripMenuItem_Click(object sender, EventArgs e) {
            if (!EnableEdit) return;

            var name = filelistiew.SelectedItems[0].Text;
            var fromtb = getTabControl(name);
            var lv = getSelectedListView(fromtb);
            var item = lv.DataItems[lv.SelectedIndices[0]];

            for (int i = 0; i < fromtb.TabPages.Count; i++) {
                var tbp = fromtb.TabPages[i];
                if (tbp.Controls[0] is ListViewEx) {
                    var lvex = tbp.Controls[0] as ListViewEx;
                    lvex.DeleteItem(item);
                }
            }
            _m.getClass(name).Delete(item);

            if (lv.SelectedIndices[0] == 0) {
                SetMainEditorText(lv.DataItems[0]);
            } else {
                lv.Items[0].Selected = true;
            }

            SaveFile(name);

            if (!name.Equals(_config.TrustFileName)) {
                lv = getAllListView(getTabControl(_config.TrustFileName));
                lv.AddItem(item,false);
                _m.getClass(name).Add(item);
                SaveFile(_config.TrustFileName);
            }
        }

        private void editDateTimeToolStripMenuItem_Click(object sender, EventArgs e) {
            var lv = getSelectedListView(getSelectedTabControl());
            var item = lv.SelectedItem;
            if (item == null) return;

            DateTimeEditForm de = new DateTimeEditForm();
            de.Value = item.Date;
            var re = de.ShowDialog();
            if (re == DialogResult.OK && de.Value != item.Date) {
                item.Date = de.Value;
                //lv.SortByDateTime();
            }
            de.Close();
        }

        private void wrapToolStripMenuItem_Click(object sender, EventArgs e) {
            if (WraptoolStripButton.Checked) {
                _mainEditor.ViewType = Sgry.Azuki.ViewType.WrappedProportional;
                _mainEditor.ViewWidth = _mainEditor.ClientSize.Width - _mainEditor.View.HRulerUnitWidth * 2;
                _subEditor.ViewType = Sgry.Azuki.ViewType.WrappedProportional;
                _subEditor.ViewWidth = _subEditor.ClientSize.Width - _subEditor.View.HRulerUnitWidth * 2;

            } else {
                _mainEditor.ViewType = Sgry.Azuki.ViewType.Proportional;
                _subEditor.ViewType = Sgry.Azuki.ViewType.Proportional;
            }
            WraptoolStripButton.Checked = WraptoolStripButton.Checked;
        }

        private void subPanleToolStripMenuItem_Click(object sender, EventArgs e) {
            splitContainer2.Panel2Collapsed = !subPanleToolStripMenuItem.Checked;
            showSubPaneltoolStripButton.Checked = subPanleToolStripMenuItem.Checked;
            
        }

        private void ThumbnailToolStripMenuItem_Click(object sender, EventArgs e) {
            thbutton1_Click();
        }

        private void showMemoListtoolStripMenuItem_Click(object sender, EventArgs e) {
            var lv = getSelectedListView(getSelectedTabControl());
            var sb = new StringBuilder();
            lv.DataItems.ForEach(x => {
                sb.AppendLine(_config.makeListHeader(x));
                sb.AppendLine(x.text);
                sb.AppendLine("");
            });
            setSubEditor(sb.ToString(), false);
        }

        private void showLinkedMemoToolStripMenuItem_Click(object sender, EventArgs e) {
            var name = filelistiew.SelectedItems[0].Text;
            var lv = getSelectedListView(getTabControl(name));
            if (lv.SelectedIndices.Count > 0) {
                var item = lv.DataItems[lv.SelectedIndices[0]];
                var items = getLinkeItem(item.ID);
                createListView(name, ">>>" + item.ID.ToString(), items);
            }
        }


        private void WraptoolStripButton_Click(object sender, EventArgs e) {
            wrapToolStripMenuItem_Click(null, null);
            wrapToolStripMenuItem.Checked = WraptoolStripButton.Checked;
        }

        private void showSubPaneltoolStripButton_Click(object sender, EventArgs e) {
            splitContainer2.Panel2Collapsed = !showSubPaneltoolStripButton.Checked;
            subPanleToolStripMenuItem.Checked = showSubPaneltoolStripButton.Checked;
        }

        private void copyToolStripMenuItem1_Click(object sender, EventArgs e) {
            if (getSelectedListView(getSelectedTabControl()).Focused) {
                var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
                string d = _config.makeLink(item);// string.Format("", item.id, item.title, item.date.ToString("yyyy/MM/dd hh:mmm"));
                Clipboard.SetDataObject(d);
            }
        }

        //editor
        private void editorcontextMenuStrip_Opening(object sender, CancelEventArgs e) {

            if (EditorContextMenuStrip == _mainEditor.ContextMenuStrip) {
                copytoolStripMenuItem.Enabled = _mainEditor.GetSelectedText() != string.Empty;
                cuttoolStripMenuItem.Enabled = _mainEditor.GetSelectedText() != string.Empty;
                pastetoolStripMenuItem.Enabled = _mainEditor.CanPaste;
                pasteAsQuotationtoolStripMenuItem.Enabled = _mainEditor.CanPaste;
                editDateTimeToolStripMenuItem.Enabled = true;

                undotoolStripMenuItem.Enabled = _mainEditor.CanUndo;
                redotoolStripMenuItem.Enabled = _mainEditor.CanRedo;
                selectAlltoolStripMenuItem.Enabled = true;
                
            } else {
                cuttoolStripMenuItem.Enabled = false;
                pastetoolStripMenuItem.Enabled = false;
                pasteAsQuotationtoolStripMenuItem.Enabled = false;
                editDateTimeToolStripMenuItem.Enabled = false;
                undotoolStripMenuItem.Enabled = false;
                redotoolStripMenuItem.Enabled = false;
                selectAlltoolStripMenuItem.Enabled = false;
            }
        }

        private void undotoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = _mainEditor.Focused ? _mainEditor : _subEditor;
            editor.Undo();
        }

        private void redotoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = _mainEditor.Focused ? _mainEditor : _subEditor;
            editor.Redo();
        }

        private void cuttoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = _mainEditor.Focused ? _mainEditor : _subEditor;
            editor.Cut();
        }

        private void copytoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = _mainEditor.Focused ? _mainEditor : _subEditor;
            editor.Copy();
        }

        private void pastetoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = _mainEditor.Focused ? _mainEditor : _subEditor;
            if (editor.IsReadOnly) return;

            if (Clipboard.ContainsText()) {
                editor.Paste();
            } else if (Clipboard.ContainsImage()) {
                var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
                if (item != null) {
                    var dir = Directory.CreateDirectory(item.ID.ToString());
                    if (dir.Exists) {
                        //var img = Clipboard.GetImage();
                        //img.Save(item.id.ToString() + ".png", System.Drawing.Imaging.ImageFormat.Png);
                        //img.Dispose();
                        //convetPath2URI(
                    }
                }

            } else if (Clipboard.ContainsFileDropList()) {
                var sb = new StringBuilder();
                var files = Clipboard.GetFileDropList();
                for (int i = 0; i < files.Count; i++){
                    //sb.AppendLine(convetPath2URI(files[i]));
                }
                editor.Document.Replace(sb.ToString());
            }
        }

        private void pasteAsQuotationtoolStripMenuItem_Click(object sender, EventArgs e) {

        }

        private void selectAlltoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = _mainEditor.Focused ? _mainEditor : _subEditor;
            editor.SelectAll();
        }

        private void insertDatetoolStripMenuItem_Click(object sender, EventArgs e) {

        }

        private void optionToolStripMenuItem_Click(object sender, EventArgs e) {
            var gf = new ConfigForm(_config);
            var ret = gf.ShowDialog();
            if (ret == DialogResult.OK) {

                _panelManager.Images.ImageSize = _config.ThumbnailSize;

                _mainEditor.Font = new Font(_config.Editor.FontName, _config.Editor.FontSize, FontStyle.Regular);
                _config.Editor.setOption(_mainEditor);
                _mainEditor.Document.Highlighter = new MemoHighlighter(_config);
                _mainEditor.Refresh();
                setMark(_mainEditor);

                _subEditor.Font = new Font(_config.Editor.FontName, _config.Editor.FontSize, FontStyle.Regular);
                _config.Editor.setOption(_subEditor);
                _subEditor.Document.Highlighter = new MemoHighlighter(_config);
                _subEditor.Refresh();
                setMark(_subEditor);
            }
            gf.Close();
        }

        private void FileListViewContextMenuStrip_Opening(object sender, CancelEventArgs e) {
            if (filelistiew.SelectedItems.Count == 1) {
                var item = filelistiew.SelectedItems[0];
                deleteFileToolStripMenuItem1.Enabled = !item.Text.Equals(_config.TrustFileName);
                renameFileToolStripMenuItem1.Enabled = !item.Text.Equals(_config.TrustFileName);
            } else {
            }
        }

        private void editorsearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_mainEditor.Focused)
            {
                if (searchmain == null)
                {
                //    searchmain = new EditorSearchControl();
                //    searchmain.Dock = DockStyle.Bottom;
                //    searchmain.nextbutton.Click += (s2, e2) =>
                //    {
                //        var res = mainEditor.Document.FindNext(searchmain.editorSearchcomboBox.Text, mainEditor.CaretIndex);
                //        if (res != null) mainEditor.SetSelection(res.Begin, res.End);
                //    };
                //    searchmain.upbutton.Click += (s2, e2) =>
                //    {
                //        var res = mainEditor.Document.FindPrev(searchmain.editorSearchcomboBox.Text, mainEditor.CaretIndex);
                //        if (res != null) mainEditor.SetSelection(res.Begin, res.End);
                //    };
                //    searchmain.closebutton.Click += (s2, e2) =>
                //    {
                //        MainEditorPanel.Controls.Remove(searchmain);
                //    };
                    searchmain = createSearchPanel(_mainEditor, MainEditorPanel);
                }
                MainEditorPanel.Controls.Add(searchmain);
            }
            else if (_subEditor.Focused)
            {
                if (searchsub == null)
                {
                    searchsub = createSearchPanel(_subEditor, tabPage1);
                }
                tabPage1.Controls.Add(searchsub);
            }
        }
        private EditorSearchControl createSearchPanel(Sgry.Azuki.WinForms.AzukiControl editor, Control parent)
        {
            var search = new EditorSearchControl();
            search.Dock = DockStyle.Bottom;
            search.nextbutton.Click += (s2, e2) =>
            {
                var res = editor.Document.FindNext(searchmain.editorSearchcomboBox.Text, editor.CaretIndex);
                if (res != null) editor.SetSelection(res.Begin, res.End);
            };
            search.upbutton.Click += (s2, e2) =>
            {
                var res = editor.Document.FindPrev(searchmain.editorSearchcomboBox.Text, editor.CaretIndex);
                if (res != null) editor.SetSelection(res.Begin, res.End);
            };
            search.closebutton.Click += (s2, e2) =>
            {
                parent.Controls.Remove(searchmain);
            };
            return search;
        }

        private void emptyToolStripMenuItem1_Click(object sender, EventArgs e){
            if (filelistiew.SelectedItems.Count == 1) {
                var item = filelistiew.SelectedItems[0];
                var name = item.Text;
                if (name.Equals(_config.TrustFileName)) {
                    var tb = getTabControl(name);
                    for (int i = 0; i < tb.TabPages.Count; i++){
                        var tbp = tb.TabPages[i];
                        if (tbp.Controls[0] is ListViewEx){
                            var lvex = tbp.Controls[0] as ListViewEx;
                            if (lvex.Name.Equals("all")){
                                lvex.ClearItem();
                            }
                            else{
                                tb.TabPages.Remove(tbp);
                            }
                        }
                    }
                    _m.getClass(_config.TrustFileName).clear();
                    SaveFile(_config.TrustFileName);
                }
            }
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Visible = true;
                this.Activate();
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!isexit)
            {
                e.Cancel = true;
                this.Visible = false;
            }
        }
        bool isexit = false;
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isexit = true;
            this.Close();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this._mainEditor.Dispose();
            this._subEditor.Dispose();
            ConfigSave();
        }

        //TODO notifyIcon1
        private void showToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Visible = true;
            this.Activate();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            exitToolStripMenuItem_Click(null, null);
        }

        private void editToolStripMenuItem_DropDownOpening(object sender, EventArgs e) {
            newMemoWithLinkToolStripMenuItem.Enabled = getSelectedListView(getSelectedTabControl()).SelectedIndices.Count>0;
        }

        private void ListViewContextMenuStrip3_Opening(object sender, CancelEventArgs e) {
            var enable = getSelectedListView(getSelectedTabControl()).SelectedIndices.Count > 0;
            deleteMemoToolStripMenuItem3.Enabled = enable;
            newMemoWithLinkToolStripMenuItem3.Enabled = enable;
            newMemoWithParentLinkToolStripMenuItem3.Enabled = enable;
        }

        private void openParentDirectoryToolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = _mainEditor;
            var doc = editor.Document;
            var index = editor.CaretIndex;
            int urlBegin, urlEnd, selBegin, selEnd;
            if (index < doc.Length && doc.IsMarked(index, 1)) {
                // select entire URI if not selected, or deselect if selected.
                doc.GetMarkedRange(index, 1, out urlBegin, out urlEnd);
                doc.GetSelection(out selBegin, out selEnd);
                if (selBegin != urlBegin && selEnd != urlEnd) {
                    doc.SetSelection(urlBegin, urlEnd);

                    var match = regpath.Match(convetURI2Path(editor.Document.GetTextInRange(urlBegin, urlEnd)));
                    if (match.Success) {
                        var p = (match.Groups[1].Value);
                        //var pp = Path.GetDirectoryName(p);
                        openFolder(p, true);
                    }
                }
            } 

        }

        private void insertLinkAsFileToolStripMenuItem2_Click(object sender, EventArgs e) {
            var c = (sender as ToolStripMenuItem).Owner;
            var fileNames = c.Tag as string[];
            var sb = new StringBuilder();
            foreach (var file in fileNames) {
                sb.AppendLine(convetPath2URI("file:///", file));
            }
            var index = _mainEditor.Document.CaretIndex;
            _mainEditor.Document.Replace(sb.ToString(), index, index);
        }

        private void insertLinkImageAsGotoToolStripMenuItem2_Click(object sender, EventArgs e) {
            var c = (sender as ToolStripMenuItem).Owner;
            var fileNames = c.Tag as string[];

            int n = (int)Math.Ceiling((double)_config.ThumbnailSize.Height / (double)_mainEditor.LineHeight);
            var sbn = new StringBuilder();
            for (int i = 0; i < n; i++) {
                sbn.Append(_mainEditor.Document.EolCode);
            }

            var sb = new StringBuilder();
            foreach (var file in fileNames) {
                sb.AppendLine(convetPath2URI(">>>", file));
                if (_regImage.IsMatch(file)) {
                    sb.Append(sbn.ToString());
                }
            }
            var index = _mainEditor.Document.CaretIndex;
            _mainEditor.Document.Replace(sb.ToString(), index, index);
        }
    }
}
