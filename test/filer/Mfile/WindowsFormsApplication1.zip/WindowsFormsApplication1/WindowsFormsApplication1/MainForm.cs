﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;
using Sgry.Azuki;
using Microsoft.VisualBasic.FileIO;
using WindowsFormsApplication1.Properties;
using Sgry.Azuki.WinForms;

namespace WindowsFormsApplication1
{
    enum LinkType {
        None,
        Goto,
        ComeFrom
    }

    public partial class MainForm : Form
    {
        Sgry.Azuki.WinForms.AzukiControl mainEditor, subEditor;

        Config config;
        manager m;
        Dictionary<string, TabControl> tabcontrols = new Dictionary<string, TabControl>();

        private FileListView filelistiew;
        private EditorSearchControl searchmain, searchsub;

        Regex regcomefrom = new Regex(@"([^<]<<<|^<<<)([0-9]+)[^0-9]*", RegexOptions.Compiled);
        //Regex reggoto = new Regex(@"([^>]>>>|^>>>)([0-9]+)[^0-9]*", RegexOptions.Compiled);
        Regex reggoto = new Regex(@">>>([0-9]+)[^0-9]*", RegexOptions.Compiled);

        Regex regpath = new Regex(@">>>([a-zA-Z]:\\[^/:\*\?<>\|]*)", RegexOptions.Compiled);

        public string getDatePath(string file) {
            return Path.Combine(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "data"), file);
        }

        private string convetPath2URI(string path) {
            //Uri u = new Uri(string.Format("file:///{0}", path));
            //return u.AbsoluteUri;
            //var reps = config.symbols.FindAll(x => {
            //    return path.Contains(x.symbol);
            //});
            config.symbols.ForEach(x => {
                path = path.Replace(x.value, x.symbol);
            });
            return string.Format(">>>{0}", path.Replace(" ", "%20"));
        }
        private string convetURI2Path(string uri) {
            //Uri u = new Uri(string.Format("file:///{0}",uri.Replace(">>>", "")));
            //return string.Format(@"""{0}""",u.LocalPath);
            config.symbols.ForEach(x => {
                uri = uri.Replace(x.symbol, x.value);
            });
            //return string.Format(@"""{0}""", uri.Replace(">>>", "").Replace("%20", " "));
            return string.Format(@"{0}", uri.Replace("%20", " "));
        }

        ViewPanelManager panelnamager;

        public MainForm()
        {
            InitializeComponent();

            filelistiew = new FileListView();
            filelistiew.View = View.LargeIcon;
            filelistiew.LargeImageList = FileimageList;
            filelistiew.Dock = DockStyle.Fill;
            filelistiew.DragOver+=new DragEventHandler(filelistiew_DragOver);
            filelistiew.DragDrop+=new DragEventHandler(filelistiew_DragDrop);
            splitContainer1.Panel1.Controls.Add(filelistiew);


            m = new manager();
            m.dataDir = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "data");

            ConfigLoad();


            Marking.Register(new MarkingInfo(1, "test", MouseCursor.Hand));

            this.Load += (s, e) => {
                if (filelistiew.Items.Count > 0) {
                    filelistiew.Items[0].Selected = true;
                }
                WraptoolStripButton.Checked = config.editorconfig.IsWrap;
                wrapToolStripMenuItem.Checked = config.editorconfig.IsWrap;
            };

            mainEditor = createEditor();
            //panelnamager=new ViewPanelManager(mainEditor, new Size(100,80));
            panelnamager = new ViewPanelManager(new Size(100, 80));


            MainEditorPanel.Controls.Add(mainEditor);
            mainEditor.AllowDrop = true;
            mainEditor.SetKeyBind(Keys.Control | Keys.C, (x) => {
                if (mainEditor.GetSelectedText() != string.Empty) {
                    mainEditor.Copy();
                }
            });
            mainEditor.SetKeyBind(Keys.Control | Keys.X, (x) => {
                if (mainEditor.GetSelectedText() != string.Empty) {
                    //if (mainEditor.GetSelectedText().Contains("\r\n")){
                    //    elinetype = EditLineType.MultiLine;
                    //}else{
                    //    elinetype = EditLineType.SingelLine;
                    //}
                    //etype = EditType.Cut;
                    //int s, e;
                    //mainEditor.Document.GetSelection(out s, out e);
                    //sline = s < e ? s : e;
                    //sline = mainEditor.Document.GetLineIndexFromCharIndex(s);
                    //eline = mainEditor.Document.GetLineIndexFromCharIndex(e);

                    //panels.RemoveAll(y => {
                    //    return (y.line > sline && y.line < eline);
                    //});

                    mainEditor.Cut();
                }
            });
           
            mainEditor.SetKeyBind(Keys.Control | Keys.V, (x) => {

                pastetoolStripMenuItem_Click(null, null);
                //if (Clipboard.ContainsText()) {
                //    mainEditor.Paste();
                //} else if (Clipboard.ContainsImage()) {
                //    var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
                //    if (item != null) {
                //       var dir = Directory.CreateDirectory(item.id.ToString());
                //       if (dir.Exists) {
                //           var img = Clipboard.GetImage();
                //           img.Save(item.id.ToString() + ".png", System.Drawing.Imaging.ImageFormat.Png);
                //           //convetPath2URI(
                //       }
                //    }
                //} else if (Clipboard.ContainsFileDropList()) {
                //    var files = Clipboard.GetFileDropList();                
                //}
            });
            mainEditor.KeyDown += (s, e) => {
                
            };
            mainEditor.GotFocus += (s, e) => {
                mainEditor.ContextMenuStrip = editorcontextMenuStrip;

            };

            mainEditor.DragOver += (s, e) => {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)){
                    e.Effect = DragDropEffects.Copy;

                    if(!mainEditor.Focused){
                        mainEditor.Focus();
                    }

                    int l, c, index; 
                    index = mainEditor.GetIndexFromPosition(mainEditor.PointToClient(new Point(e.X, e.Y)));
                    var pos = mainEditor.GetPositionFromIndex(index);
                    mainEditor.Document.GetLineColumnIndexFromCharIndex(index, out l, out c);
                    mainEditor.Document.SetCaretIndex(l, c);
                }
            };
            mainEditor.DragDrop += (s, e) => {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    string[] fileName = (string[])e.Data.GetData(DataFormats.FileDrop, false);
                    var sb = new StringBuilder();
                    foreach (var file in fileName){
		               //sb.AppendLine(string.Format("file:///{0}", file));
                       sb.AppendLine(convetPath2URI(file));
                    }
                    
                    var point = mainEditor.PointToClient(new Point(e.X, e.Y));
                    var index = mainEditor.GetIndexFromPosition(point);
                    mainEditor.Document.Replace(sb.ToString(), index, index);

                    int l, c;
                    mainEditor.Document.GetLineColumnIndexFromCharIndex(index + sb.Length, out l, out c);
                    mainEditor.Document.SetCaretIndex(l, c);
                    //if (fileName.Length > 1) {
                    //    setMark(mainEditor);
                    //}
                }
            };

            mainEditor.LostFocus += (s, e) => {
                if (mainEditor.Document.IsDirty) {
                    var tb = getTabControl(filelistiew.SelectedItems[0].Text); 
                    if (tb.SelectedTab.Controls[0] is ListViewEx)
                    {
                        var lv = tb.SelectedTab.Controls[0] as ListViewEx;
                        if(lv.SelectedIndices.Count>0){
                            var item = lv.DataItems[lv.SelectedIndices[0]];
                            item.text = mainEditor.Text;
                        }
                    }
                    SaveFile(filelistiew.SelectedItems[0].Text);
                }
            };

            toolStripComboBox1.KeyDown += (s, e) => {
                ToolStripComboBox cb = s as ToolStripComboBox;
                if (e.KeyData == Keys.Return) {
                    createListView(filelistiew.SelectedItems[0].Text, cb.Text);
                }
            };

            filelistiew.AfterLabelEdit += (s, e) => {
                if (filelistiew.Items.IndexOfKey(e.Label) >= 0 || e.Label == string.Empty) {
                    e.CancelEdit = true;
                }else{
                    RenameFile(filelistiew.Items[e.Item].Text, e.Label);
                }
            };

            filelistiew.ItemSelectionChanged += (s, e) =>{
                if (e.IsSelected ) {
                    var filename =e.Item.Text;
                    Item item=null;
                    if (!tabcontrols.ContainsKey(filename)) {
                        var tb = getTabControl(filename);
                        var cl = m.getClass(filename);
                        var lv = getAllListView(tb);
                        lv.DataItems = cl._items.OrderByDescending((x) => x.date).ToList<Item>();
     
                        tb.BringToFront();
                        if (lv.DataItems.Count>0) {
                            lv.Items[0].Selected = true;
                            item = lv.DataItems[0];
                        }
                    } else {
                        var tb = getTabControl(filename);
                        var lv = getAllListView(tb);
                        tb.BringToFront();
                        if (lv.DataItems.Count > 0){
                            if (lv.SelectedIndices.Count == 0) {
                                lv.Items[0].Selected = true;
                                item = lv.DataItems[0];
                            } else {
                                item = lv.DataItems[lv.SelectedIndices[0]];
                            }
                            SetMainEditorText(item);  
                        }
                    }
                    if (item == null) {
                        SetMainEditorText(item);  
                    }
                }
            };

            filelistiew.ContextMenuStrip = FileListViewContextMenuStrip;

            subEditor = createEditor();
            subEditor.IsReadOnly = true;
            tabPage1.Controls.Add(subEditor);
            subEditor.GotFocus += (s, e) => {
                subEditor.ContextMenuStrip = editorcontextMenuStrip;
            };

            DateTimeLabel.DoubleClick += (s, e) => {
                editDateTimeToolStripMenuItem_Click(null, null);
            };

            splitContainer2.Panel2Collapsed = true;

            //m.Load(config.FileList);
        }

        void filelistiew_DragDrop(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(typeof(ListViewItem))) {
                ListView lv = (ListView)sender;
                ListViewItem source = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                if (target != null) {
                    var srclvex = source.ListView as ListViewEx;
                    var item = srclvex.DataItems[source.Index];
                    var fromtb = getTabControl(lv.SelectedItems[0].Text);
                    for (int i = 0; i < fromtb.TabPages.Count; i++) {
                        var tbp = fromtb.TabPages[i];
                        var fromlvex = tbp.Controls[0] as ListViewEx;
                        fromlvex.DeleteItem(item);
                    }
                    if (srclvex.DataItems.Count > 0) {
                        if (source.Index > 0) {
                            srclvex.Items[source.Index - 1].Selected = true;
                        } else {
                            srclvex.Items[0].Selected = true;
                        }
                    }

                    var targetlv = getAllListView(getTabControl(target.Text));
                    targetlv.AddItem(item,false);
                } else
                    e.Effect = DragDropEffects.None;
            } else
                e.Effect = DragDropEffects.None;
        }

        void filelistiew_DragOver(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(typeof(ListViewItem))) {
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                    e.Effect = DragDropEffects.Move;
            } else {
                e.Effect = DragDropEffects.None;
            }

            if (e.Effect != DragDropEffects.None) {
                ListView lv = (ListView)sender;
                var point = lv.PointToClient(new Point(e.X, e.Y));
                var target = lv.GetItemAt(point.X, point.Y);
                ListViewItem source = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
                if (target != null && !target.Text.Equals(lv.SelectedItems[0].Text)) {
                } else
                    e.Effect = DragDropEffects.None;
            }
        }


        //#region IUserInterface - Scroll
        //public event ScrollEventHandler ScrollEvent;
        ///// <summary>
        ///// Scrolls a portion of the window.
        ///// </summary>
        //public void Scroll(Rectangle rect, int vOffset, int hOffset) {
        //    WinApi.ScrollWindow(Handle, vOffset, hOffset, rect);
        //    WinApi.SetScrollPos(Handle, false, _Impl.View.FirstVisibleLine);
        //    WinApi.SetScrollPos(Handle, true, _Impl.View.ScrollPosX);
        //    UpdateCaretGraphic();

        //    if (ScrollEvent != null) {
        //        if (vOffset != 0) {
        //            ScrollEvent(this, new ScrollEventArgs(ScrollEventType.SmallIncrement, vOffset, ScrollOrientation.VerticalScroll));
        //        } else {
        //            ScrollEvent(this, new ScrollEventArgs(ScrollEventType.SmallIncrement, hOffset, ScrollOrientation.HorizontalScroll));
        //        }
        //    }
        //}


        Regex reg = new Regex(@"(>>>|<<<)\S+", RegexOptions.Compiled);
        private Sgry.Azuki.WinForms.AzukiControl createEditor() {

            var editor = new Sgry.Azuki.WinForms.AzukiControl();

            editor.Dock = DockStyle.Fill;
            editor.Highlighter = new MemoHighlighter(config);
            editor.ColorScheme = config.editorconfig.getColorScheme();
            editor.ColorScheme.SetMarkingDecoration(1, new UnderlineTextDecoration(LineStyle.Solid, Color.Transparent));
            editor.Font = new Font(config.editorconfig.FontName, config.editorconfig.FontSize);
            editor.HighlightsCurrentLine = false;
            editor.Document.MarksUri = true;
            editor.Document.EolCode = "\n";
            editor.Document.WordProc.EnableWordWrap = false;

            panelnamager.setPanel(editor);

            var regfig = new Regex(@".*((\.jpg|\.jepg|\.png|\.gif|\.bmp|\.tif)\s*)$", RegexOptions.Compiled);

            editor.Document.ContentChanged += (s, e) => {
                var lll = editor.Document.GetLineIndexFromCharIndex(e.Index);
              
               //var nsa = (e.NewText.Length - e.NewText.Replace("\r\n", "").Length)/2;
               //var osa = (e.OldText.Length - e.OldText.Replace("\r\n", "").Length)/2;

               var nsa = (e.NewText.Length - e.NewText.Replace("\n", "").Length);
               var osa = (e.OldText.Length - e.OldText.Replace("\n", "").Length);

               panelnamager.removePanel(editor, y => {
                   return (y.Line > lll && y.Line < lll + Math.Abs(nsa - osa));
               });


               var lindex = editor.Document.GetLineHeadIndexFromCharIndex(e.Index);
               var ind = lll;
               //var ll = editor.GetLineLength(ind);
               var ll = editor.Document.GetLineContent(ind).Length;
               for (int i = osa+1; i < nsa; i++) {
                   ll+=editor.Document.GetLineContentWithEolCode(ind+i).Length;
               }
               //var tt = 0;
               //if (ind + 1 < editor.LineCount) {
               //    tt = editor.Document.GetLineHeadIndex(ind + 1);
               //}
               int b, en;
               //if (editor.CaretIndex < editor.Document.Length
               //    && editor.Document.GetMarkedRange(editor.CaretIndex, 1, out b, out en)) {
               //    editor.Document.Unmark(b, en, 1);
               //}
               if (e.Index < editor.Document.Length
                   && editor.Document.GetMarkedRange(e.Index, 1, out b, out en)) {
                   editor.Document.Unmark(b, en, 1);
               }

               //var kk = editor.GetTextInRange(lindex, lindex + ll);
               var rend = ll;
               if (e.NewText.Length - e.OldText.Length > 0) {
                   rend = e.NewText.Length - e.OldText.Length;
               }
               var kk = editor.GetTextInRange(lindex, lindex + ll);
               var ms = reg.Matches(kk);

               panelnamager.removePanel(editor, x => {
                   return x.Line == ind;
               });

               //for (int i = 0; i < length; i++) {
                   
               //}
               int lastline = lll;
               for (int i = 0; i < ms.Count; i++) {
                   var rang = editor.Document.GetTextInRange(lindex + ms[i].Index, lindex + ms[i].Index + ms[i].Length);
                   editor.Document.Mark(lindex + ms[i].Index, lindex + ms[i].Index + ms[i].Length, 1);
                   
                   //if (regfig.IsMatch(rang) && !dic.ContainsKey(ind)) {
                   if (regfig.IsMatch(rang)) {
                      // var pp = editor.GetPositionFromIndex(ind, ms[i].Index);
                       var pp = editor.GetPositionFromIndex(lindex + ms[i].Index);
                       var line = editor.GetLineIndexFromCharIndex(lindex + ms[i].Index);
                       var path = rang.Substring(3);
                       //panelnamager.addPanel(path, ind, new Point(pp.X, pp.Y + editor.LineHeight));
                       var panel = panelnamager.addPanel(editor, path, line, new Point(pp.X, pp.Y + editor.LineHeight));
                       panel.MouseDoubleClick += (s2, e2) => {
                           execute(path);
                       };

                       lastline = line;
                   }
               }
               var panels = panelnamager.getPanels(editor);
               panels.ForEach(x => {
               //panelnamager.panels.ForEach(x => {
                   //if (x.Line > lll) {
                   if (x.Line > lastline) {
                       x.Line += (nsa - osa);
                       //x.panel.Location = new Point(x.panel.Location.X, x.panel.Location.Y + (nsa - osa) * editor.LineHeight+1);

                       var yy = editor.GetPositionFromIndex(x.Line,0);
                       x.panel.Location = new Point(x.panel.Location.X, yy.Y + editor.LineHeight);
                   }
               });
            };

            editor.SizeChanged += (s, e) => {
                if (editor.ViewType == ViewType.WrappedProportional) {
                    
                }
            };
            //editor.TextChanged += (s, e) => {
            //    var lindex = editor.Document.GetLineHeadIndexFromCharIndex(editor.CaretIndex);
            //    var ind = editor.Document.GetLineIndexFromCharIndex(editor.CaretIndex);
            //    //var ll = editor.GetLineLength(ind);
            //    var ll = editor.Document.GetLineContent(ind).Length;
            //    var tt = 0;
            //    if (ind + 1 < editor.LineCount) {
            //        tt = editor.Document.GetLineHeadIndex(ind + 1);
            //    }
            //    int b, en;
            //    if (editor.CaretIndex < editor.Document.Length
            //        && editor.Document.GetMarkedRange(editor.CaretIndex, 1, out b, out en)) {
            //        editor.Document.Unmark(b, en, 1);
            //    }
            //    var kk = editor.GetTextInRange(lindex, lindex + ll);
            //    var ms = reg.Matches(kk);
            //    //dic.Remove(ind);
            //    //if (dic.ContainsKey(ind)) {
            //    //    editor.Controls.Remove(dic[ind]);
            //    //    dic.Remove(ind);
            //    //}
            //    panels.RemoveAll(x => {
            //        return x.line == ind;
            //    });
            //    for (int i = 0; i < ms.Count; i++) {
            //        var rang = editor.Document.GetTextInRange(lindex + ms[i].Index, lindex + ms[i].Index + ms[i].Length);
            //        editor.Document.Mark(lindex + ms[i].Index, lindex + ms[i].Index + ms[i].Length, 1);
            //        //if (regfig.IsMatch(rang) && !dic.ContainsKey(ind)) {
            //        if (regfig.IsMatch(rang) ) {
            //            Panel pan = new Panel();
            //            var la = new Label();
            //            la.Text = kk;
            //            pan.Controls.Add(la);
            //            pan.BackColor = Color.Red;
            //            //pan.Visible = false;
            //            //dic.Add(ind, pan);
            //            var pp = editor.GetPositionFromIndex(ind, ms[i].Index);
            //            //var pp = editor.View.GetVirPosFromIndex(ind, ms[i].Index);
            //            pan.Location = new Point(pp.X, pp.Y + editor.LineHeight);
            //            editor.Controls.Add(pan);
            //            panels.Add(new PanelInfo() { panel = pan, line = ind });
            //        }
            //    }
            //    if (elinetype == EditLineType.MultiLine) {
            //        int mp = 1;
            //        if (etype == EditType.Cut) {
            //            mp = -1;
            //        }
            //        panels.ForEach(x => {
            //            if (x.line > sline) {
            //                x.panel.Location = new Point(x.panel.Location.X, x.panel.Location.Y + mp * (eline - sline) * editor.LineHeight);
            //            }
            //        });
            //        //foreach (var item in dic.Keys) {
            //        //    if (item > sline) {
            //        //        dic[item].Location = new Point(dic[item].Location.X, dic[item].Location.Y + mp*(eline - sline) * editor.LineHeight);
            //        //    }
            //        //}
            //    }
            //    elinetype = EditLineType.SingelLine;
            //};


            editor.ScrollEvent += (s, e) => {
                if (e.ScrollOrientation != ScrollOrientation.VerticalScroll) {
                    var panels = panelnamager.getPanels(editor);
                    panels.ForEach(x => {
                        x.panel.Location = new Point(x.panel.Location.X, x.panel.Location.Y + e.NewValue);
                    });
                }
            };


            Func<Document, EventArgs, List<int>> markFunc = ((d, e)=>{
                IMouseEventArgs mea = (IMouseEventArgs)e;
                int urlBegin, urlEnd, selBegin, selEnd;
                var marklist = new List<int>(){0,1};
                foreach (var m in marklist){
                    if (mea.Index < d.Length && d.IsMarked(mea.Index, m)
                        && editor.View.TextAreaRectangle.Contains(mea.Location)) {
                        d.GetMarkedRange(mea.Index, m, out urlBegin, out urlEnd);
                        d.GetSelection(out selBegin, out selEnd);
                        if (selBegin != urlBegin && selEnd != urlEnd) {
                            d.SetSelection(urlBegin, urlEnd);
                        } else {
                            d.SetSelection(mea.Index, mea.Index);
                        }
                        mea.Handled = true;
                        return new List<int>(){m, urlBegin, urlEnd};
                    } 
                }

                return null;
            });
            editor.MouseDown += (s, e) => {
                int l, c, index;
                index = editor.GetIndexFromPosition((new Point(e.X, e.Y)));
                editor.Document.GetLineColumnIndexFromCharIndex(index, out l, out c);
                editor.Document.SetCaretIndex(l, c);
            };
            editor.MouseClick += (s, e) => {
                var doc = editor.Document;
                IMouseEventArgs mea = (IMouseEventArgs)e;
                int urlBegin, urlEnd, selBegin, selEnd;
                if (mea.Index < doc.Length && doc.IsMarked(mea.Index, Marking.Uri)
                    && editor.View.TextAreaRectangle.Contains(mea.Location)) {
                    // select entire URI if not selected, or deselect if selected.
                    doc.GetMarkedRange(mea.Index, Marking.Uri, out urlBegin, out urlEnd);
                    doc.GetSelection(out selBegin, out selEnd);
                    if (selBegin != urlBegin && selEnd != urlEnd) {
                        doc.SetSelection(urlBegin, urlEnd);
                    } else {
                        doc.SetSelection(mea.Index, mea.Index);
                    }
                    mea.Handled = true;
                } else {
                    if (e.Button == MouseButtons.Middle) {
                        Item item;
                        var lt = getItemFromLink(editor, out item);
                        if (lt == LinkType.Goto) {
                            setSubEditor(item.text, true);
                        } else if (lt == LinkType.ComeFrom) {

                        }
                    }
                }

            };
            editor.DoubleClick += (s, e) => {
                var res = markFunc(editor.Document, e);
                if (res == null) return;

                if (res[0] == 1) {
                    var match =reggoto.Match(editor.Document.GetTextInRange(res[1], res[2]));
                    if (match.Success) {
                        var t = match.Groups[1].Value;
                        var id = int.Parse(t);
                        string name;
                        var item = m.getItem(id, out name);
                        if (item != null) {
                            getAllListView(getTabControl(name)).SetSelect(item);
                        }
                        return;
                    }
                    //var tt = convetURI2Path(editor.Document.GetTextInRange(res[1], res[2]));
                    match = regpath.Match(convetURI2Path(editor.Document.GetTextInRange(res[1], res[2])));
                    if (match.Success) {
                        var p = (match.Groups[1].Value);
                        if (File.Exists(p)) {

                        } else if (Directory.Exists(p)) {
                            //System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select," + p);
                        } else {
                            if (MessageBox.Show(string.Format("make {0}?", p), "Make Folder", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                                try {
                                    Directory.CreateDirectory(p);
                                } catch (Exception ex) {
                                    MessageBox.Show(ex.Message,"ERROR", MessageBoxButtons.OK,MessageBoxIcon.Error);
                                }
                            }
                        }
                        return;
                    }
                }
                //var doc = editor.Document;
                //IMouseEventArgs mea = (IMouseEventArgs)e;
                //int urlBegin, urlEnd, selBegin, selEnd;
                //if (mea.Index < doc.Length && doc.IsMarked(mea.Index, Marking.Uri)
                //    && editor.View.TextAreaRectangle.Contains(mea.Location)) {
                //    // select entire URI if not selected, or deselect if selected.
                //    doc.GetMarkedRange(mea.Index, Marking.Uri, out urlBegin, out urlEnd);
                //    doc.GetSelection(out selBegin, out selEnd);
                //    if (selBegin != urlBegin && selEnd != urlEnd) {
                //        doc.SetSelection(urlBegin, urlEnd);
                //    } else {
                //        doc.SetSelection(mea.Index, mea.Index);
                //    }
                //    mea.Handled = true;

                //} else {
                //    Item item;
                //    var lt = getItemFromLink(editor, out item);
                //    if (lt == LinkType.Goto) {
                //        //subEditor.Text = item.text;
                //        var lv = getSelectedListView(getSelectedTabControl());
                //        if (lv != null) {
                //            lv.SetSelect(item);
                //        }

                //    } else if (lt == LinkType.ComeFrom) {

                //    }
                //}
            };

            return editor;
        }

        private Item createItem(string text) {
            if (filelistiew.SelectedItems.Count > 0) {
                var name = filelistiew.SelectedItems[0].Text;
                var tb = getTabControl(name);
                var sellv = getSelectedListView(tb);
                var item = m.createItem();
                item.text = item.text + Environment.NewLine + text;
                m.getClass(name).Add(item);
                if (sellv.Name.Equals("all")) {
                    sellv.AddItem(item, true);
                } else {
                    var lv = getAllListView(tb);
                    //var item = m.createItem();
                    lv.AddItem(item,false);
                    sellv.AddItem(item, true);
                }
                if (sellv.SelectedIndices[0] == 0) {
                    SetMainEditorText(sellv.DataItems[0]);
                } else {
                    sellv.Items[0].Selected = true;
                }
                SaveFile(name);
                return item;
            }
            return null;
        }

        private LinkType getItemFromLink(Sgry.Azuki.WinForms.AzukiControl editor, out Item item) {
            item = null;
            var doc = editor.Document;
            var lineindex = doc.GetLineIndexFromCharIndex(editor.CaretIndex);
            string line = doc.GetLineContent(lineindex);
            var match = regcomefrom.Match(line);
            if (match.Success && match.Groups.Count == 3) {
                var id = int.Parse(match.Groups[2].Value);
                item = m.getItem(id);
                return LinkType.ComeFrom;
            }

            match = reggoto.Match(line);
            if (match.Success && match.Groups.Count == 3) {
                var id = int.Parse(match.Groups[2].Value);
                item = m.getItem(id);
                return LinkType.Goto;
            }

            return LinkType.None;
        }

        private List<Item> getLinkedItem(int id)
        {
            var items = new List<Item>();
            Regex reg = new Regex(@">>>" + id.ToString() + @"\s", RegexOptions.Compiled);
            m.acts.ForEach(x =>
            {
                items.AddRange(x._items.FindAll(y =>
                {
                    return reg.IsMatch(y.text);
                }));
            });
            return items;
        }
        private List<Item> getLinkItem(Item item) {
            var list = new List<Item>();
            var matchs = reggoto.Matches(item.text);
            for (int i = 0; i < matchs.Count; i++) {
                var match = matchs[i];
                if (match.Groups.Count == 3) {
                    var id = int.Parse(match.Groups[2].Value);
                    item = m.getItem(id);
                    if (item != null) list.Add(item);
                }
            }
            return list;
        }
        private List<Item> getLinkeItem(int id)
        {
            var items = new List<Item>();
            m.acts.ForEach(x =>
            {
                items.AddRange(x._items.FindAll(y =>
                {
                    return y.id == id;
                }));
            });
            return items;
        }

        //private string makeLink(Item item) {
        //    return String.Format(">>>{0} {1} {2}", item.id, item.title, item.date.ToString("yyyy/MM/dd_hh:mmm"));
        //}

        private void SaveFile(string name) {
            m.Save(name);
        }

        private ListViewEx getSelectedListView(TabControl tb) {

            return tb.SelectedTab.Controls[0] as ListViewEx;
        }

        private ListViewEx getAllListView(TabControl tb) {
            for (int i = 0; i < tb.TabPages.Count; i++) {
                ListViewEx lv = tb.TabPages[i].Controls[0] as ListViewEx;
                if (lv.Name.Equals("all")) {
                    return lv;
                }
            }
            return null;
        }

        private void setSubEditor(string text, bool stack) {
            if (stack) {
                subEditor.Text = text + Environment.NewLine + subEditor.Text;
            } else {
                subEditor.Text = text;
            }
        }

        private void createListView(string name, string title, List<Item> items) {
            var tb = getTabControl(name);
            tb.BringToFront();

            var tbp = new TabPage();
            tbp.Text = title;

            var lv = new ListViewEx(config);
            lv.ContextMenuStrip = ListViewContextMenuStrip3;
            lv.Dock = DockStyle.Fill;
            lv.Margin = new Padding(0);
            lv.ItemSelectionChanged += (s, e) => {

                if (e.IsSelected) {
                    var item = lv.DataItems[e.ItemIndex];
                    SetMainEditorText(item, false);
                }
            };
            lv.MouseDoubleClick += (s, e) => {

            };
            lv.GotFocus += (s, e) => {
                copyToolStripMenuItem1.Enabled = true;
            };
            lv.LostFocus += (s, e) => {
                copyToolStripMenuItem1.Enabled = false;
            };
            lv.ItemDrag += new ItemDragEventHandler(lv_ItemDrag);

            lv.ClearItem();
            lv.DataItems = items;
            tbp.Controls.Add(lv);
            tb.TabPages.Add(tbp);
            tb.SelectedTab = tbp;
        }

        private void createListView(string name, string word) {
            //var tb = getTabControl(name);
            //tb.BringToFront();

            //var tbp = new TabPage();
            //tbp.Text = word;
            //var lv = new ListViewEx();
            //lv.ContextMenuStrip = ListViewContextMenuStrip3;
            //lv.Dock= DockStyle.Fill;
            //lv.Margin = new Padding(0);
            //lv.ItemSelectionChanged += (s, e) => {

            //    if (e.IsSelected) {
            //        var item = lv.DataItems[e.ItemIndex];
            //        SetMainEditorText(item, false);
            //    }
            //};
            //lv.MouseDoubleClick += (s, e) =>
            //{

            //};
            //lv.GotFocus += (s, e) => {
            //    copyToolStripMenuItem1.Enabled = true;
            //};
            //lv.LostFocus += (s, e) => {
            //    copyToolStripMenuItem1.Enabled = false;
            //};

            Regex rg = new Regex(word, RegexOptions.IgnoreCase | RegexOptions.Compiled);
            var lists = m.getClass(name)._items.FindAll(x => {
                return rg.IsMatch(x.text);
            });
            
            //lv.ClearItem();
            //lv.DataItems = lists;
            //tbp.Controls.Add(lv);
            //tb.TabPages.Add(tbp);
            //tb.SelectedTab = tbp;

            createListView(name, word, lists);
        }

        private TabControl getSelectedTabControl(){
            return getTabControl(filelistiew.SelectedItems[0].Text);
        }

        private TabControl getTabControl(string name) {
            if (!tabcontrols.ContainsKey(name)) {
                TabControl tb = new TabControl();
                tb.Dock = DockStyle.Fill;
                tb.Selected += (s,e) =>
                {
                    if (tb.SelectedTab.Controls[0] is ListView)
                    {
                        var lv = tb.SelectedTab.Controls[0] as ListView;
                        if (lv.SelectedIndices.Count == 0 && lv.Items.Count>0)
                        {
                            lv.Items[0].Selected = true;
                        }
                    }
                };

                var lvex = new ListViewEx(config);
                lvex.ContextMenuStrip = ListViewContextMenuStrip3;
                lvex.AllowDrop = true;
                lvex.Dock = DockStyle.Fill;
                lvex.Name = "all";
                lvex.ItemSelectionChanged += (s, e) => {
                    if (e.IsSelected) {
                        SetMainEditorText(lvex.DataItems[e.ItemIndex]);
                    }
                };
                lvex.SelectedIndexChanged += (s, e) => {
                    if (lvex.SelectedIndices.Count == 0) {
                        SetMainEditorText(null, true);
                    } 
                };
                lvex.GotFocus += (s, e) => {
                    copyToolStripMenuItem1.Enabled = true;
                };
                lvex.LostFocus += (s, e) => {
                    copyToolStripMenuItem1.Enabled = false;
                };
                lvex.ItemDrag += new ItemDragEventHandler(lv_ItemDrag);

                var tbp = new TabPage();
                tbp.Name="all";
                tbp.Controls.Add(lvex);
                tb.TabPages.Add(tbp);
                tb.SendToBack();
                TabPanel.Controls.Add(tb);

                tabcontrols.Add(name, tb);

            }
            return tabcontrols[name];
        }

        void lv_ItemDrag(object sender, ItemDragEventArgs e) {
            var lv = sender as ListView;
            lv.DoDragDrop((ListViewItem)e.Item, DragDropEffects.Copy | DragDropEffects.Move);   
        }

        private void SetMainEditorText(Item item){

            SetMainEditorText(item, false);
            //if (item.text.Length > 3)
            //{
            //    editor.Document.Mark(0, 2, 1);
            //}
        }

        private void SetMainEditorText(Item item, bool isreadonly) {
            if (item == null){
                DateTimeLabel.Text = "";
                mainEditor.Text = "";
                mainEditor.Document.IsDirty = false;
                mainEditor.Document.IsReadOnly = true;
            }
            else
            {
                DateTimeLabel.Text = item.date.ToString();
                mainEditor.Text = item.text;
                mainEditor.Document.IsDirty = false;
                mainEditor.Document.IsReadOnly = isreadonly;

                //setMark(mainEditor);
            }
            mainEditor.Document.ClearHistory();
            //if (mainEditor.Text.Length > 2) {
            //    mainEditor.Document.Mark(0, 2, 1);
            //}
        }

        private void setMark(Sgry.Azuki.WinForms.AzukiControl editor) {
            var ms = reg.Matches(editor.Text);
            for (int i = 0; i < ms.Count; i++) {
                editor.Document.Mark(ms[i].Index, ms[i].Index + ms[i].Length, 1);
            } 
        }

        private void ConfigLoad() {
            if (!Directory.Exists("data")) {
                Directory.CreateDirectory("data");
            }
            try {
                config = XMLSerializer.Deserialize<Config>("config.xml");
            } catch (Exception) {

                config = new Config();
                config.setDefault();
            }

            //if (config.FileList.Count == 0) {
            //    config.FileList.Add("File.xml");
            //    config.FileList.Add(trustfile);
            //} else if (!config.FileList.Contains(trustfile)) {
            //    config.FileList.Add(trustfile);
            //}
            if (config.FileList.Count == 0) {
                config.FileList.Add(config.NewFileName);
                config.FileList.Add(config.TrustFileName);
                config.FileList.ForEach(x => {
                    XMLSerializer.Serialize<Class1>(getDatePath(x), m.getClass(x));
                });
            } else if (!config.FileList.Contains(config.TrustFileName)) {
                config.FileList.Add(config.TrustFileName);
                XMLSerializer.Serialize<Class1>(getDatePath(config.TrustFileName), m.getClass(config.TrustFileName));
            }

            config.FileList.ForEach(x => {
                var item = new ListViewItem(x);
                item.ImageIndex = x != config.TrustFileName ? 0 : 1;
                item.Name = x;
                filelistiew.Items.Add(item);
            });
        }
        private void ConfigSave() {
            config.editorconfig.IsWrap = WraptoolStripButton.Checked;

            XMLSerializer.Serialize<Config>("config.xml", config);

            var items = filelistiew.Items;
            for (int i = 0; i < items.Count; i++) {
                var text = items[i].Text;
                //m.Save(text);
                //if (NodeCashe.ContainsKey(text)) {
                    //SaveTree(NodeCashe[text], text + ".tree.xml");

                //    SerializeTreeView(NodeCashe[text], text + ".xml");
                //}
            }        
        }

        public void RenameFile(string from, string to) {
            try {
                File.Move(getDatePath(from), getDatePath(to));
                if (tabcontrols.ContainsKey(from)) {
                    var tb = tabcontrols[from];
                    tabcontrols.Remove(from);
                    tabcontrols.Add(to, tb);
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private bool editenable = true;
        private bool EnableEdit {
            get { return editenable; }
            set {
                editenable = value;
                if (editenable) {

                } else {

                }
            }
        }

        private void moveFileListViewItem(int updawn) {
            if (filelistiew.SelectedItems.Count != 1) return;
            if (updawn > 0) {
                if (filelistiew.SelectedItems[0].Index == 0) {
                    return;
                }
            }
            if (updawn < 0) {
                if (filelistiew.SelectedItems[0].Index >= filelistiew.SelectedItems.Count) {
                    return;
                }
            }

            var name = filelistiew.SelectedItems[0].Text;
            var index = filelistiew.SelectedItems[0].Index;

            filelistiew.BeginUpdate();
            filelistiew.Items.Clear();

            var c = m.getClass(name);
            m.acts.Remove(c);
            m.acts.Insert(index + updawn, c);
            m.acts.ForEach(x => {
                var item = new ListViewItem(x.name);
                item.Name = x.name;
                item.ImageIndex = x.name != config.TrustFileName ? 0 : 1;
                filelistiew.Items.Add(item);
            });

            filelistiew.EndUpdate();

            filelistiew.Items[index + updawn].Selected = true;
        }

        private void newFileToolStripMenuItem_Click(object sender, EventArgs e) {
            var name = config.NewFileName;
            var n = Path.GetFileNameWithoutExtension(name);
            var ext = Path.GetExtension(name);
            var cnt = 1;

            while (filelistiew.Items.IndexOfKey(name) >= 0) {
                name = string.Format("{0}{1}.{2}", n, cnt.ToString(), ext);
                cnt++;
            }
            //m.Add(name);
            m.Insert(0, name);
            XMLSerializer.Serialize<Class1>(getDatePath(name), m.getClass(name));

            filelistiew.BeginUpdate();
            filelistiew.Items.Clear();

            var newitem = new ListViewItem(name);
            newitem.Name = name;
            newitem.ImageIndex = name != config.TrustFileName ? 0 : 1;
            filelistiew.Items.Add(newitem);
            newitem.Selected = true;

            m.acts.ForEach(x => {
                if (!x.name.Equals(newitem.Name)) {
                    var item = new ListViewItem(x.name);
                    item.Name = x.name;
                    item.ImageIndex = x.name != config.TrustFileName ? 0 : 1;
                    filelistiew.Items.Add(item);
                }
            });
            filelistiew.EndUpdate();
        }

        private void deleteFileToolStripMenuItem_Click(object sender, EventArgs e) {
            if (filelistiew.SelectedItems.Count > 0 && filelistiew.SelectedItems[0].Text != config.TrustFileName) {
                var name = filelistiew.SelectedItems[0].Text;
                m.Remove(name);
                string filePath = getDatePath(name);
                FileSystem.DeleteFile(
                  filePath,
                  UIOption.OnlyErrorDialogs,
                  RecycleOption.SendToRecycleBin);
            }
        }

        private void renameFileToolStripMenuItem_Click(object sender, EventArgs e) {
            if (filelistiew.SelectedItems.Count > 0) {
                filelistiew.SelectedItems[0].BeginEdit();
            }
        }

        private void upFileToolStripMenuItem_Click(object sender, EventArgs e) {
            //if (filelistiew.SelectedItems.Count == 1 && filelistiew.SelectedItems[0].Index > 0) {
            //    var name = filelistiew.SelectedItems[0].Text ;
            //    var index = filelistiew.SelectedItems[0].Index;

            //    filelistiew.BeginUpdate();
            //    filelistiew.Items.Clear();

            //    var c = m.getClass(name);
            //    m.acts.Remove(c);
            //    m.acts.Insert(index - 1, c);
            //    m.acts.ForEach(x => {
            //        var item = new ListViewItem(x.name);
            //        item.Name = x.name;
            //        item.ImageIndex = x.name != config.TrustFileName ? 0 : 1;
            //        filelistiew.Items.Add(item);
            //    });

            //    filelistiew.EndUpdate();

            //    filelistiew.Items[index - 1].Selected = true;
            //}
            moveFileListViewItem(1);
        }

        private void downFileToolStripMenuItem_Click(object sender, EventArgs e) {
            //if (filelistiew.SelectedItems.Count == 1 && filelistiew.SelectedItems[0].Index < filelistiew.SelectedItems.Count) {
            //    var item = filelistiew.SelectedItems[0];
            //    var index = filelistiew.SelectedItems[0].Index;
            //    filelistiew.Items.Remove(item);
            //    filelistiew.Items.Insert(index + 1, item);
            //    item.Selected = true;
            //}

            //if (filelistiew.SelectedItems.Count == 1 && filelistiew.SelectedItems[0].Index < filelistiew.SelectedItems.Count) {
            //    var name = filelistiew.SelectedItems[0].Text;
            //    var index = filelistiew.SelectedItems[0].Index;

            //    filelistiew.BeginUpdate();
            //    filelistiew.Items.Clear();

            //    var c = m.getClass(name);
            //    m.acts.Remove(c);
            //    m.acts.Insert(index + 1, c);
            //    m.acts.ForEach(x => {
            //        var item = new ListViewItem(x.name);
            //        item.Name = x.name;
            //        item.ImageIndex = x.name != config.TrustFileName ? 0 : 1;
            //        filelistiew.Items.Add(item);
            //    });

            //    filelistiew.EndUpdate();

            //    filelistiew.Items[index + 1].Selected = true;
            //}
            moveFileListViewItem(-1);
        }

        private void newMemoToolStripMenuItem_Click(object sender, EventArgs e) {
            if (!EnableEdit) return;

            //if (listView1.SelectedItems.Count > 0) {
            //    var name = listView1.SelectedItems[0].Text;
            //    var tb = getTabControl(name);
            //    var sellv = getSelectedListView(tb);
            //    var item = m.createItem();
            //    m.getClass(name).Add(item);
            //    if (sellv.Name.Equals("all")) {
            //        sellv.AddItem(item);
            //    } else {
            //        var lv = getAllListView(tb);
            //        //var item = m.createItem();
            //        lv.AddItem(item);
            //        sellv.AddItem(item);
            //    }
            //    sellv.Items[0].Selected = true;
            //    SaveFile(name);
            //}
            createItem(string.Empty);
        }
        
        //TODO
        private void newMemoWithLinkToolStripMenuItem_Click(object sender, EventArgs e) {
            var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
            if (item != null) {
                createItem(config.makeLink(item));
            }
        }
        private void newMemoWithParentLinkToolStripMenuItem_Click(object sender, EventArgs e) {
            var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
            if (item != null) {
                var list = getLinkItem(item);
                if (list.Count > 1) {

                    var f = new ItemListForm();
                    list.ForEach(x => {
                        f.listBox1.Items.Add(config.makeLink(x));
                    });
                    var link = string.Empty;
                    f.KeyDown += (s2, e2) => {
                        if (e2.KeyCode == Keys.Return && f.listBox1.SelectedItem != null) {
                            link = f.listBox1.SelectedItem.ToString();
                            f.DialogResult = DialogResult.OK;
                        }
                    };
                    f.listBox1.MouseDoubleClick += (s2, e2) => {
                        if (f.listBox1.SelectedItem != null) {
                            link = f.listBox1.SelectedItem.ToString();
                            f.DialogResult = DialogResult.OK;
                        }
                    };
                    if (f.ShowDialog() == DialogResult.OK) {
                        if (link != string.Empty) {
                            createItem(link);
                        }
                    }
                    f.Close();
                } else {
                    var sb = new StringBuilder();
                    list.ForEach(x => {
                        sb.AppendLine(config.makeLink(x));
                    });
                    createItem(sb.ToString());
                }
            }
        }

        private void deleteMemoToolStripMenuItem_Click(object sender, EventArgs e) {
            if (!EnableEdit) return;

            var name = filelistiew.SelectedItems[0].Text;
            var fromtb = getTabControl(name);
            var lv = getSelectedListView(fromtb);
            var item = lv.DataItems[lv.SelectedIndices[0]];

            for (int i = 0; i < fromtb.TabPages.Count; i++) {
                var tbp = fromtb.TabPages[i];
                if (tbp.Controls[0] is ListViewEx) {
                    var lvex = tbp.Controls[0] as ListViewEx;
                    lvex.DeleteItem(item);
                }
            }
            m.getClass(name).Delete(item);

            if (lv.SelectedIndices[0] == 0) {
                SetMainEditorText(lv.DataItems[0]);
            } else {
                lv.Items[0].Selected = true;
            }

            SaveFile(name);

            if (!name.Equals(config.TrustFileName)) {
                lv = getAllListView(getTabControl(config.TrustFileName));
                lv.AddItem(item,false);
                m.getClass(name).Add(item);
                SaveFile(config.TrustFileName);
            }
        }

        private void editDateTimeToolStripMenuItem_Click(object sender, EventArgs e) {
            var lv = getSelectedListView(getSelectedTabControl());
            var item = lv.SelectedItem;
            if (item == null) return;

            DateTimeEditForm de = new DateTimeEditForm();
            de.Value = item.date;
            var re = de.ShowDialog();
            if (re == DialogResult.OK && de.Value != item.date) {
                item.date = de.Value;
                //lv.SortByDateTime();
            }
            de.Close();
        }

        private void wrapToolStripMenuItem_Click(object sender, EventArgs e) {
            if (WraptoolStripButton.Checked) {
                mainEditor.ViewType = Sgry.Azuki.ViewType.WrappedProportional;
                mainEditor.ViewWidth = mainEditor.ClientSize.Width - mainEditor.View.HRulerUnitWidth * 2;
                subEditor.ViewType = Sgry.Azuki.ViewType.WrappedProportional;
                subEditor.ViewWidth = subEditor.ClientSize.Width - subEditor.View.HRulerUnitWidth * 2;

            } else {
                mainEditor.ViewType = Sgry.Azuki.ViewType.Proportional;
                subEditor.ViewType = Sgry.Azuki.ViewType.Proportional;
            }
            WraptoolStripButton.Checked = WraptoolStripButton.Checked;
        }

        private void subPanleToolStripMenuItem_Click(object sender, EventArgs e) {
            splitContainer2.Panel2Collapsed = !subPanleToolStripMenuItem.Checked;
            showSubPaneltoolStripButton.Checked = subPanleToolStripMenuItem.Checked;
            
        }

        private void ThumbnailToolStripMenuItem_Click(object sender, EventArgs e) {
            thbutton1_Click();
        }

        private void showMemoListtoolStripMenuItem_Click(object sender, EventArgs e) {
            var lv = getSelectedListView(getSelectedTabControl());
            var sb = new StringBuilder();
            lv.DataItems.ForEach(x => {
                sb.AppendLine(config.makeListHeader(x));
                sb.AppendLine(x.text);
                sb.AppendLine("");
            });
            setSubEditor(sb.ToString(), false);
        }

        private void showLinkedMemoToolStripMenuItem_Click(object sender, EventArgs e) {
            var name = filelistiew.SelectedItems[0].Text;
            var lv = getSelectedListView(getTabControl(name));
            if (lv.SelectedIndices.Count > 0) {
                var item = lv.DataItems[lv.SelectedIndices[0]];
                var items = getLinkeItem(item.id);
                createListView(name, ">>>" + item.id.ToString(), items);
            }
        }


        private void WraptoolStripButton_Click(object sender, EventArgs e) {
            wrapToolStripMenuItem_Click(null, null);
            wrapToolStripMenuItem.Checked = WraptoolStripButton.Checked;
        }

        private void showSubPaneltoolStripButton_Click(object sender, EventArgs e) {
            splitContainer2.Panel2Collapsed = !showSubPaneltoolStripButton.Checked;
            subPanleToolStripMenuItem.Checked = showSubPaneltoolStripButton.Checked;
        }

        private void copyToolStripMenuItem1_Click(object sender, EventArgs e) {
            if (getSelectedListView(getSelectedTabControl()).Focused) {
                var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
                string d = config.makeLink(item);// string.Format("", item.id, item.title, item.date.ToString("yyyy/MM/dd hh:mmm"));
                Clipboard.SetDataObject(d);
            }
        }

        //editor
        private void editorcontextMenuStrip_Opening(object sender, CancelEventArgs e) {

            if (editorcontextMenuStrip == mainEditor.ContextMenuStrip) {
                copytoolStripMenuItem.Enabled = mainEditor.GetSelectedText() != string.Empty;
                cuttoolStripMenuItem.Enabled = mainEditor.GetSelectedText() != string.Empty;
                pastetoolStripMenuItem.Enabled = mainEditor.CanPaste;
                pasteAsQuotationtoolStripMenuItem.Enabled = mainEditor.CanPaste;
                editDateTimeToolStripMenuItem.Enabled = true;

                undotoolStripMenuItem.Enabled = mainEditor.CanUndo;
                redotoolStripMenuItem.Enabled = mainEditor.CanRedo;
                selectAlltoolStripMenuItem.Enabled = true;
                
            } else {
                cuttoolStripMenuItem.Enabled = false;
                pastetoolStripMenuItem.Enabled = false;
                pasteAsQuotationtoolStripMenuItem.Enabled = false;
                editDateTimeToolStripMenuItem.Enabled = false;
                undotoolStripMenuItem.Enabled = false;
                redotoolStripMenuItem.Enabled = false;
                selectAlltoolStripMenuItem.Enabled = false;
            }
        }

        private void undotoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = mainEditor.Focused ? mainEditor : subEditor;
            editor.Undo();
        }

        private void redotoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = mainEditor.Focused ? mainEditor : subEditor;
            editor.Redo();
        }

        private void cuttoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = mainEditor.Focused ? mainEditor : subEditor;
            editor.Cut();
        }

        private void copytoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = mainEditor.Focused ? mainEditor : subEditor;
            editor.Copy();
        }

        private void pastetoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = mainEditor.Focused ? mainEditor : subEditor;
            //editor.Paste();

            if (Clipboard.ContainsText()) {
                editor.Paste();
            } else if (Clipboard.ContainsImage()) {
                var item = getSelectedListView(getSelectedTabControl()).SelectedItem;
                if (item != null) {
                    var dir = Directory.CreateDirectory(item.id.ToString());
                    if (dir.Exists) {
                        var img = Clipboard.GetImage();
                        img.Save(item.id.ToString() + ".png", System.Drawing.Imaging.ImageFormat.Png);
                        //convetPath2URI(
                    }
                }

            } else if (Clipboard.ContainsFileDropList()) {
                var sb = new StringBuilder();
                var files = Clipboard.GetFileDropList();
                for (int i = 0; i < files.Count; i++){
                    sb.AppendLine(convetPath2URI(files[i]));
                }
                editor.Document.Replace(sb.ToString());
            }
        }

        private void pasteAsQuotationtoolStripMenuItem_Click(object sender, EventArgs e) {

        }

        private void selectAlltoolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = mainEditor.Focused ? mainEditor : subEditor;
            editor.SelectAll();
        }

        private void insertDatetoolStripMenuItem_Click(object sender, EventArgs e) {

        }

        private void optionToolStripMenuItem_Click(object sender, EventArgs e) {
            var gf = new ConfigForm(config);
            var ret = gf.ShowDialog();
            if (ret == DialogResult.OK) {
                mainEditor.Font = new Font(config.editorconfig.FontName, config.editorconfig.FontSize, FontStyle.Regular);
                mainEditor.ColorScheme = gf.getColorScheme();
                mainEditor.Document.Highlighter = new MemoHighlighter(config);
                mainEditor.Refresh();

                subEditor.Font = new Font(config.editorconfig.FontName, config.editorconfig.FontSize, FontStyle.Regular);
                subEditor.ColorScheme = gf.getColorScheme();
                subEditor.Document.Highlighter = new MemoHighlighter(config);
                subEditor.Refresh();
            }
            gf.Close();
        }

        private void FileListViewContextMenuStrip_Opening(object sender, CancelEventArgs e) {
            if (filelistiew.SelectedItems.Count == 1) {
                var item = filelistiew.SelectedItems[0];
                deleteFileToolStripMenuItem1.Enabled = !item.Text.Equals(config.TrustFileName);
                renameFileToolStripMenuItem1.Enabled = !item.Text.Equals(config.TrustFileName);
            } else {
            }
        }

        private void editorsearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (mainEditor.Focused)
            {
                if (searchmain == null)
                {
                //    searchmain = new EditorSearchControl();
                //    searchmain.Dock = DockStyle.Bottom;
                //    searchmain.nextbutton.Click += (s2, e2) =>
                //    {
                //        var res = mainEditor.Document.FindNext(searchmain.editorSearchcomboBox.Text, mainEditor.CaretIndex);
                //        if (res != null) mainEditor.SetSelection(res.Begin, res.End);
                //    };
                //    searchmain.upbutton.Click += (s2, e2) =>
                //    {
                //        var res = mainEditor.Document.FindPrev(searchmain.editorSearchcomboBox.Text, mainEditor.CaretIndex);
                //        if (res != null) mainEditor.SetSelection(res.Begin, res.End);
                //    };
                //    searchmain.closebutton.Click += (s2, e2) =>
                //    {
                //        MainEditorPanel.Controls.Remove(searchmain);
                //    };
                    searchmain = createSearchPanel(mainEditor, MainEditorPanel);
                }
                MainEditorPanel.Controls.Add(searchmain);
            }
            else if (subEditor.Focused)
            {
                if (searchsub == null)
                {
                    searchsub = createSearchPanel(subEditor, tabPage1);
                }
                tabPage1.Controls.Add(searchsub);
            }
        }
        private EditorSearchControl createSearchPanel(Sgry.Azuki.WinForms.AzukiControl editor, Control parent)
        {
            var search = new EditorSearchControl();
            search.Dock = DockStyle.Bottom;
            search.nextbutton.Click += (s2, e2) =>
            {
                var res = editor.Document.FindNext(searchmain.editorSearchcomboBox.Text, editor.CaretIndex);
                if (res != null) editor.SetSelection(res.Begin, res.End);
            };
            search.upbutton.Click += (s2, e2) =>
            {
                var res = editor.Document.FindPrev(searchmain.editorSearchcomboBox.Text, editor.CaretIndex);
                if (res != null) editor.SetSelection(res.Begin, res.End);
            };
            search.closebutton.Click += (s2, e2) =>
            {
                parent.Controls.Remove(searchmain);
            };
            return search;
        }

        private void emptyToolStripMenuItem1_Click(object sender, EventArgs e){
            if (filelistiew.SelectedItems.Count == 1) {
                var item = filelistiew.SelectedItems[0];
                var name = item.Text;
                if (name.Equals(config.TrustFileName)) {
                    var tb = getTabControl(name);
                    for (int i = 0; i < tb.TabPages.Count; i++){
                        var tbp = tb.TabPages[i];
                        if (tbp.Controls[0] is ListViewEx){
                            var lvex = tbp.Controls[0] as ListViewEx;
                            if (lvex.Name.Equals("all")){
                                lvex.ClearItem();
                            }
                            else{
                                tb.TabPages.Remove(tbp);
                            }
                        }
                    }
                    m.getClass(config.TrustFileName).clear();
                    SaveFile(config.TrustFileName);
                }
            }
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Visible = true;
                this.Activate();
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!isexit)
            {
                e.Cancel = true;
                this.Visible = false;
            }
        }
        bool isexit = false;
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isexit = true;
            this.Close();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.mainEditor.Dispose();
            this.subEditor.Dispose();
            ConfigSave();
        }

        //TODO notifyIcon1
        private void showToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Visible = true;
            this.Activate();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            exitToolStripMenuItem_Click(null, null);
        }

        private void editToolStripMenuItem_DropDownOpening(object sender, EventArgs e) {
            newMemoWithLinkToolStripMenuItem.Enabled = getSelectedListView(getSelectedTabControl()).SelectedIndices.Count>0;
        }

        private void ListViewContextMenuStrip3_Opening(object sender, CancelEventArgs e) {
            var enable = getSelectedListView(getSelectedTabControl()).SelectedIndices.Count > 0;
            deleteMemoToolStripMenuItem3.Enabled = enable;
            newMemoWithLinkToolStripMenuItem3.Enabled = enable;
            newMemoWithParentLinkToolStripMenuItem3.Enabled = enable;
        }

        private void openParentDirectoryToolStripMenuItem_Click(object sender, EventArgs e) {
            var editor = mainEditor;
            var doc = editor.Document;
            var index = editor.CaretIndex;
            int urlBegin, urlEnd, selBegin, selEnd;
            if (index < doc.Length && doc.IsMarked(index, 1)) {
                // select entire URI if not selected, or deselect if selected.
                doc.GetMarkedRange(index, 1, out urlBegin, out urlEnd);
                doc.GetSelection(out selBegin, out selEnd);
                if (selBegin != urlBegin && selEnd != urlEnd) {
                    doc.SetSelection(urlBegin, urlEnd);

                    var match = regpath.Match(convetURI2Path(editor.Document.GetTextInRange(urlBegin, urlEnd)));
                    if (match.Success) {
                        var p = (match.Groups[1].Value);
                        //var pp = Path.GetDirectoryName(p);
                        openFolder(p, true);
                    }
                }
            } 

        }
    }
}
