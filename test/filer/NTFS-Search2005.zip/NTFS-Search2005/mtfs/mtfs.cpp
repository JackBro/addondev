// mtfs.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "NTFS_STRUCT.h"
#include "commctrl.h"

int _tmain(int argc, _TCHAR* argv[])
{
	WCHAR path[8];
	path[0] = L'\\';
	path[1] = L'\\';
	path[2] = L'.';
	path[3] = L'\\';
	path[4] = L'c';
	path[5] = L':';
	path[6] = L'\0';
	PDISKHANDLE disk;
	disk = OpenDisk(path);
	if (disk!=NULL)
	{
		disk->DosDevice = L'c';
		//return disk;
	}
	DWORD res;
	STATUSINFO status={0};
	status.Value = PBM_SETPOS;
	if (disk->filesSize==0){
		if(res = LoadMFT(disk, false)!=0){
			ParseMFT(disk, SEARCHINFO, &status);
		}
	}else{
		ReparseDisk(disk, SEARCHINFO, &status);
	}

	LONGFILEINFO *info;
	info = disk->lFiles;
LONGFILEINFO io = info[130];

	return 0;
}

