// mtfs.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "NTFS_STRUCT.h"
#include "commctrl.h"

int _tmain(int argc, _TCHAR* argv[])
{
	//WCHAR path[8];
	//path[0] = L'\\';
	//path[1] = L'\\';
	//path[2] = L'.';
	//path[3] = L'\\';
	//path[4] = L'c';
	//path[5] = L':';
	//path[6] = L'\0';
	//PDISKHANDLE disk;
	//disk = OpenDisk(path);
	//if (disk!=NULL)
	//{
	//	disk->DosDevice = L'c';
	//	//return disk;
	//}
	PDISKHANDLE disk = OpenDisk('c');
	DWORD res;
	STATUSINFO status={0};
	status.Value = PBM_SETPOS;
	if (disk->filesSize==0){
		if(res = LoadMFT(disk, TRUE)!=0){
			ParseMFT(disk, SEARCHINFO, &status);
		}
	}else{
		ReparseDisk(disk, SEARCHINFO, &status);
	}

	PLONGFILEINFO info;
	info = disk->lFiles;
PLONGFILEINFO io = &info[12500];

	CloseDisk(disk);
//std::string s = "test";
	return 0;
}

