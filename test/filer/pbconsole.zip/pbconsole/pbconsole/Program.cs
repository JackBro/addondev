﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ProtoBuf;
using System.IO;
using System.Runtime.InteropServices;

namespace pbconsole {
    [ProtoContract]
    public class Item {
        [ProtoMember(1)]
        public string Name { get; set; }
        [ProtoMember(2)]
        public int Flags { get; set; }
        [ProtoMember(3)]
        public long parent { get; set; }
        [ProtoMember(4)]
        public long size { get; set; }

        [ProtoMember(5)]
        public int ctime1 { get; set; }
        [ProtoMember(6)]
        public int ctime2 { get; set; }
        [ProtoMember(7)]
        public int wtime1 { get; set; }
        [ProtoMember(8)]
        public int wtime2 { get; set; }
    }

    class Program {

        static void Main(string[] args) {
            Item item = new Item {
                Name = "Bar",
                Flags = 1,
                parent = 100,
                size = 10,
                ctime1 = 10,
                ctime2 = 10,
                wtime1 = 10,
                wtime2 = 10,
            };


            using (Stream stream = new MemoryStream())
            using (StreamReader reader = new StreamReader(stream)) {
                // シリアライズ
                Serializer.Serialize(stream, item);

                // コンソールに出力する
                stream.Seek(0, SeekOrigin.Begin);
                Console.WriteLine(reader.ReadToEnd());

                // 元に戻す
                stream.Seek(0, SeekOrigin.Begin);
                Item result = Serializer.Deserialize<Item>(stream);
                Console.WriteLine(item.Name);

                bool write=false;
                List<Item> items = new List<Item>();
                DateTime s = DateTime.Now;
                if (write) {
                    for (int i = 0; i < 100000; i++) {
                        Item tmp = new Item {
                            Name = "シリアライズ時は出力ファイルサイズデシリアライズ時",
                            Flags = 1,
                            parent = 100,
                            size = 10,
                            ctime1 = 10,
                            ctime2 = 10,
                            wtime1 = 10,
                            wtime2 = 10,
                        };
                        items.Add(tmp);
                    }
                    using (var file = File.Create("person.bin")) {
                        Serializer.Serialize(file, items);
                    }
                }else{
                    using (var file = File.OpenRead("person.bin")) {
                        items = Serializer.Deserialize<List<Item>>(file);

                    }
                }
                var sp = DateTime.Now - s;
                var ms = sp.TotalMilliseconds;
                int j = 0;
                Console.WriteLine("ms = " + ms);
            }

            Console.ReadLine();
        }
    }
}
