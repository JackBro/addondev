using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace lff
{
    class KeyMap
    {
        private Dictionary<string, string> _keymapdic = new Dictionary<string, string>();
        private static KeyMap keymap = null;
        private KeyMap()
        {
            this.init();
        }

        public static KeyMap GetInstance()
        {
            if (keymap == null)
                keymap = new KeyMap();

            return keymap;
        }

        private void init()
        {
            _keymapdic.Add("1", "D1");
            _keymapdic.Add("2", "D2");
            _keymapdic.Add("3", "D3");
            _keymapdic.Add("4", "D4");
            _keymapdic.Add("5", "D5");
            _keymapdic.Add("6", "D6");
            _keymapdic.Add("7", "D7");
            _keymapdic.Add("8", "D8");
            _keymapdic.Add("9", "D9");
            _keymapdic.Add("0", "D0");
            _keymapdic.Add("!", "D1, Shift");
            _keymapdic.Add("\"", "D2, Shift");
            _keymapdic.Add("#", "D3, Shift");
            _keymapdic.Add("$", "D4, Shift");
            _keymapdic.Add("%", "D5, Shift");
            _keymapdic.Add("&", "D6, Shift");
            _keymapdic.Add("'", "D7, Shift");
            _keymapdic.Add("(", "D8, Shift");
            _keymapdic.Add(")", "D9, Shift");

            _keymapdic.Add("-", "OemMinus");
            _keymapdic.Add("^", "Oem7");
            _keymapdic.Add(@"\", "Oem5");
            _keymapdic.Add("@", "Oemtilde");
            _keymapdic.Add("[", "OemOpenBrackets");
            _keymapdic.Add(";", "Oemplus");
            _keymapdic.Add(":", "Oem1");
            _keymapdic.Add("]", "Oem6");
            _keymapdic.Add(",", "Oemcomma");
            _keymapdic.Add(".", "OemPeriod");
            _keymapdic.Add("/", "OemQuestion");
            //_keymapdic.Add(@"\", "OemBackslash");

            _keymapdic.Add("=", "OemMinus, Shift");
            _keymapdic.Add("~", "Oem7, Shift");
            _keymapdic.Add("|", "Oem5, Shift");
            _keymapdic.Add("`", "Oemtilde, Shift");
            _keymapdic.Add("{", "OemOpenBrackets, Shift");
            _keymapdic.Add("+", "Oemplus, Shift");
            _keymapdic.Add("*", "Oem1, Shift");
            _keymapdic.Add("}", "Oem6, Shift");
            _keymapdic.Add("<", "Oemcomma, Shift");
            _keymapdic.Add(">", "OemPeriod, Shift");
            _keymapdic.Add("?", "OemQuestion, Shift");
            _keymapdic.Add("_", "OemBackslash, Shift");

            _keymapdic.Add("A", "A");
            _keymapdic.Add("B", "B");
            _keymapdic.Add("C", "C");
            _keymapdic.Add("D", "D");
            _keymapdic.Add("E", "E");
            _keymapdic.Add("F", "F");
            _keymapdic.Add("G", "G");
            _keymapdic.Add("H", "H");
            _keymapdic.Add("I", "I");
            _keymapdic.Add("J", "J");
            _keymapdic.Add("K", "K");
            _keymapdic.Add("L", "L");
            _keymapdic.Add("M", "M");
            _keymapdic.Add("N", "N");
            _keymapdic.Add("O", "O");
            _keymapdic.Add("P", "P");
            _keymapdic.Add("Q", "Q");
            _keymapdic.Add("R", "R");
            _keymapdic.Add("S", "S");
            _keymapdic.Add("T", "T");
            _keymapdic.Add("U", "U");
            _keymapdic.Add("V", "V");
            _keymapdic.Add("W", "W");
            _keymapdic.Add("X", "X");
            _keymapdic.Add("Y", "Y");
            _keymapdic.Add("Z", "Z");
        }
        public string GetKeyMap(Keys keydata)
        {
            string k = keydata.ToString();
            if (_keymapdic.ContainsKey(k))
            {
                return _keymapdic[k];
            }
            return string.Empty;
        }
    }
}
