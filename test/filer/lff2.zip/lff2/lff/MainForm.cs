using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace lff
{
    public partial class MainForm : Form
    {
        private Config config;

        public MainForm()
        {
            InitializeComponent();

            config = Config.GetInstance();
            try
            {
                string configdirectory = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), Environment.UserName);
                if (!Directory.Exists(configdirectory))
                {
                    Directory.CreateDirectory(configdirectory);
                }
                config.ConfigDirectory = configdirectory;
            }
            catch(IOException e)
            {
                config.ConfigDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            }
        }

        private void MainMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ListViewForm.ListViewPanel form = dockPanel1.ActiveContent as ListViewForm.ListViewPanel;
            //if (sender == newWindowToolStripMenuItem)
            //{
            //    ListViewForm.ListViewPanel newform = new ListViewForm.ListViewPanel();

            //    newform.ContextMenuStripPopup += new lff.ListViewForm.ContextMenuStripPopupEventHander(newform_ContextMenuStripPopup);
            //    newform.Show(dockPanel1, DockState.Document);

            //    newform.OpenNewTab(Path.GetDirectoryName(Application.ExecutablePath));
            //}
            //else if (sender == newTabToolStripMenuItem)
            //{
            //    form.OpenNewTab();
            //}
            //else if (sender == viewlistToolStripMenuItem)
            //{
            //    form.ChangeView(View.List);
            //}
            //else if (sender == viewdeitaleToolStripMenuItem)
            //{
            //    form.ChangeView(View.Details);
            //}
            //else if (sender == optionToolStripMenuItem)
            //{
            //    ConfigForm.ConfigForm configform = new lff.ConfigForm.ConfigForm();

            //    configform.ShowDialog();
            //}
            //else if (sender == sortbynameToolStripMenuItem)
            //{
            //    form.ActiveListView.ListViewSort(lff.ListViewForm.ListViewItemSortType.Name);
            //}
            //else if (sender == sortbynameRToolStripMenuItem)
            //{
            //    form.ActiveListView.ListViewSort(lff.ListViewForm.ListViewItemSortType.Name_R);
            //}
            //else if (sender == sortbysizeToolStripMenuItem)
            //{
            //    form.ActiveListView.ListViewSort(lff.ListViewForm.ListViewItemSortType.Size);
            //}
            //else if (sender == sortbysizeRToolStripMenuItem)
            //{
            //    form.ActiveListView.ListViewSort(lff.ListViewForm.ListViewItemSortType.Size_R);
            //}
            //else if (sender == cutToolStripMenuItem)
            //{
            //    form.ActiveListView.CutToClipBoard();
            //}
            //else if (sender == copyToolStripMenuItem)
            //{
            //    form.ActiveListView.CopyToClipBoard();
            //}
            //else if (sender == incsearchnextToolStripMenuItem)
            //{
            //    form.ActiveListView.IncSelectNextItem();
            //}
            //else if (sender == driveInfoToolStripMenuItem)
            //{
            //    DriveInfoForm dform = new DriveInfoForm();
            //    dform.ShowDialog();
            //}
            //else if (sender == moveToTopToolStripMenuItem)
            //{

            //}
            //else if (sender == moveToEndToolStripMenuItem)
            //{
            //    form.MoveItemToLast();
            //}
        }

        void newform_ContextMenuStripPopup(object sender, Point e)
        {
            //ContextMenuStrip contextmenu = sender as  ContextMenuStrip;
            //contextmenu.Items.Clear();

            //IDockContent[] documents = dockPanel1.DocumentsToArray();
            //foreach (IDockContent content in documents)
            //{
            //    ListViewForm.ListViewPanel form = content as ListViewForm.ListViewPanel;
            //    foreach (ListViewForm.FileListView listview in form)
            //    {
            //        ToolStripMenuItem item = new ToolStripMenuItem(Path.GetFileName(listview.CurrentPath));
            //        item.DisplayStyle = ToolStripItemDisplayStyle.Text;
            //        item.ToolTipText = listview.CurrentPath;
            //        item.Tag = listview.CurrentPath; 
            //        item.Click += delegate(object lsender, EventArgs le)
            //        {
            //            string path = item.Tag as string;
            //            IDockContent dock = this.GetFormByPath(path);
            //            ListViewForm.ListViewPanel listviewform = dock as ListViewForm.ListViewPanel;
            //            listviewform.SetActive(path);
            //            dock.DockHandler.Activate();

            //        };
            //        contextmenu.Items.Add(item);
            //    }
            //}
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //this.SaveXML();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //this.LoadXML();
        }

        //private void SaveXML()
        //{
        //    IDockContent[] documents = dockPanel1.DocumentsToArray();
        //    List<lff.ListViewForm.ListViewPanel> formlist = new List<lff.ListViewForm.ListViewPanel>();
        //    foreach (IDockContent content in documents)
        //    {
        //        ListViewForm.ListViewPanel form = content as ListViewForm.ListViewPanel;
        //        formlist.Add(form);
        //        //content.DockHandler.Close();
        //    }
        //    ListViewFormsP lp = new ListViewFormsP();
        //    lp.save(formlist);


        //    string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.config");
        //    dockPanel1.SaveAsXml(configFile);
        //}

        //private void LoadXML()
        //{
        //    string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.config");
        //    if (File.Exists(configFile))
        //        dockPanel1.LoadFromXml(configFile, m_deserializeDockContent);

        //    List<lff.ListViewForm.ListViewPanel> formlist = new List<lff.ListViewForm.ListViewPanel>();
        //    IDockContent[] documents = dockPanel1.DocumentsToArray();
        //    foreach (IDockContent content in documents)
        //    {
        //        ListViewForm.ListViewPanel form = content as ListViewForm.ListViewPanel;
        //        formlist.Add(form);
        //        form.ContextMenuStripPopup += new lff.ListViewForm.ContextMenuStripPopupEventHander(newform_ContextMenuStripPopup);
        //    }
        //    ListViewFormsP lp = new ListViewFormsP();
        //    lp.load(formlist);
        //}
    }
}