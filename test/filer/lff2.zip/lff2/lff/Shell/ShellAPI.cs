using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace lff.Shell
{
    public class ShellAPI
    {
        public const int S_OK = 0, S_FALSE = 1;

        public static REFIID IID_IShellFolder = new REFIID("000214E6-0000-0000-c000-000000000046");
        //public static REFIID IID_IContextMenu = new REFIID("000214E4-0000-0000-c000-000000000046");
        public static Guid IID_IContextMenu = new Guid("000214E4-0000-0000-c000-000000000046");

        public static Guid IID_IShellExtInit = new Guid("{000214e8-0000-0000-c000-000000000046}");
        public static Guid IID_IContextMenu2 = new Guid("{000214f4-0000-0000-c000-000000000046}");
        public static Guid IID_IContextMenu3 = new Guid("{bcfce0a0-ec17-11d0-8d10-00a0c90f2719}");

        public static Guid CLSID_NewMenu = new Guid("{D969A300-E7FF-11d0-A93B-00A0C90F2719}");

        [DllImport("user32.dll", ExactSpelling = true, CharSet = CharSet.Auto)]
        public static extern uint TrackPopupMenuEx(
            IntPtr hmenu,
            ShellAPI.TPM flags,
            int x,
            int y,
            IntPtr hwnd,
            IntPtr lptpm);

        // CreatePopupMenu
        [DllImport("user32.dll", EntryPoint = "CreatePopupMenu", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr CreatePopupMenu();
        // MessageBeep
        [DllImport("User32", EntryPoint = "MessageBeep", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool MessageBeep(int SoundType);

        // TrackPopupMenu
        [DllImport("user32.dll", EntryPoint = "TrackPopupMenu", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern int TrackPopupMenu(IntPtr hMenu, int wFlags, int x, int y, int nReserved, IntPtr hwnd, out Rect lprc);
        // SHGetDesktopFolder
        [DllImport("shell32.dll", EntryPoint = "SHGetDesktopFolder", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern void SHGetDesktopFolder(ref ShellAPI.IShellFolder sf);

        [DllImport("user32", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool DestroyMenu(IntPtr hMenu);

        [ComImport, Guid("00000000-0000-0000-c000-000000000046")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IUnknown
        {
            [PreserveSig]
            IntPtr QueryInterface(REFIID riid, out IntPtr pVoid);

            [PreserveSig]
            IntPtr AddRef();
            [PreserveSig]
            IntPtr Release();
        }
        public struct Rect
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
            public int Width
            {
                get
                {
                    return right - left;
                }
            }
            public int Height
            {
                get
                {
                    return bottom - top;
                }
            }
        }
        [ComImport, Guid("000214E6-0000-0000-c000-000000000046")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IShellFolder
        {
            [PreserveSig]
            int ParseDisplayName(IntPtr hwnd, IntPtr pbc, string pszDisplayName, ref int pchEaten, ref IntPtr ppidl, ref int pdwAttributes);

            [PreserveSig]
            int EnumObjects(IntPtr hWnd, ShellEnumFlags flags, ref IEnumIDList enumList);
            [PreserveSig]
            int BindToObject(IntPtr idList, IntPtr bindingContext, ref REFIID refiid, ref IShellFolder folder);

            [PreserveSig]
            int BindToStorage(ref IntPtr idList, IntPtr bindingContext, ref REFIID riid, IntPtr pVoid);
            [PreserveSig]
            int CompareIDs(int lparam, IntPtr idList1, IntPtr idList2);

            [PreserveSig]
            int CreateViewObject(IntPtr hWnd, REFIID riid, IntPtr pVoid);

            [PreserveSig]
            int GetAttributesOf(int count, ref IntPtr idList, out GetAttributeOfFlags attributes);
            [PreserveSig]
            //int GetUIObjectOf(IntPtr hwnd, int cidl, ref IntPtr apidl, ref REFIID riid, out int rgfReserved, ref IContextMenu ppv);
            int GetUIObjectOf(IntPtr hwnd, int cidl, ref IntPtr apidl, ref REFIID riid, out int rgfReserved, out IntPtr ppv);
            [PreserveSig]
            int GetDisplayNameOf(IntPtr idList, ShellGetDisplayNameOfFlags flags, ref STRRET strRet);
            [PreserveSig]
            int SetNameOf(IntPtr hWnd, ref IntPtr idList, IntPtr pOLEString, int flags, ref IntPtr pItemIDList);

        }
        [ComImport, Guid("000214f2-0000-0000-c000-000000000046")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IEnumIDList
        {
            [PreserveSig]
            int Next(int count, ref IntPtr idList, out int fetched);

            [PreserveSig]
            int Skip(int count);
            [PreserveSig]
            int Reset();
            [PreserveSig]
            int Clone(ref IEnumIDList list);
        }
        [ComImport, Guid("000214e4-0000-0000-c000-000000000046")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IContextMenu
        {
            [PreserveSig]
            int QueryContextMenu(IntPtr hMenu, int indexMenu, int idFirstCommand, int idLastCommand, QueryContextMenuFlags flags);

            [PreserveSig]
            int InvokeCommand(ref CMINVOKECOMMANDINFO ici);
            [PreserveSig]
            int GetCommandString(int idCommand, int type, int reserved, string commandName, int cchMax);
        }
        [ComImport, Guid("000214f4-0000-0000-c000-000000000046")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IContextMenu2
        {
            // Adds commands to a shortcut menu
            [PreserveSig()]
            Int32 QueryContextMenu(
                IntPtr hmenu,
                uint iMenu,
                uint idCmdFirst,
                uint idCmdLast,
                QueryContextMenuFlags uFlags);

            // Carries out the command associated with a shortcut menu item
            [PreserveSig()]
            Int32 InvokeCommand(
                ref CMINVOKECOMMANDINFO info);

            // Retrieves information about a shortcut menu command, 
            // including the help string and the language-independent, 
            // or canonical, name for the command
            [PreserveSig()]
            Int32 GetCommandString(
                uint idcmd,
                int uflags,
                uint reserved,
                string commandstring,
                int cch);

            // Allows client objects of the IContextMenu interface to 
            // handle messages associated with owner-drawn menu items
            [PreserveSig]
            Int32 HandleMenuMsg(
                uint uMsg,
                IntPtr wParam,
                IntPtr lParam);
        }
        [ComImport, Guid("bcfce0a0-ec17-11d0-8d10-00a0c90f2719")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IContextMenu3
        {
            // Adds commands to a shortcut menu
            [PreserveSig()]
            Int32 QueryContextMenu(
                IntPtr hmenu,
                uint iMenu,
                uint idCmdFirst,
                uint idCmdLast,
                QueryContextMenuFlags uFlags);

            // Carries out the command associated with a shortcut menu item
            [PreserveSig()]
            Int32 InvokeCommand(
                ref CMINVOKECOMMANDINFO info);

            // Retrieves information about a shortcut menu command, 
            // including the help string and the language-independent, 
            // or canonical, name for the command
            [PreserveSig()]
            Int32 GetCommandString(
                uint idcmd,
                int uflags,
                uint reserved,
                [MarshalAs(UnmanagedType.LPWStr)]
            StringBuilder commandstring,
                int cch);

            // Allows client objects of the IContextMenu interface to 
            // handle messages associated with owner-drawn menu items
            [PreserveSig]
            Int32 HandleMenuMsg(
                uint uMsg,
                IntPtr wParam,
                IntPtr lParam);

            // Allows client objects of the IContextMenu3 interface to 
            // handle messages associated with owner-drawn menu items
            [PreserveSig]
            Int32 HandleMenuMsg2(
                uint uMsg,
                IntPtr wParam,
                IntPtr lParam,
                IntPtr plResult);
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct REFIID
        {
            public int x;
            public short s1;
            public short s2;
            [MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 8)]
            public byte[] chars;
            public REFIID(string guid)
            {
                // Needs to be a string of the form:
                // "000214E6-0000-0000-c000-000000000046"
                string[] data = guid.Split('-');
                Debug.Assert(data.Length == 5);
                x = Convert.ToInt32(data[0], 16);
                s1 = Convert.ToInt16(data[1], 16);
                s2 = Convert.ToInt16(data[2], 16);
                string bytesData = data[3] + data[4];
                chars = new byte[] { Convert.ToByte(bytesData.Substring(0,2), 16), Convert.ToByte(bytesData.Substring(2,2), 16),
Convert.ToByte(bytesData.Substring(4,2), 16), Convert.ToByte(bytesData.Substring(6,2), 16),
Convert.ToByte(bytesData.Substring(8,2), 16), Convert.ToByte(bytesData.Substring(10,2), 16),
Convert.ToByte(bytesData.Substring(12,2), 16), Convert.ToByte(bytesData.Substring(14,2), 16) };
            }
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct STRRET
        {
            public STRRETFlags uType; // One of the STRRET values
            [MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 1024)]
            public byte[] cStr;
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct CMINVOKECOMMANDINFO
        {
            public int cbSize; // sizeof(CMINVOKECOMMANDINFO)
            public int fMask; // any combination of CMIC_MASK_*
            public IntPtr hwnd; // might be NULL (indicating no owner window)
            public IntPtr lpVerb; // either a string or MAKEINTRESOURCE(idOffset)
            public IntPtr lpParameters; // might be NULL (indicating no parameter)
            public IntPtr lpDirectory; // might be NULL (indicating no specific directory)
            public int nShow; // one of SW_ values for ShowWindow() API
            public int dwHotKey;
            public IntPtr hIcon;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct SHITEMID
        {
            public short cb;
            [MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 1)]
            public byte[] abID;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct ITEMIDLIST
        {
            public SHITEMID mkid;
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct POINT
        {
            public int x;
            public int y;
        };
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }
        // Enums
        [Flags]
        public enum ShellEnumFlags
        {
            SHCONTF_FOLDERS = 32, // for shell browser
            SHCONTF_NONFOLDERS = 64, // for default view
            SHCONTF_INCLUDEHIDDEN = 128, // for hidden/system objects
        }
        [Flags]
        public enum ShellGetDisplayNameOfFlags
        {
            SHGDN_NORMAL = 0, // default (display purpose)
            SHGDN_INFOLDER = 1, // displayed under a folder (relative)
            SHGDN_INCLUDE_NONFILESYS = 0x2000, // if not set, display names for shell name space items that are not in the file system will fail.
            SHGDN_FORADDRESSBAR = 0x4000, // for displaying in the address (drives dropdown) bar
            SHGDN_FORPARSING = 0x8000, // for ParseDisplayName or path
        }
        [Flags]
        public enum STRRETFlags
        {
            STRRET_WSTR = 0x0000, // Use STRRET.pOleStr
            STRRET_OFFSET = 0x0001, // Use STRRET.uOffset to Ansi
            STRRET_CSTR = 0x0002 // Use STRRET.cStr
        }
        [Flags]
        public enum GetAttributeOfFlags : long
        {
            DROPEFFECT_NONE = 0,
            DROPEFFECT_COPY = 1,
            DROPEFFECT_MOVE = 2,
            DROPEFFECT_LINK = 4,
            DROPEFFECT_SCROLL = 0x80000000,
            SFGAO_CANCOPY = DROPEFFECT_COPY, // Objects can be copied
            SFGAO_CANMOVE = DROPEFFECT_MOVE, // Objects can be moved
            SFGAO_CANLINK = DROPEFFECT_LINK, // Objects can be linked
            SFGAO_CANRENAME = 0x00000010, // Objects can be renamed
            SFGAO_CANDELETE = 0x00000020, // Objects can be deleted
            SFGAO_HASPROPSHEET = 0x00000040, // Objects have property sheets
            SFGAO_DROPTARGET = 0x00000100, // Objects are drop target
            SFGAO_CAPABILITYMASK = 0x00000177,
            SFGAO_LINK = 0x00010000, // Shortcut (link)
            SFGAO_SHARE = 0x00020000, // shared
            SFGAO_READONLY = 0x00040000, // read-only
            SFGAO_GHOSTED = 0x00080000, // ghosted icon
            SFGAO_HIDDEN = 0x00080000, // hidden object
            SFGAO_DISPLAYATTRMASK = 0x000F0000,
            SFGAO_FILESYSANCESTOR = 0x10000000, // It contains file system folder
            SFGAO_FOLDER = 0x20000000, // It's a folder.
            SFGAO_FILESYSTEM = 0x40000000, // is a file system thing (file/folder/root)
            SFGAO_HASSUBFOLDER = 0x80000000, // Expandable in the map pane
            SFGAO_CONTENTSMASK = 0x80000000,
            SFGAO_VALIDATE = 0x01000000, // invalidate cached information
            SFGAO_REMOVABLE = 0x02000000, // is this removeable media?
            SFGAO_COMPRESSED = 0x04000000, // Object is compressed (use alt color)
            SFGAO_BROWSABLE = 0x08000000, // is in-place browsable
            SFGAO_NONENUMERATED = 0x00100000, // is a non-enumerated object
            SFGAO_NEWCONTENT = 0x00200000 // should show bold in explorer tree
        }
        public enum QueryContextMenuFlags : long
        {
            CMF_NORMAL = 0x00000000,
            CMF_DEFAULTONLY = 0x00000001,
            CMF_VERBSONLY = 0x00000002,
            CMF_EXPLORE = 0x00000004,
            CMF_NOVERBS = 0x00000008,
            CMF_CANRENAME = 0x00000010,
            CMF_NODEFAULT = 0x00000020,
            CMF_INCLUDESTATIC = 0x00000040,
            CMF_EXTENDEDVERBS = 0x00000100,
            CMF_RESERVED = 0xffff0000
        }

        public enum WM : uint
        {
            ACTIVATE = 0x6,
            ACTIVATEAPP = 0x1C,
            AFXFIRST = 0x360,
            AFXLAST = 0x37F,
            APP = 0x8000,
            ASKCBFORMATNAME = 0x30C,
            CANCELJOURNAL = 0x4B,
            CANCELMODE = 0x1F,
            CAPTURECHANGED = 0x215,
            CHANGECBCHAIN = 0x30D,
            CHAR = 0x102,
            CHARTOITEM = 0x2F,
            CHILDACTIVATE = 0x22,
            CLEAR = 0x303,
            CLOSE = 0x10,
            COMMAND = 0x111,
            COMPACTING = 0x41,
            COMPAREITEM = 0x39,
            CONTEXTMENU = 0x7B,
            COPY = 0x301,
            COPYDATA = 0x4A,
            CREATE = 0x1,
            CTLCOLORBTN = 0x135,
            CTLCOLORDLG = 0x136,
            CTLCOLOREDIT = 0x133,
            CTLCOLORLISTBOX = 0x134,
            CTLCOLORMSGBOX = 0x132,
            CTLCOLORSCROLLBAR = 0x137,
            CTLCOLORSTATIC = 0x138,
            CUT = 0x300,
            DEADCHAR = 0x103,
            DELETEITEM = 0x2D,
            DESTROY = 0x2,
            DESTROYCLIPBOARD = 0x307,
            DEVICECHANGE = 0x219,
            DEVMODECHANGE = 0x1B,
            DISPLAYCHANGE = 0x7E,
            DRAWCLIPBOARD = 0x308,
            DRAWITEM = 0x2B,
            DROPFILES = 0x233,
            ENABLE = 0xA,
            ENDSESSION = 0x16,
            ENTERIDLE = 0x121,
            ENTERMENULOOP = 0x211,
            ENTERSIZEMOVE = 0x231,
            ERASEBKGND = 0x14,
            EXITMENULOOP = 0x212,
            EXITSIZEMOVE = 0x232,
            FONTCHANGE = 0x1D,
            GETDLGCODE = 0x87,
            GETFONT = 0x31,
            GETHOTKEY = 0x33,
            GETICON = 0x7F,
            GETMINMAXINFO = 0x24,
            GETOBJECT = 0x3D,
            GETSYSMENU = 0x313,
            GETTEXT = 0xD,
            GETTEXTLENGTH = 0xE,
            HANDHELDFIRST = 0x358,
            HANDHELDLAST = 0x35F,
            HELP = 0x53,
            HOTKEY = 0x312,
            HSCROLL = 0x114,
            HSCROLLCLIPBOARD = 0x30E,
            ICONERASEBKGND = 0x27,
            IME_CHAR = 0x286,
            IME_COMPOSITION = 0x10F,
            IME_COMPOSITIONFULL = 0x284,
            IME_CONTROL = 0x283,
            IME_ENDCOMPOSITION = 0x10E,
            IME_KEYDOWN = 0x290,
            IME_KEYLAST = 0x10F,
            IME_KEYUP = 0x291,
            IME_NOTIFY = 0x282,
            IME_REQUEST = 0x288,
            IME_SELECT = 0x285,
            IME_SETCONTEXT = 0x281,
            IME_STARTCOMPOSITION = 0x10D,
            INITDIALOG = 0x110,
            INITMENU = 0x116,
            INITMENUPOPUP = 0x117,
            INPUTLANGCHANGE = 0x51,
            INPUTLANGCHANGEREQUEST = 0x50,
            KEYDOWN = 0x100,
            KEYFIRST = 0x100,
            KEYLAST = 0x108,
            KEYUP = 0x101,
            KILLFOCUS = 0x8,
            LBUTTONDBLCLK = 0x203,
            LBUTTONDOWN = 0x201,
            LBUTTONUP = 0x202,
            LVM_GETEDITCONTROL = 0x1018,
            LVM_SETIMAGELIST = 0x1003,
            MBUTTONDBLCLK = 0x209,
            MBUTTONDOWN = 0x207,
            MBUTTONUP = 0x208,
            MDIACTIVATE = 0x222,
            MDICASCADE = 0x227,
            MDICREATE = 0x220,
            MDIDESTROY = 0x221,
            MDIGETACTIVE = 0x229,
            MDIICONARRANGE = 0x228,
            MDIMAXIMIZE = 0x225,
            MDINEXT = 0x224,
            MDIREFRESHMENU = 0x234,
            MDIRESTORE = 0x223,
            MDISETMENU = 0x230,
            MDITILE = 0x226,
            MEASUREITEM = 0x2C,
            MENUCHAR = 0x120,
            MENUCOMMAND = 0x126,
            MENUDRAG = 0x123,
            MENUGETOBJECT = 0x124,
            MENURBUTTONUP = 0x122,
            MENUSELECT = 0x11F,
            MOUSEACTIVATE = 0x21,
            MOUSEFIRST = 0x200,
            MOUSEHOVER = 0x2A1,
            MOUSELAST = 0x20A,
            MOUSELEAVE = 0x2A3,
            MOUSEMOVE = 0x200,
            MOUSEWHEEL = 0x20A,
            MOVE = 0x3,
            MOVING = 0x216,
            NCACTIVATE = 0x86,
            NCCALCSIZE = 0x83,
            NCCREATE = 0x81,
            NCDESTROY = 0x82,
            NCHITTEST = 0x84,
            NCLBUTTONDBLCLK = 0xA3,
            NCLBUTTONDOWN = 0xA1,
            NCLBUTTONUP = 0xA2,
            NCMBUTTONDBLCLK = 0xA9,
            NCMBUTTONDOWN = 0xA7,
            NCMBUTTONUP = 0xA8,
            NCMOUSEHOVER = 0x2A0,
            NCMOUSELEAVE = 0x2A2,
            NCMOUSEMOVE = 0xA0,
            NCPAINT = 0x85,
            NCRBUTTONDBLCLK = 0xA6,
            NCRBUTTONDOWN = 0xA4,
            NCRBUTTONUP = 0xA5,
            NEXTDLGCTL = 0x28,
            NEXTMENU = 0x213,
            NOTIFY = 0x4E,
            NOTIFYFORMAT = 0x55,
            NULL = 0x0,
            PAINT = 0xF,
            PAINTCLIPBOARD = 0x309,
            PAINTICON = 0x26,
            PALETTECHANGED = 0x311,
            PALETTEISCHANGING = 0x310,
            PARENTNOTIFY = 0x210,
            PASTE = 0x302,
            PENWINFIRST = 0x380,
            PENWINLAST = 0x38F,
            POWER = 0x48,
            PRINT = 0x317,
            PRINTCLIENT = 0x318,
            QUERYDRAGICON = 0x37,
            QUERYENDSESSION = 0x11,
            QUERYNEWPALETTE = 0x30F,
            QUERYOPEN = 0x13,
            QUEUESYNC = 0x23,
            QUIT = 0x12,
            RBUTTONDBLCLK = 0x206,
            RBUTTONDOWN = 0x204,
            RBUTTONUP = 0x205,
            RENDERALLFORMATS = 0x306,
            RENDERFORMAT = 0x305,
            SETCURSOR = 0x20,
            SETFOCUS = 0x7,
            SETFONT = 0x30,
            SETHOTKEY = 0x32,
            SETICON = 0x80,
            SETMARGINS = 0xD3,
            SETREDRAW = 0xB,
            SETTEXT = 0xC,
            SETTINGCHANGE = 0x1A,
            SHOWWINDOW = 0x18,
            SIZE = 0x5,
            SIZECLIPBOARD = 0x30B,
            SIZING = 0x214,
            SPOOLERSTATUS = 0x2A,
            STYLECHANGED = 0x7D,
            STYLECHANGING = 0x7C,
            SYNCPAINT = 0x88,
            SYSCHAR = 0x106,
            SYSCOLORCHANGE = 0x15,
            SYSCOMMAND = 0x112,
            SYSDEADCHAR = 0x107,
            SYSKEYDOWN = 0x104,
            SYSKEYUP = 0x105,
            TCARD = 0x52,
            TIMECHANGE = 0x1E,
            TIMER = 0x113,
            TVM_GETEDITCONTROL = 0x110F,
            TVM_SETIMAGELIST = 0x1109,
            UNDO = 0x304,
            UNINITMENUPOPUP = 0x125,
            USER = 0x400,
            USERCHANGED = 0x54,
            VKEYTOITEM = 0x2E,
            VSCROLL = 0x115,
            VSCROLLCLIPBOARD = 0x30A,
            WINDOWPOSCHANGED = 0x47,
            WINDOWPOSCHANGING = 0x46,
            WININICHANGE = 0x1A,
            SH_NOTIFY = 0x0401
        }

        // Specifies how TrackPopupMenuEx positions the shortcut menu horizontally
        [Flags]
        public enum TPM : uint
        {
            LEFTBUTTON = 0x0000,
            RIGHTBUTTON = 0x0002,
            LEFTALIGN = 0x0000,
            CENTERALIGN = 0x0004,
            RIGHTALIGN = 0x0008,
            TOPALIGN = 0x0000,
            VCENTERALIGN = 0x0010,
            BOTTOMALIGN = 0x0020,
            HORIZONTAL = 0x0000,
            VERTICAL = 0x0040,
            NONOTIFY = 0x0080,
            RETURNCMD = 0x0100,
            RECURSE = 0x0001,
            HORPOSANIMATION = 0x0400,
            HORNEGANIMATION = 0x0800,
            VERPOSANIMATION = 0x1000,
            VERNEGANIMATION = 0x2000,
            NOANIMATION = 0x4000,
            LAYOUTRTL = 0x8000
        }

        public static int cbMenuItemInfo = Marshal.SizeOf(typeof(MENUITEMINFO));
        [Flags]
        public enum MFT : uint
        {
            GRAYED = 0x00000003,
            DISABLED = 0x00000003,
            CHECKED = 0x00000008,
            SEPARATOR = 0x00000800,
            RADIOCHECK = 0x00000200,
            BITMAP = 0x00000004,
            OWNERDRAW = 0x00000100,
            MENUBARBREAK = 0x00000020,
            MENUBREAK = 0x00000040,
            RIGHTORDER = 0x00002000,
            BYCOMMAND = 0x00000000,
            BYPOSITION = 0x00000400,
            POPUP = 0x00000010
        }
        [Flags]
        public enum MIIM : uint
        {
            BITMAP = 0x80,
            CHECKMARKS = 0x08,
            DATA = 0x20,
            FTYPE = 0x100,
            ID = 0x02,
            STATE = 0x01,
            STRING = 0x40,
            SUBMENU = 0x04,
            TYPE = 0x10
        }
        [Flags]
        public enum MFS : uint
        {
            GRAYED = 0x00000003,
            DISABLED = 0x00000003,
            CHECKED = 0x00000008,
            HILITE = 0x00000080,
            ENABLED = 0x00000000,
            UNCHECKED = 0x00000000,
            UNHILITE = 0x00000000,
            DEFAULT = 0x00001000
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct MENUITEMINFO
        {
            public MENUITEMINFO(string text)
            {
                cbSize = cbMenuItemInfo;
                dwTypeData = text;
                cch = text.Length;
                fMask = 0;
                fType = 0;
                fState = 0;
                wID = 0;
                hSubMenu = IntPtr.Zero;
                hbmpChecked = IntPtr.Zero;
                hbmpUnchecked = IntPtr.Zero;
                dwItemData = IntPtr.Zero;
                hbmpItem = IntPtr.Zero;
            }

            public int cbSize;
            public MIIM fMask;
            public MFT fType;
            public MFS fState;
            public uint wID;
            public IntPtr hSubMenu;
            public IntPtr hbmpChecked;
            public IntPtr hbmpUnchecked;
            public IntPtr dwItemData;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string dwTypeData;
            public int cch;
            public IntPtr hbmpItem;
        }

        [DllImport("user32", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool AppendMenu(
            IntPtr hMenu,
            MFT uFlags,
            uint uIDNewItem,
            [MarshalAs(UnmanagedType.LPTStr)]
            string lpNewItem);

        [DllImport("user32", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool InsertMenuItem(
            IntPtr hMenu,
            uint uItem,
            bool fByPosition,
            ref MENUITEMINFO lpmii);

        [DllImport("ole32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int CoCreateInstance(
            ref Guid rclsid,
            IntPtr pUnkOuter,
            CLSCTX dwClsContext,
            ref Guid riid,
            out IntPtr ppv);

        [Flags]
        public enum CLSCTX : uint
        {
            INPROC_SERVER = 0x1,
            INPROC_HANDLER = 0x2,
            LOCAL_SERVER = 0x4,
            INPROC_SERVER16 = 0x8,
            REMOTE_SERVER = 0x10,
            INPROC_HANDLER16 = 0x20,
            RESERVED1 = 0x40,
            RESERVED2 = 0x80,
            RESERVED3 = 0x100,
            RESERVED4 = 0x200,
            NO_CODE_DOWNLOAD = 0x400,
            RESERVED5 = 0x800,
            NO_CUSTOM_MARSHAL = 0x1000,
            ENABLE_CODE_DOWNLOAD = 0x2000,
            NO_FAILURE_LOG = 0x4000,
            DISABLE_AAA = 0x8000,
            ENABLE_AAA = 0x10000,
            FROM_DEFAULT_CONTEXT = 0x20000,
            INPROC = INPROC_SERVER | INPROC_HANDLER,
            SERVER = INPROC_SERVER | LOCAL_SERVER | REMOTE_SERVER,
            ALL = SERVER | INPROC_HANDLER
        }

        [ComImport()]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [GuidAttribute("000214e8-0000-0000-c000-000000000046")]
        public interface IShellExtInit
        {
            [PreserveSig()]
            int Initialize(
                IntPtr pidlFolder,
                IntPtr lpdobj,
                uint hKeyProgID);
        }

        [DllImport("user32", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern IntPtr GetSubMenu(IntPtr hMenu, int nPos);

        [DllImport("user32", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern int GetMenuItemCount(IntPtr hMenu);

        [DllImport("user32")]
        public static extern int InsertMenu(IntPtr hMenu, uint Pos, uint ByPostion, uint uIDItem, string Title);
    }
}