using System;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Drawing;

namespace lff.Shell
{
    public delegate void ContextMenuClikEventHandler(object sender, ContextMenuClikEventArgs e);
    public class ContextMenuClikEventArgs : EventArgs
    {
        public Boolean cancel;
        public uint cmdid;
        public string[] files;

        public ContextMenuClikEventArgs()
        {
        }

        public void SetParam(uint cmdid, string[] files)
        {
            this.cancel = false;
            this.cmdid = cmdid;
            this.files = files;
        }

        public void Clear()
        {
            this.cancel = false;
            this.files = null;
        }

    }

    public enum CMDID : uint
    {
        CMD_DELETE = 18,
        CMD_RENAME = 19,
        CMD_CUT = 25,
        CMD_COPY = 26,
        CMD_PASTE = 27
    }

    public class ShellContextMenu : NativeWindow
    {
        private IContextMenu iContextMenu, newContextMenu;
        private IContextMenu2 iContextMenu2, newContextMenu2;
        //private ShellAPI.IContextMenu3 iContextMenu3, newContextMenu3;
        private ShellAPI.IContextMenu3 iContextMenu3, newContextMenu3;

        private IntPtr newSubmenuPtr;

        public const uint CMD_FIRST = 1;
        public const uint CMD_LAST = 30000;
        public event ContextMenuClikEventHandler ContextMenuClik = null;
        private ContextMenuClikEventArgs contextMenuClikEventArgs = new ContextMenuClikEventArgs();

        private const uint CMD_COPY = 26;
        private const uint CMD_PASTE = 27;
        private const uint CMD_DELETE = 18;
        private const uint CMD_RENAME = 19;

        private enum CMD_CUSTOM
        {
            Tiles = (int)CMD_LAST + 1,
            Icons,
            List,
            Details,
            Properties,
            Paste,
            Paste_ShortCut,
            SpecialView
        }

        // CreatePopupMenu
        [DllImport("user32.dll", EntryPoint = "CreatePopupMenu", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr CreatePopupMenu();
        // MessageBeep
        [DllImport("User32", EntryPoint = "MessageBeep", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool MessageBeep(int SoundType);

        // TrackPopupMenu
        [DllImport("user32.dll", EntryPoint = "TrackPopupMenu", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern int TrackPopupMenu(IntPtr hMenu, int wFlags, int x, int y, int nReserved, IntPtr hwnd, out Rect lprc);
        // SHGetDesktopFolder
        [DllImport("shell32.dll", EntryPoint = "SHGetDesktopFolder", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        static extern void SHGetDesktopFolder(ref IShellFolder sf);

        [DllImport("user32", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool DestroyMenu(IntPtr hMenu);

        public const int MIN_SHELL_ID = 1;
        public const int MAX_SHELL_ID = 0x7FFF;
        //
        public const int TPM_RETURNCMD = 0x100;
        public const int TPM_LEFTALIGN = 0x0;
        //
        public const int SW_SHOWNORMAL = 1;
        static int m_pidlCount = 0;
        static IntPtr[] m_ipList;
        public static int MAKEINTRESOURCE(int res)
        {
            return 0x0000FFFF & res;
        }

        //
        [DllImport("user32.dll", ExactSpelling = true, CharSet = CharSet.Auto)]
        public static extern uint TrackPopupMenuEx(
            IntPtr hmenu,
            TPM flags,
            int x,
            int y,
            IntPtr hwnd,
            IntPtr lptpm);

        public ShellContextMenu()
        {
            //
            // All static, no instances
            //
            this.CreateHandle(new CreateParams());
        }

        public int ShowContextMenu(Control control, string[] strFiles, int intX, int intY, bool blnErrorBeep)
        {
            IntPtr hwnd = control.Handle;
            CMINVOKECOMMANDINFO CI = new CMINVOKECOMMANDINFO();
            DirectoryInfo dInfo;
            FileInfo fInfo;
            uint cmdID; // LongBool
            int pchEaten = 0; // DWORD pchEaten;
            int dwAttributes = new int(); // ULONG
            int intZero = 0;
            int intCount;
            IntPtr ipParent = new IntPtr(); // LPITEMIDLIST
            IntPtr ipChild = new IntPtr(); // LPITEMIDLIST
            IntPtr hMenu = new IntPtr(); // HMENU
            IShellFolder DesktopFolder = null; // IShellFolder
            IShellFolder ParentFolder = null; // IShellfolder ParentFolder
            //Rect mRect;
            REFIID IID_IShellFolder = new REFIID("000214E6-0000-0000-c000-000000000046");
            REFIID IID_IContextMenu = new REFIID("000214E4-0000-0000-c000-000000000046");

            //
            Guid IID_IContextMenu2 = new Guid("{000214f4-0000-0000-c000-000000000046}");
            Guid IID_IContextMenu3 = new Guid("{bcfce0a0-ec17-11d0-8d10-00a0c90f2719}");

            //
            IntPtr iContextMenuPtr = IntPtr.Zero,
                iContextMenuPtr2 = IntPtr.Zero,
                iContextMenuPtr3 = IntPtr.Zero;
            
            //
            string strFullName = "";
            string strFilePath = "";
            string strFileName = "";
            string strFQName = "";
            m_pidlCount = 0;
            for (intCount = 0; intCount <= strFiles.GetUpperBound(0); intCount++)
            {
                strFullName = strFiles[intCount];
                fInfo = new FileInfo(strFullName);
                if (fInfo.Exists)
                {
                    strFilePath = fInfo.DirectoryName;
                    strFileName = fInfo.Name;
                    strFQName = fInfo.FullName;
                }
                else
                {
                    dInfo = new DirectoryInfo(strFullName);
                    if (dInfo.Exists)
                    {
                        try
                        {
                            strFileName = dInfo.Name;
                            strFilePath = dInfo.Parent.FullName;
                        }
                        catch
                        {
                            strFilePath = "";
                        }
                    }
                }
                SHGetDesktopFolder(ref DesktopFolder);

                // ParseDisplayName - parent
                // Translates a file object's or folder's display name into an item identifier list
                pchEaten = 1;
                dwAttributes = 0;
                ipParent = new IntPtr();
                DesktopFolder.ParseDisplayName(hwnd, IntPtr.Zero, strFilePath, ref pchEaten, ref ipParent, ref dwAttributes);

                // BindToObject
                // Retrieves an IShellFolder object for a subfolder
                ParentFolder = null;
                DesktopFolder.BindToObject(ipParent, IntPtr.Zero, ref IID_IShellFolder, ref ParentFolder);
                // ParseDisplayName - child
                // Translates a file object's or folder's display name into an item identifier list
                pchEaten = 1;
                dwAttributes = 0;
                ipChild = new IntPtr();
                ParentFolder.ParseDisplayName(hwnd, IntPtr.Zero, strFileName, ref pchEaten, ref ipChild, ref dwAttributes);
                JAddItemToIDList(ipChild);
            }

            try
            {
                int intReturn = ParentFolder.GetUIObjectOf(hwnd, m_pidlCount, ref m_ipList[0], ref IID_IContextMenu, out intZero, out iContextMenuPtr);
                if (intReturn == 0)
                {
                    iContextMenu = (IContextMenu)Marshal.GetTypedObjectForIUnknown(iContextMenuPtr, typeof(IContextMenu));
                    hMenu = CreatePopupMenu();
                    iContextMenu.QueryContextMenu(
                                        hMenu,
                                        0,
                                        (int)CMD_FIRST,
                                        (int)CMD_LAST,
                                        QueryContextMenuFlags.CMF_EXPLORE |
                                        QueryContextMenuFlags.CMF_CANRENAME |
                                        ((Control.ModifierKeys & Keys.Shift) != 0 ? QueryContextMenuFlags.CMF_EXTENDEDVERBS : 0));
                    //
                    Marshal.QueryInterface(iContextMenuPtr, ref IID_IContextMenu2, out iContextMenuPtr2);
                    iContextMenu2 = (IContextMenu2)Marshal.GetTypedObjectForIUnknown(iContextMenuPtr2, typeof(IContextMenu2));
                    //


                    ShellAPI.MENUITEMINFO menuiteminfo = new ShellAPI.MENUITEMINFO();
                    menuiteminfo.cbSize = (int)Marshal.SizeOf(typeof(ShellAPI.MENUITEMINFO));
                    menuiteminfo.fMask = ShellAPI.MIIM.ID | ShellAPI.MIIM.STRING | ShellAPI.MIIM.DATA;// 16;
                    menuiteminfo.fType = 0;
                    menuiteminfo.cch = 256;
                    //menuiteminfo.dwTypeData = null;
                    menuiteminfo.dwTypeData = "test";// new String('\0', (int)(menuiteminfo.cch + 1));
                    menuiteminfo.wID = 988;
                    ShellAPI.InsertMenuItem(hMenu, 0, true, ref menuiteminfo);

                    cmdID = TrackPopupMenuEx(
                        hMenu,
                        TPM.RETURNCMD,
                        intX,
                        intY,
                        this.Handle,
                        IntPtr.Zero);

                    if (cmdID != 0)
                    {
                        switch (cmdID)
                        {
                            case (uint)CMDID.CMD_CUT:
                            case (uint)CMDID.CMD_COPY:
                            case (uint)CMDID.CMD_PASTE:
                            case (uint)CMDID.CMD_DELETE:
                            case (uint)CMDID.CMD_RENAME:
                                if (ContextMenuClik != null)
                                {
                                    contextMenuClikEventArgs.Clear();
                                    contextMenuClikEventArgs.SetParam(cmdID, strFiles);
                                    ContextMenuClik(control, contextMenuClikEventArgs);
                                }
                                break;
                            default:
                                CI.cbSize = Marshal.SizeOf(CI);
                                CI.hwnd = hwnd;
                                CI.lpVerb = (IntPtr)MAKEINTRESOURCE((int)cmdID - 1);
                                CI.lpParameters = IntPtr.Zero;
                                CI.lpDirectory = string.Empty;
                                CI.nShow = SW_SHOWNORMAL;
                                iContextMenu.InvokeCommand(ref CI);
                                break;
                        }
                    }
                }
                else
                {
                    if (blnErrorBeep)
                        MessageBeep(-1);
                }
                return 0;

            }
            catch (Exception) { }
            finally
            {
                if (iContextMenu != null)
                {
                    Marshal.ReleaseComObject(iContextMenu);
                    iContextMenu = null;
                }

                if (iContextMenu2 != null)
                {
                    Marshal.ReleaseComObject(iContextMenu2);
                    iContextMenu2 = null;
                }

                if (iContextMenuPtr != IntPtr.Zero)
                    Marshal.Release(iContextMenuPtr);

                if (iContextMenuPtr2 != IntPtr.Zero)
                    Marshal.Release(iContextMenuPtr2);
                
                if (hMenu != null)
                    DestroyMenu(hMenu);

                if (ipParent != IntPtr.Zero)
                    Marshal.Release(ipParent);

                //if (ipChild != IntPtr.Zero)
                //    Marshal.Release(ipChild);

                if (DesktopFolder != null)
                    Marshal.ReleaseComObject(DesktopFolder);

                if (ParentFolder != null)
                    Marshal.ReleaseComObject(ParentFolder);
            }
            return 0;
        }

        public void CreateFolderMenu(Control control, string path, Point ptInvoke)
        {
            #region Fields
            IntPtr contextMenu = IntPtr.Zero, 
                viewSubMenu = IntPtr.Zero;
            IntPtr newContextMenuPtr = IntPtr.Zero, 
                newContextMenuPtr2 = IntPtr.Zero, 
                newContextMenuPtr3 = IntPtr.Zero;
            newSubmenuPtr = IntPtr.Zero;

            CMINVOKECOMMANDINFO CI = new CMINVOKECOMMANDINFO();
            int newSubmenuPos = 0;
            #endregion

            try
            {
                #region Make Menu

                contextMenu = ShellAPI.CreatePopupMenu();
                viewSubMenu = ShellAPI.CreatePopupMenu();

                #region View Submenu

                ShellAPI.MENUITEMINFO itemInfo = new ShellAPI.MENUITEMINFO("View");
                itemInfo.cbSize = ShellAPI.cbMenuItemInfo;
                itemInfo.fMask = ShellAPI.MIIM.SUBMENU | ShellAPI.MIIM.STRING;
                itemInfo.hSubMenu = viewSubMenu;
                ShellAPI.InsertMenuItem(contextMenu, 0, true, ref itemInfo);

                ShellAPI.MFT rCheck = ShellAPI.MFT.RADIOCHECK | ShellAPI.MFT.CHECKED;
                //ShellAPI.AppendMenu(viewSubMenu,
                //    (br.CurrentViewPlugin == null && br.FileView.View == View.Tile ? rCheck : 0), (uint)CMD_CUSTOM.Tiles, "Tiles");
                //ShellAPI.AppendMenu(viewSubMenu,
                //    (br.CurrentViewPlugin == null && br.FileView.View == View.LargeIcon ? rCheck : 0), (uint)CMD_CUSTOM.Icons, "Icons");
                //ShellAPI.AppendMenu(viewSubMenu, 0, (uint)CMD_CUSTOM.List, "List");
                //ShellAPI.AppendMenu(viewSubMenu, 0, (uint)CMD_CUSTOM.Details, "Details");

                //for (int i = 0; i < pluginWrapper.ViewPlugins.Count; i++)
                //{
                //    ShellAPI.AppendMenu(viewSubMenu,
                //        (IViewPlugin.Equals(br.CurrentViewPlugin, pluginWrapper.ViewPlugins[i]) ? rCheck : 0),
                //            (uint)CMD_CUSTOM.SpecialView + (uint)i, ((IViewPlugin)pluginWrapper.ViewPlugins[i]).ViewName);
                //}

                #endregion

                #region Paste Menu

                //DragDropEffects effects = ShellHelper.CanDropClipboard(currentItem);
                //bool canPaste = (effects & DragDropEffects.Copy) != 0 || (effects & DragDropEffects.Move) != 0;
                //bool canPasteShortCut = (effects & DragDropEffects.Link) != 0;

                ShellAPI.AppendMenu(contextMenu, ShellAPI.MFT.SEPARATOR, 0, string.Empty);
                //ShellAPI.AppendMenu(contextMenu, canPaste ? 0 : ShellAPI.MFT.GRAYED, (int)CMD_CUSTOM.Paste, "Paste");
                //ShellAPI.AppendMenu(contextMenu, canPasteShortCut ? 0 : ShellAPI.MFT.GRAYED, (int)CMD_CUSTOM.Paste_ShortCut, "Paste Shortcut");

                #endregion

                #region New Submenu

                if (this.GetNewContextMenu(control.Handle, path, out newContextMenuPtr, out newContextMenu))
                {
                    ShellAPI.AppendMenu(contextMenu, ShellAPI.MFT.SEPARATOR, 0, string.Empty);
                    newSubmenuPos = ShellAPI.GetMenuItemCount(contextMenu);
                    newContextMenu.QueryContextMenu(
                        contextMenu,
                        newSubmenuPos,
                        (int)CMD_FIRST,
                        (int)CMD_LAST,
                        QueryContextMenuFlags.CMF_NORMAL);

                    newSubmenuPtr = ShellAPI.GetSubMenu(contextMenu, newSubmenuPos);

                    Marshal.QueryInterface(newContextMenuPtr, ref ShellAPI.IID_IContextMenu2, out newContextMenuPtr2);
                    Marshal.QueryInterface(newContextMenuPtr, ref ShellAPI.IID_IContextMenu3, out newContextMenuPtr3);

                    try
                    {
                        newContextMenu2 =
                            (IContextMenu2)Marshal.GetTypedObjectForIUnknown(newContextMenuPtr2, typeof(IContextMenu2));

                        newContextMenu3 =
                            (ShellAPI.IContextMenu3)Marshal.GetTypedObjectForIUnknown(newContextMenuPtr3, typeof(ShellAPI.IContextMenu3));
                    }
                    catch (Exception) { }
                }

                #endregion

                #region Properties Menu

                    ShellAPI.AppendMenu(contextMenu, ShellAPI.MFT.SEPARATOR, 0, string.Empty);
                    ShellAPI.AppendMenu(contextMenu, 0, (int)CMD_CUSTOM.Properties, "Properties");

                #endregion

                #endregion

                CMD_CUSTOM selected = (CMD_CUSTOM)ShellAPI.TrackPopupMenuEx(
                                    contextMenu,
                                    ShellAPI.TPM.RETURNCMD,
                                    ptInvoke.X,
                                    ptInvoke.Y,
                                    this.Handle,
                                    IntPtr.Zero);

                #region Invoke

                if ((int)selected >= CMD_FIRST)
                {
                    switch (selected)
                    {
                        #region Normal Views

                        case CMD_CUSTOM.List:
                            //br.FileView.View = View.List;
                            //br.ResetSpecialView();
                            //provider.ReleaseStorage();
                            //provider.ReleaseStream();
                            break;
                        case CMD_CUSTOM.Details:
                            //br.FileView.SuspendHeaderContextMenu = true;
                            //br.FileView.View = View.Details;
                            //br.ResetSpecialView();
                            //provider.ReleaseStorage();
                            //provider.ReleaseStream();
                            break;

                        #endregion

                        #region Folder Items

                        case CMD_CUSTOM.Properties:
                            //ContextMenuHelper.InvokeCommand(
                            //    br.SelectedItem.ParentItem,
                            //    new IntPtr[] { br.SelectedItem.PIDLRel.Ptr },
                            //    "properties",
                            //    ptInvoke);
                            break;

                        case CMD_CUSTOM.Paste:
                            //ContextMenuHelper.InvokeCommand(
                            //    br.SelectedItem.ParentItem,
                            //    new IntPtr[] { br.SelectedItem.PIDLRel.Ptr },
                            //    "paste",
                            //    ptInvoke);
                            break;

                        case CMD_CUSTOM.Paste_ShortCut:
                            //ContextMenuHelper.InvokeCommand(
                            //    br.SelectedItem.ParentItem,
                            //    new IntPtr[] { br.SelectedItem.PIDLRel.Ptr },
                            //    "pastelink",
                            //    ptInvoke);
                            break;

                        #endregion

                        default:
                            #region New
                            if ((uint)selected <= CMD_LAST)
                            {
                                //ContextMenuHelper.InvokeCommand(
                                //    newContextMenu,
                                //    (uint)selected - ShellAPI.CMD_FIRST,
                                //    ShellItem.GetRealPath(br.SelectedItem),
                                //    ptInvoke);
                                CI.cbSize = Marshal.SizeOf(CI);
                                //CI.hwnd = control.Handle;
                                CI.lpVerb = (IntPtr)MAKEINTRESOURCE((int)selected - 1);
                                CI.lpParameters = IntPtr.Zero;
                                CI.lpDirectory = path;
                                CI.nShow = SW_SHOWNORMAL;
                                newContextMenu.InvokeCommand(ref CI);
                            }
                            #endregion
                            #region Special Views
                            //else
                            //{
                            //    int index = (int)selected - (int)CMD_CUSTOM.SpecialView;

                            //    if (br.FileView.Alignment != ListViewAlignment.Left)
                            //        br.FileView.Alignment = ListViewAlignment.Left;

                            //    br.FileView.View = View.LargeIcon;
                            //    br.CurrentViewPlugin = pluginWrapper.ViewPlugins[index] as IViewPlugin;
                            //    br.SpecialViewPanelVisible = true;
                            //    br.SpecialViewPanel.Controls.Add(br.CurrentViewPlugin.ViewControl);
                            //    br.CurrentViewPlugin.ViewControl.Dock = DockStyle.Fill;
                            //}
                            #endregion
                            break;
                    }
                }

                #endregion
            }
            catch (Exception) { }
            #region Finally
            finally
            {
                if (newContextMenu != null)
                {
                    Marshal.ReleaseComObject(newContextMenu);
                    newContextMenu = null;
                }

                if (newContextMenu2 != null)
                {
                    Marshal.ReleaseComObject(newContextMenu2);
                    newContextMenu2 = null;
                }

                if (newContextMenu3 != null)
                {
                    Marshal.ReleaseComObject(newContextMenu3);
                    newContextMenu3 = null;
                }

                if (contextMenu != null)
                    ShellAPI.DestroyMenu(contextMenu);

                if (viewSubMenu != null)
                    ShellAPI.DestroyMenu(viewSubMenu);

                if (newContextMenuPtr != IntPtr.Zero)
                    Marshal.Release(newContextMenuPtr);

                if (newContextMenuPtr2 != IntPtr.Zero)
                    Marshal.Release(newContextMenuPtr2);

                if (newContextMenuPtr3 != IntPtr.Zero)
                    Marshal.Release(newContextMenuPtr3);

                newSubmenuPtr = IntPtr.Zero;
            }
            #endregion
        }
        
        private void JAddItemToIDList(IntPtr ipNew)
        {
            if (m_pidlCount == 0)
            {
                m_ipList = new IntPtr[1];
                m_ipList[0] = ipNew;
                m_pidlCount++;
                return;
            }
            int intCount;
            IntPtr[] ipTemp = new IntPtr[m_pidlCount];
            for (intCount = 0; intCount < m_pidlCount; intCount++)
                ipTemp[intCount] = m_ipList[intCount];
            m_ipList = new IntPtr[m_pidlCount + 1];
            for (intCount = 0; intCount < m_pidlCount; intCount++)
                m_ipList[intCount] = ipTemp[intCount];

            m_ipList[intCount] = ipNew;
            m_pidlCount++;
        }

        protected override void WndProc(ref Message m)
        {

            #region IContextMenu2

            if (iContextMenu2 != null &&
                (m.Msg == (int)WM.INITMENUPOPUP ||
                 m.Msg == (int)WM.MEASUREITEM ||
                 m.Msg == (int)WM.DRAWITEM))
            {
                if (iContextMenu2.HandleMenuMsg(
                    (uint)m.Msg, m.WParam, m.LParam) == 0)
                    return;
            }
            if (newContextMenu2 != null &&
                ((m.Msg == (int)ShellAPI.WM.INITMENUPOPUP && m.WParam == newSubmenuPtr) ||
                 m.Msg == (int)ShellAPI.WM.MEASUREITEM ||
                 m.Msg == (int)ShellAPI.WM.DRAWITEM))
            {
                if (newContextMenu2.HandleMenuMsg(
                    (uint)m.Msg, m.WParam, m.LParam) == ShellAPI.S_OK)
                    return;
            }

            #endregion

            #region IContextMenu3

            if (iContextMenu3 != null &&
                m.Msg == (int)ShellAPI.WM.MENUCHAR)
            {
                if (iContextMenu3.HandleMenuMsg2(
                    (uint)m.Msg, m.WParam, m.LParam, IntPtr.Zero) == ShellAPI.S_OK)
                    return;
            }

            if (newContextMenu3 != null &&
                m.Msg == (int)ShellAPI.WM.MENUCHAR)
            {
                if (newContextMenu3.HandleMenuMsg2(
                    (uint)m.Msg, m.WParam, m.LParam, IntPtr.Zero) == ShellAPI.S_OK)
                    return;
            }

            #endregion   

            base.WndProc(ref m);
        }

        private bool GetNewContextMenu(IntPtr hwnd, string path, out IntPtr iContextMenuPtr, out IContextMenu iContextMenu)
        {
            if (ShellAPI.CoCreateInstance(
                    ref ShellAPI.CLSID_NewMenu,
                    IntPtr.Zero,
                    ShellAPI.CLSCTX.INPROC_SERVER,
                    ref ShellAPI.IID_IContextMenu,
                    out iContextMenuPtr) == ShellAPI.S_OK)
            {
                iContextMenu = Marshal.GetTypedObjectForIUnknown(iContextMenuPtr, typeof(IContextMenu)) as IContextMenu;

                IntPtr iShellExtInitPtr;
                if (Marshal.QueryInterface(
                    iContextMenuPtr,
                    ref ShellAPI.IID_IShellExtInit,
                    out iShellExtInitPtr) == ShellAPI.S_OK)
                {
                    ShellAPI.IShellExtInit iShellExtInit = Marshal.GetTypedObjectForIUnknown(
                        iShellExtInitPtr, typeof(ShellAPI.IShellExtInit)) as ShellAPI.IShellExtInit;
                    string[] files = new string[1];
                    files[0] = path;
                    this.MakePIDL(hwnd, files);

                    iShellExtInit.Initialize(m_ipList[0], IntPtr.Zero, 0);

                    Marshal.ReleaseComObject(iShellExtInit);
                    Marshal.Release(iShellExtInitPtr);
                    //pidlFull.Free();

                    return true;
                }
                else
                {
                    if (iContextMenu != null)
                    {
                        Marshal.ReleaseComObject(iContextMenu);
                        iContextMenu = null;
                    }

                    if (iContextMenuPtr != IntPtr.Zero)
                    {
                        Marshal.Release(iContextMenuPtr);
                        iContextMenuPtr = IntPtr.Zero;
                    }

                    return false;
                }
            }
            else
            {
                iContextMenuPtr = IntPtr.Zero;
                iContextMenu = null;
                return false;
            }
        }

        private void MakePIDL(IntPtr hwnd, string[] strFiles)
        {
            REFIID IID_IShellFolder = new REFIID("000214E6-0000-0000-c000-000000000046");
            int intCount;
            DirectoryInfo dInfo;
            FileInfo fInfo;
            IShellFolder DesktopFolder = null; // IShellFolder
            IShellFolder ParentFolder = null; // IShellfolder ParentFolder
            int pchEaten = 0; // DWORD pchEaten;
            int dwAttributes = new int(); // ULONG
            IntPtr ipParent = new IntPtr(); // LPITEMIDLIST
            IntPtr ipChild = new IntPtr(); // LPITEMIDLIST
            //
            string strFullName = "";
            string strFilePath = "";
            string strFileName = "";
            string strFQName = "";
            m_pidlCount = 0;
            for (intCount = 0; intCount <= strFiles.GetUpperBound(0); intCount++)
            {
                strFullName = strFiles[intCount];
                fInfo = new FileInfo(strFullName);
                if (fInfo.Exists)
                {
                    strFilePath = fInfo.DirectoryName;
                    strFileName = fInfo.Name;
                    strFQName = fInfo.FullName;
                }
                else
                {
                    dInfo = new DirectoryInfo(strFullName);
                    if (dInfo.Exists)
                    {
                        try
                        {
                            strFileName = dInfo.Name;
                            strFilePath = dInfo.Parent.FullName;
                        }
                        catch
                        {
                            strFilePath = "";
                        }
                    }
                }
                SHGetDesktopFolder(ref DesktopFolder);

                // ParseDisplayName - parent
                // Translates a file object's or folder's display name into an item identifier list
                pchEaten = 1;
                dwAttributes = 0;
                ipParent = new IntPtr();
                DesktopFolder.ParseDisplayName(hwnd, IntPtr.Zero, strFilePath, ref pchEaten, ref ipParent, ref dwAttributes);

                // BindToObject
                // Retrieves an IShellFolder object for a subfolder
                ParentFolder = null;
                DesktopFolder.BindToObject(ipParent, IntPtr.Zero, ref IID_IShellFolder, ref ParentFolder);
                // ParseDisplayName - child
                // Translates a file object's or folder's display name into an item identifier list
                pchEaten = 1;
                dwAttributes = 0;
                ipChild = new IntPtr();
                ParentFolder.ParseDisplayName(hwnd, IntPtr.Zero, strFileName, ref pchEaten, ref ipChild, ref dwAttributes);
                JAddItemToIDList(ipChild);
            }
        }
    }

    [ComImport, Guid("00000000-0000-0000-c000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IUnknown
    {
        [PreserveSig]
        IntPtr QueryInterface(REFIID riid, out IntPtr pVoid);

        [PreserveSig]
        IntPtr AddRef();
        [PreserveSig]
        IntPtr Release();
    }
    public struct Rect
    {
        public int left;
        public int top;
        public int right;
        public int bottom;
        public int Width
        {
            get
            {
                return right - left;
            }
        }
        public int Height
        {
            get
            {
                return bottom - top;
            }
        }
    }
    [ComImport, Guid("000214E6-0000-0000-c000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IShellFolder
    {
        [PreserveSig]
        int ParseDisplayName(IntPtr hwnd, IntPtr pbc, string pszDisplayName, ref int pchEaten, ref IntPtr ppidl, ref int pdwAttributes);

        [PreserveSig]
        int EnumObjects(IntPtr hWnd, ShellEnumFlags flags, ref IEnumIDList enumList);
        [PreserveSig]
        int BindToObject(IntPtr idList, IntPtr bindingContext, ref REFIID refiid, ref IShellFolder folder);

        [PreserveSig]
        int BindToStorage(ref IntPtr idList, IntPtr bindingContext, ref REFIID riid, IntPtr pVoid);
        [PreserveSig]
        int CompareIDs(int lparam, IntPtr idList1, IntPtr idList2);

        [PreserveSig]
        int CreateViewObject(IntPtr hWnd, REFIID riid, IntPtr pVoid);

        [PreserveSig]
        int GetAttributesOf(int count, ref IntPtr idList, out GetAttributeOfFlags attributes);
        [PreserveSig]
        //int GetUIObjectOf(IntPtr hwnd, int cidl, ref IntPtr apidl, ref REFIID riid, out int rgfReserved, ref IContextMenu ppv);
        int GetUIObjectOf(IntPtr hwnd, int cidl, ref IntPtr apidl, ref REFIID riid, out int rgfReserved, out IntPtr ppv);
        [PreserveSig]
        int GetDisplayNameOf(IntPtr idList, ShellGetDisplayNameOfFlags flags, ref STRRET strRet);
        [PreserveSig]
        int SetNameOf(IntPtr hWnd, ref IntPtr idList, IntPtr pOLEString, int flags, ref IntPtr pItemIDList);

    }
    [ComImport, Guid("000214f2-0000-0000-c000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IEnumIDList
    {
        [PreserveSig]
        int Next(int count, ref IntPtr idList, out int fetched);

        [PreserveSig]
        int Skip(int count);
        [PreserveSig]
        int Reset();
        [PreserveSig]
        int Clone(ref IEnumIDList list);
    }
    [ComImport, Guid("000214e4-0000-0000-c000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IContextMenu
    {
        [PreserveSig]
        int QueryContextMenu(IntPtr hMenu, int indexMenu, int idFirstCommand, int idLastCommand, QueryContextMenuFlags flags);

        [PreserveSig]
        int InvokeCommand(ref CMINVOKECOMMANDINFO ici);
        [PreserveSig]
        int GetCommandString(int idCommand, int type, int reserved, string commandName, int cchMax);
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct REFIID
    {
        public int x;
        public short s1;
        public short s2;
        [MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] chars;
        public REFIID(string guid)
        {
            // Needs to be a string of the form:
            // "000214E6-0000-0000-c000-000000000046"
            string[] data = guid.Split('-');
            Debug.Assert(data.Length == 5);
            x = Convert.ToInt32(data[0], 16);
            s1 = Convert.ToInt16(data[1], 16);
            s2 = Convert.ToInt16(data[2], 16);
            string bytesData = data[3] + data[4];
            chars = new byte[] { Convert.ToByte(bytesData.Substring(0,2), 16), Convert.ToByte(bytesData.Substring(2,2), 16),
Convert.ToByte(bytesData.Substring(4,2), 16), Convert.ToByte(bytesData.Substring(6,2), 16),
Convert.ToByte(bytesData.Substring(8,2), 16), Convert.ToByte(bytesData.Substring(10,2), 16),
Convert.ToByte(bytesData.Substring(12,2), 16), Convert.ToByte(bytesData.Substring(14,2), 16) };
        }
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct STRRET
    {
        public STRRETFlags uType; // One of the STRRET values
        [MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 1024)]
        public byte[] cStr;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct CMINVOKECOMMANDINFO
    {
        public int cbSize; // sizeof(CMINVOKECOMMANDINFO)
        public int fMask; // any combination of CMIC_MASK_*
        public IntPtr hwnd; // might be NULL (indicating no owner window)
        public IntPtr lpVerb; // either a string or MAKEINTRESOURCE(idOffset)
        public IntPtr lpParameters; // might be NULL (indicating no parameter)
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpDirectory; // might be NULL (indicating no specific directory)
        public int nShow; // one of SW_ values for ShowWindow() API
        public int dwHotKey;
        public IntPtr hIcon;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct SHITEMID
    {
        public short cb;
        [MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 1)]
        public byte[] abID;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct ITEMIDLIST
    {
        public SHITEMID mkid;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct POINT
    {
        public int x;
        public int y;
    };
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
    // Enums
    [Flags]
    public enum ShellEnumFlags
    {
        SHCONTF_FOLDERS = 32, // for shell browser
        SHCONTF_NONFOLDERS = 64, // for default view
        SHCONTF_INCLUDEHIDDEN = 128, // for hidden/system objects
    }
    [Flags]
    public enum ShellGetDisplayNameOfFlags
    {
        SHGDN_NORMAL = 0, // default (display purpose)
        SHGDN_INFOLDER = 1, // displayed under a folder (relative)
        SHGDN_INCLUDE_NONFILESYS = 0x2000, // if not set, display names for shell name space items that are not in the file system will fail.
        SHGDN_FORADDRESSBAR = 0x4000, // for displaying in the address (drives dropdown) bar
        SHGDN_FORPARSING = 0x8000, // for ParseDisplayName or path
    }
    [Flags]
    public enum STRRETFlags
    {
        STRRET_WSTR = 0x0000, // Use STRRET.pOleStr
        STRRET_OFFSET = 0x0001, // Use STRRET.uOffset to Ansi
        STRRET_CSTR = 0x0002 // Use STRRET.cStr
    }
    [Flags]
    public enum GetAttributeOfFlags : long
    {
        DROPEFFECT_NONE = 0,
        DROPEFFECT_COPY = 1,
        DROPEFFECT_MOVE = 2,
        DROPEFFECT_LINK = 4,
        DROPEFFECT_SCROLL = 0x80000000,
        SFGAO_CANCOPY = DROPEFFECT_COPY, // Objects can be copied
        SFGAO_CANMOVE = DROPEFFECT_MOVE, // Objects can be moved
        SFGAO_CANLINK = DROPEFFECT_LINK, // Objects can be linked
        SFGAO_CANRENAME = 0x00000010, // Objects can be renamed
        SFGAO_CANDELETE = 0x00000020, // Objects can be deleted
        SFGAO_HASPROPSHEET = 0x00000040, // Objects have property sheets
        SFGAO_DROPTARGET = 0x00000100, // Objects are drop target
        SFGAO_CAPABILITYMASK = 0x00000177,
        SFGAO_LINK = 0x00010000, // Shortcut (link)
        SFGAO_SHARE = 0x00020000, // shared
        SFGAO_READONLY = 0x00040000, // read-only
        SFGAO_GHOSTED = 0x00080000, // ghosted icon
        SFGAO_HIDDEN = 0x00080000, // hidden object
        SFGAO_DISPLAYATTRMASK = 0x000F0000,
        SFGAO_FILESYSANCESTOR = 0x10000000, // It contains file system folder
        SFGAO_FOLDER = 0x20000000, // It's a folder.
        SFGAO_FILESYSTEM = 0x40000000, // is a file system thing (file/folder/root)
        SFGAO_HASSUBFOLDER = 0x80000000, // Expandable in the map pane
        SFGAO_CONTENTSMASK = 0x80000000,
        SFGAO_VALIDATE = 0x01000000, // invalidate cached information
        SFGAO_REMOVABLE = 0x02000000, // is this removeable media?
        SFGAO_COMPRESSED = 0x04000000, // Object is compressed (use alt color)
        SFGAO_BROWSABLE = 0x08000000, // is in-place browsable
        SFGAO_NONENUMERATED = 0x00100000, // is a non-enumerated object
        SFGAO_NEWCONTENT = 0x00200000 // should show bold in explorer tree
    }
    public enum QueryContextMenuFlags : long
    {
        CMF_NORMAL = 0x00000000,
        CMF_DEFAULTONLY = 0x00000001,
        CMF_VERBSONLY = 0x00000002,
        CMF_EXPLORE = 0x00000004,
        CMF_NOVERBS = 0x00000008,
        CMF_CANRENAME = 0x00000010,
        CMF_NODEFAULT = 0x00000020,
        CMF_INCLUDESTATIC = 0x00000040,
        CMF_EXTENDEDVERBS = 0x00000100,
        CMF_RESERVED = 0xffff0000
    }

    //
    [ComImport, Guid("000214f4-0000-0000-c000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IContextMenu2
    {
        // Adds commands to a shortcut menu
        [PreserveSig()]
        Int32 QueryContextMenu(
            IntPtr hmenu,
            uint iMenu,
            uint idCmdFirst,
            uint idCmdLast,
            QueryContextMenuFlags uFlags);

        // Carries out the command associated with a shortcut menu item
        [PreserveSig()]
        Int32 InvokeCommand(
            ref CMINVOKECOMMANDINFO info);

        // Retrieves information about a shortcut menu command, 
        // including the help string and the language-independent, 
        // or canonical, name for the command
        [PreserveSig()]
        Int32 GetCommandString(
            uint idcmd,
            int uflags,
            uint reserved,
            string commandstring,
            int cch);

        // Allows client objects of the IContextMenu interface to 
        // handle messages associated with owner-drawn menu items
        [PreserveSig]
        Int32 HandleMenuMsg(
            uint uMsg,
            IntPtr wParam,
            IntPtr lParam);
    }

    public enum WM : uint
    {
        ACTIVATE = 0x6,
        ACTIVATEAPP = 0x1C,
        AFXFIRST = 0x360,
        AFXLAST = 0x37F,
        APP = 0x8000,
        ASKCBFORMATNAME = 0x30C,
        CANCELJOURNAL = 0x4B,
        CANCELMODE = 0x1F,
        CAPTURECHANGED = 0x215,
        CHANGECBCHAIN = 0x30D,
        CHAR = 0x102,
        CHARTOITEM = 0x2F,
        CHILDACTIVATE = 0x22,
        CLEAR = 0x303,
        CLOSE = 0x10,
        COMMAND = 0x111,
        COMPACTING = 0x41,
        COMPAREITEM = 0x39,
        CONTEXTMENU = 0x7B,
        COPY = 0x301,
        COPYDATA = 0x4A,
        CREATE = 0x1,
        CTLCOLORBTN = 0x135,
        CTLCOLORDLG = 0x136,
        CTLCOLOREDIT = 0x133,
        CTLCOLORLISTBOX = 0x134,
        CTLCOLORMSGBOX = 0x132,
        CTLCOLORSCROLLBAR = 0x137,
        CTLCOLORSTATIC = 0x138,
        CUT = 0x300,
        DEADCHAR = 0x103,
        DELETEITEM = 0x2D,
        DESTROY = 0x2,
        DESTROYCLIPBOARD = 0x307,
        DEVICECHANGE = 0x219,
        DEVMODECHANGE = 0x1B,
        DISPLAYCHANGE = 0x7E,
        DRAWCLIPBOARD = 0x308,
        DRAWITEM = 0x2B,
        DROPFILES = 0x233,
        ENABLE = 0xA,
        ENDSESSION = 0x16,
        ENTERIDLE = 0x121,
        ENTERMENULOOP = 0x211,
        ENTERSIZEMOVE = 0x231,
        ERASEBKGND = 0x14,
        EXITMENULOOP = 0x212,
        EXITSIZEMOVE = 0x232,
        FONTCHANGE = 0x1D,
        GETDLGCODE = 0x87,
        GETFONT = 0x31,
        GETHOTKEY = 0x33,
        GETICON = 0x7F,
        GETMINMAXINFO = 0x24,
        GETOBJECT = 0x3D,
        GETSYSMENU = 0x313,
        GETTEXT = 0xD,
        GETTEXTLENGTH = 0xE,
        HANDHELDFIRST = 0x358,
        HANDHELDLAST = 0x35F,
        HELP = 0x53,
        HOTKEY = 0x312,
        HSCROLL = 0x114,
        HSCROLLCLIPBOARD = 0x30E,
        ICONERASEBKGND = 0x27,
        IME_CHAR = 0x286,
        IME_COMPOSITION = 0x10F,
        IME_COMPOSITIONFULL = 0x284,
        IME_CONTROL = 0x283,
        IME_ENDCOMPOSITION = 0x10E,
        IME_KEYDOWN = 0x290,
        IME_KEYLAST = 0x10F,
        IME_KEYUP = 0x291,
        IME_NOTIFY = 0x282,
        IME_REQUEST = 0x288,
        IME_SELECT = 0x285,
        IME_SETCONTEXT = 0x281,
        IME_STARTCOMPOSITION = 0x10D,
        INITDIALOG = 0x110,
        INITMENU = 0x116,
        INITMENUPOPUP = 0x117,
        INPUTLANGCHANGE = 0x51,
        INPUTLANGCHANGEREQUEST = 0x50,
        KEYDOWN = 0x100,
        KEYFIRST = 0x100,
        KEYLAST = 0x108,
        KEYUP = 0x101,
        KILLFOCUS = 0x8,
        LBUTTONDBLCLK = 0x203,
        LBUTTONDOWN = 0x201,
        LBUTTONUP = 0x202,
        LVM_GETEDITCONTROL = 0x1018,
        LVM_SETIMAGELIST = 0x1003,
        MBUTTONDBLCLK = 0x209,
        MBUTTONDOWN = 0x207,
        MBUTTONUP = 0x208,
        MDIACTIVATE = 0x222,
        MDICASCADE = 0x227,
        MDICREATE = 0x220,
        MDIDESTROY = 0x221,
        MDIGETACTIVE = 0x229,
        MDIICONARRANGE = 0x228,
        MDIMAXIMIZE = 0x225,
        MDINEXT = 0x224,
        MDIREFRESHMENU = 0x234,
        MDIRESTORE = 0x223,
        MDISETMENU = 0x230,
        MDITILE = 0x226,
        MEASUREITEM = 0x2C,
        MENUCHAR = 0x120,
        MENUCOMMAND = 0x126,
        MENUDRAG = 0x123,
        MENUGETOBJECT = 0x124,
        MENURBUTTONUP = 0x122,
        MENUSELECT = 0x11F,
        MOUSEACTIVATE = 0x21,
        MOUSEFIRST = 0x200,
        MOUSEHOVER = 0x2A1,
        MOUSELAST = 0x20A,
        MOUSELEAVE = 0x2A3,
        MOUSEMOVE = 0x200,
        MOUSEWHEEL = 0x20A,
        MOVE = 0x3,
        MOVING = 0x216,
        NCACTIVATE = 0x86,
        NCCALCSIZE = 0x83,
        NCCREATE = 0x81,
        NCDESTROY = 0x82,
        NCHITTEST = 0x84,
        NCLBUTTONDBLCLK = 0xA3,
        NCLBUTTONDOWN = 0xA1,
        NCLBUTTONUP = 0xA2,
        NCMBUTTONDBLCLK = 0xA9,
        NCMBUTTONDOWN = 0xA7,
        NCMBUTTONUP = 0xA8,
        NCMOUSEHOVER = 0x2A0,
        NCMOUSELEAVE = 0x2A2,
        NCMOUSEMOVE = 0xA0,
        NCPAINT = 0x85,
        NCRBUTTONDBLCLK = 0xA6,
        NCRBUTTONDOWN = 0xA4,
        NCRBUTTONUP = 0xA5,
        NEXTDLGCTL = 0x28,
        NEXTMENU = 0x213,
        NOTIFY = 0x4E,
        NOTIFYFORMAT = 0x55,
        NULL = 0x0,
        PAINT = 0xF,
        PAINTCLIPBOARD = 0x309,
        PAINTICON = 0x26,
        PALETTECHANGED = 0x311,
        PALETTEISCHANGING = 0x310,
        PARENTNOTIFY = 0x210,
        PASTE = 0x302,
        PENWINFIRST = 0x380,
        PENWINLAST = 0x38F,
        POWER = 0x48,
        PRINT = 0x317,
        PRINTCLIENT = 0x318,
        QUERYDRAGICON = 0x37,
        QUERYENDSESSION = 0x11,
        QUERYNEWPALETTE = 0x30F,
        QUERYOPEN = 0x13,
        QUEUESYNC = 0x23,
        QUIT = 0x12,
        RBUTTONDBLCLK = 0x206,
        RBUTTONDOWN = 0x204,
        RBUTTONUP = 0x205,
        RENDERALLFORMATS = 0x306,
        RENDERFORMAT = 0x305,
        SETCURSOR = 0x20,
        SETFOCUS = 0x7,
        SETFONT = 0x30,
        SETHOTKEY = 0x32,
        SETICON = 0x80,
        SETMARGINS = 0xD3,
        SETREDRAW = 0xB,
        SETTEXT = 0xC,
        SETTINGCHANGE = 0x1A,
        SHOWWINDOW = 0x18,
        SIZE = 0x5,
        SIZECLIPBOARD = 0x30B,
        SIZING = 0x214,
        SPOOLERSTATUS = 0x2A,
        STYLECHANGED = 0x7D,
        STYLECHANGING = 0x7C,
        SYNCPAINT = 0x88,
        SYSCHAR = 0x106,
        SYSCOLORCHANGE = 0x15,
        SYSCOMMAND = 0x112,
        SYSDEADCHAR = 0x107,
        SYSKEYDOWN = 0x104,
        SYSKEYUP = 0x105,
        TCARD = 0x52,
        TIMECHANGE = 0x1E,
        TIMER = 0x113,
        TVM_GETEDITCONTROL = 0x110F,
        TVM_SETIMAGELIST = 0x1109,
        UNDO = 0x304,
        UNINITMENUPOPUP = 0x125,
        USER = 0x400,
        USERCHANGED = 0x54,
        VKEYTOITEM = 0x2E,
        VSCROLL = 0x115,
        VSCROLLCLIPBOARD = 0x30A,
        WINDOWPOSCHANGED = 0x47,
        WINDOWPOSCHANGING = 0x46,
        WININICHANGE = 0x1A,
        SH_NOTIFY = 0x0401
    }

    // Specifies how TrackPopupMenuEx positions the shortcut menu horizontally
    [Flags]
    public enum TPM : uint
    {
        LEFTBUTTON = 0x0000,
        RIGHTBUTTON = 0x0002,
        LEFTALIGN = 0x0000,
        CENTERALIGN = 0x0004,
        RIGHTALIGN = 0x0008,
        TOPALIGN = 0x0000,
        VCENTERALIGN = 0x0010,
        BOTTOMALIGN = 0x0020,
        HORIZONTAL = 0x0000,
        VERTICAL = 0x0040,
        NONOTIFY = 0x0080,
        RETURNCMD = 0x0100,
        RECURSE = 0x0001,
        HORPOSANIMATION = 0x0400,
        HORNEGANIMATION = 0x0800,
        VERPOSANIMATION = 0x1000,
        VERNEGANIMATION = 0x2000,
        NOANIMATION = 0x4000,
        LAYOUTRTL = 0x8000
    }
}