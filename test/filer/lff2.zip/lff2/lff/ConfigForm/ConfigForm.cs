using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace lff.ConfigForm
{
    public partial class ConfigForm : Form
    {
        private Config config = Config.GetInstance();
        private ViewProperty vpbk;
        public ConfigForm()
        {
            InitializeComponent();

            vpbk = config.ViewProperty.Clone() as ViewProperty;

            this.propertyGrid.SelectedObject = vpbk;
            //this.propertyGrid.
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            config.ViewProperty = vpbk.Clone() as ViewProperty;
        }
    }
}