﻿using System.Windows.Forms;

namespace lff.ListViewForm
{
    partial class ListViewPanel
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PathtextBox = new System.Windows.Forms.TextBox();
            this.Basepanel = new System.Windows.Forms.Panel();
            this.ListViewstatusStrip = new System.Windows.Forms.StatusStrip();
            this.ListViewStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.ListViewcontextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.OpenNewTabtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TabcontextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CloseTabtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DirectoryListcontextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TabBasePanel = new System.Windows.Forms.Panel();
            this.ListViewstatusStrip.SuspendLayout();
            this.ListViewcontextMenuStrip.SuspendLayout();
            this.TabcontextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // PathtextBox
            // 
            this.PathtextBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.PathtextBox.Location = new System.Drawing.Point(0, 22);
            this.PathtextBox.Name = "PathtextBox";
            this.PathtextBox.Size = new System.Drawing.Size(294, 19);
            this.PathtextBox.TabIndex = 0;
            // 
            // Basepanel
            // 
            this.Basepanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Basepanel.Location = new System.Drawing.Point(0, 41);
            this.Basepanel.Name = "Basepanel";
            this.Basepanel.Size = new System.Drawing.Size(294, 213);
            this.Basepanel.TabIndex = 2;
            // 
            // ListViewstatusStrip
            // 
            this.ListViewstatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ListViewStatusLabel});
            this.ListViewstatusStrip.Location = new System.Drawing.Point(0, 254);
            this.ListViewstatusStrip.Name = "ListViewstatusStrip";
            this.ListViewstatusStrip.Size = new System.Drawing.Size(294, 22);
            this.ListViewstatusStrip.TabIndex = 0;
            this.ListViewstatusStrip.Text = "statusStrip1";
            // 
            // ListViewStatusLabel
            // 
            this.ListViewStatusLabel.Name = "ListViewStatusLabel";
            this.ListViewStatusLabel.Size = new System.Drawing.Size(279, 17);
            this.ListViewStatusLabel.Spring = true;
            this.ListViewStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ListViewcontextMenuStrip
            // 
            this.ListViewcontextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenNewTabtoolStripMenuItem});
            this.ListViewcontextMenuStrip.Name = "ListViewcontextMenuStrip";
            this.ListViewcontextMenuStrip.Size = new System.Drawing.Size(138, 26);
            this.ListViewcontextMenuStrip.Click += new System.EventHandler(this.listviewtoolStripMenuItem_Click);
            // 
            // OpenNewTabtoolStripMenuItem
            // 
            this.OpenNewTabtoolStripMenuItem.Name = "OpenNewTabtoolStripMenuItem";
            this.OpenNewTabtoolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.OpenNewTabtoolStripMenuItem.Text = "OpenNewTab";
            this.OpenNewTabtoolStripMenuItem.Click += new System.EventHandler(this.listviewtoolStripMenuItem_Click);
            // 
            // TabcontextMenuStrip
            // 
            this.TabcontextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CloseTabtoolStripMenuItem});
            this.TabcontextMenuStrip.Name = "TabcontextMenuStrip";
            this.TabcontextMenuStrip.Size = new System.Drawing.Size(100, 26);
            // 
            // CloseTabtoolStripMenuItem
            // 
            this.CloseTabtoolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.CloseTabtoolStripMenuItem.Name = "CloseTabtoolStripMenuItem";
            this.CloseTabtoolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.CloseTabtoolStripMenuItem.Text = "Close";
            this.CloseTabtoolStripMenuItem.Click += new System.EventHandler(this.listviewtoolStripMenuItem_Click);
            // 
            // DirectoryListcontextMenuStrip
            // 
            this.DirectoryListcontextMenuStrip.Name = "DirectoryListcontextMenuStrip";
            this.DirectoryListcontextMenuStrip.Size = new System.Drawing.Size(61, 4);
            // 
            // TabBasePanel
            // 
            this.TabBasePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TabBasePanel.Location = new System.Drawing.Point(0, 0);
            this.TabBasePanel.Name = "TabBasePanel";
            this.TabBasePanel.Size = new System.Drawing.Size(294, 22);
            this.TabBasePanel.TabIndex = 0;
            // 
            // ListViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 276);
            this.Controls.Add(this.Basepanel);
            this.Controls.Add(this.ListViewstatusStrip);
            this.Controls.Add(this.PathtextBox);
            this.Controls.Add(this.TabBasePanel);
            this.DoubleBuffered = true;
            this.Name = "ListViewForm";
            this.TabText = "ListViewForm";
            this.Text = "ListViewForm";
            this.ListViewstatusStrip.ResumeLayout(false);
            this.ListViewstatusStrip.PerformLayout();
            this.ListViewcontextMenuStrip.ResumeLayout(false);
            this.TabcontextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PathtextBox;
        private Panel Basepanel;
        private ContextMenuStrip ListViewcontextMenuStrip;
        private ToolStripMenuItem OpenNewTabtoolStripMenuItem;
        private StatusStrip ListViewstatusStrip;
        private ToolStripStatusLabel ListViewStatusLabel;
        private ContextMenuStrip TabcontextMenuStrip;
        private ToolStripMenuItem CloseTabtoolStripMenuItem;
        internal ContextMenuStrip DirectoryListcontextMenuStrip;
        private Panel TabBasePanel;

    }
}