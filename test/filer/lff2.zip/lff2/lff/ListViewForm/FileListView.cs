using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace lff.ListViewForm
{
    public delegate void ChangeDirectoryEventhandler(object sender, string path);
    
    public partial class FileListView : ListView
    {
        private List<string> FilenameList = new List<string>();
        private Dictionary<string, FileData> FileDataList = new Dictionary<string, FileData>();
        private BackgroundWorker worker = new BackgroundWorker();
        private string _path;
        private IconCache iconcache;
        private CutedListViewItem cutedlistviewitem;
        private uint MouseClikInterval = (uint)SystemInformation.DoubleClickTime;
        private uint MouseClikTime;
        private int MouseClikCount = 0;
        public event MouseEventHandler DoubleClickEx = null;
        public event ChangeDirectoryEventhandler ChangeDirectory = null;
        
        private FileSystemWatcher watcher = new FileSystemWatcher();
        public List<string> FileOperatedFilenameList = new List<string>();

        private ColumnHeader columnName;
        private ColumnHeader columnType;
        private ColumnHeader columnSize;
        private ColumnHeader columnLastWriteTime;

        private ListViewItemSortType _currentsorttype;
        private Config config = Config.GetInstance();

        public FileListView()
        {
            InitializeComponent();

            this.DoubleBuffered = true;
            //this.FullRowSelect = true;
            this.HideSelection = false;
            this.AllowDrop = true;

            this.MouseDown += new MouseEventHandler(FileListView_MouseDown);
            this.ColumnClick += new ColumnClickEventHandler(FileListView_ColumnClick);
            this.DragDrop += new DragEventHandler(FileListView_DragDrop);
            this.DragOver += new DragEventHandler(FileListView_DragOver);
            this.DragEnter += new DragEventHandler(FileListView_DragEnter);
            this.ItemDrag += new ItemDragEventHandler(FileListView_ItemDrag);
            this.View = View.List;

            watcher.NotifyFilter = NotifyFilters.DirectoryName | NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Attributes;
            watcher.IncludeSubdirectories = false;
            watcher.SynchronizingObject = this;
            watcher.Created += new FileSystemEventHandler(watcher_Created);
            watcher.Deleted += new FileSystemEventHandler(watcher_Deleted);
            watcher.Renamed += new RenamedEventHandler(watcher_Renamed);
            watcher.Changed += new FileSystemEventHandler(watcher_Changed);

            worker.WorkerSupportsCancellation = true;
            worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);

            iconcache = IconCache.GetInstance();
            this.SmallImageList = iconcache.ImageList;
            cutedlistviewitem = CutedListViewItem.GetInstance();

            MouseClikTime = Win32API.GetTickCount();
            
            this.InitFileSystemEventCheck();

            this.fileoperatioinit();
        }

        void FileListView_ItemDrag(object sender, ItemDragEventArgs e)
        {
            DataObject dataObj = new DataObject(DataFormats.FileDrop, this.SelectedFileFullPath);
            DragDropEffects effect = DragDropEffects.Copy | DragDropEffects.Move | DragDropEffects.Link;
            ((ListView)sender).DoDragDrop(dataObj, effect);
        }

        void FileListView_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        void FileListView_DragOver(object sender, DragEventArgs e)
        {
            
        }

        void FileListView_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop, false);
        }

        void FileListView_ColumnClick(object sender, ColumnClickEventArgs e)
        {

        }

        public string CurrentPath
        {
            get { return this._path; }
        }

        public string[] SelectedFilenames
        {
            get
            {
                string[] files = new string[this.SelectedItems.Count];
                for (int i = 0; i < this.SelectedItems.Count; i++)
                    files[i] = this.SelectedItems[i].Text;

                return files;
            }
        }

        public string[] SelectedFileFullPath
        {
            get
            {
                string[] files = new string[this.SelectedItems.Count];
                for (int i = 0; i < this.SelectedItems.Count; i++)
                    files[i] = Path.Combine(this._path, this.SelectedItems[i].Text);

                return files;
            }
        }

        public new View View
        {
            get { return base.View; }
            set
            {
                base.View = value;
                if (base.View == View.Details)
                {
                    if (this.Columns.Count == 0)
                    {
                        // ��i�R�����j�w�b�_�̍쐬
                        columnName = new ColumnHeader();
                        columnType = new ColumnHeader();
                        columnSize = new ColumnHeader();
                        columnLastWriteTime = new ColumnHeader();
                        columnName.Text = "���O";
                        columnName.Width = 100;
                        columnSize.Text = "�T�C�Y";
                        columnSize.Width = 100;
                        columnType.Text = "���";
                        columnType.Width = 50;
                        columnLastWriteTime.Text = "�X�V����";
                        columnLastWriteTime.Width = 150;
                        ColumnHeader[] colHeaderRegValue = 
                            { this.columnName, this.columnSize, this.columnType, columnLastWriteTime };
                        this.Columns.AddRange(colHeaderRegValue);
                    }

                    if (this.Items[0].SubItems.Count != 1)
                    {
                        if(this.Items[0].SubItems.Count != 4)
                        {
                            foreach (ListViewItem item in this.Items)
                            {
                                FileData fdata = FileDataList[item.Text];
                                item.SubItems[1].Text = Utility.ConvertToBKMG(fdata.size);
                                item.SubItems[2].Text = fdata.ext;
                                item.SubItems[3].Text = fdata._lastwritetimeTostr;
                            }
                        }
                    }
                    else
                    {
                        foreach (ListViewItem item in this.Items)
                        {
                            FileData fdata = FileDataList[item.Text];
                            string[] subitems = { Utility.ConvertToBKMG(fdata.size), fdata.ext, fdata._lastwritetimeTostr };
                            item.SubItems.AddRange(subitems);
                        }
                    }
                }
            }
        }

        private Point premousepos;
        void FileListView_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (Win32API.GetTickCount() - MouseClikTime < MouseClikInterval)
                {
                    MouseClikCount++;
                    if (MouseClikCount == 2
                        && premousepos.X == e.X
                        && premousepos.Y == e.Y)
                    {
                        MouseClikCount = 0;
                        if (DoubleClickEx != null)
                            DoubleClickEx(sender, e);
                    }
                }
                else
                {
                    MouseClikCount = 0;
                    MouseClikCount++;
                }
                premousepos = e.Location;
                MouseClikTime = Win32API.GetTickCount();
            }
        }

        void watcher_Changed(object sender, FileSystemEventArgs e)
        {
            Utility.debug("watcher_Changed " + e.Name);
            if (!FileSystemChangedEventList.Contains(e.Name))
            {
                //FileSystemChangedEventList.Add(e.Name);
            }
            //this.InterruptFileSystemEvent();
        }

        void watcher_Renamed(object sender, RenamedEventArgs e)
        {
            Utility.debug("watcher_Renamed " + e.OldName + " TO " + e.Name);
            if (this.ContainsFileOperatedFilename(e.OldName))
            {
                //int index = this.FilenameList.IndexOf(e.OldName);
                //this.FilenameList[index] = e.Name;
            }
            else
            {
                this.InterruptFileSystemEvent();
                FileSystemEventQueue.Enqueue(e);
            }
            this.FileDataList.Remove(e.OldName);
            this.FileDataList.Add(e.Name, new FileData(e.FullPath));
        }

        void watcher_Deleted(object sender, FileSystemEventArgs e)
        {
            Utility.debug("watcher_Deleted " + e.Name);
            if (this.ContainsFileOperatedFilename(e.Name))
            {
                //this.FilenameList.Remove(e.Name);
                //this.Items.RemoveByKey(e.Name);
            }
            else
            {
                this.InterruptFileSystemEvent();
                FileSystemEventQueue.Enqueue(e);
            }
            this.FileDataList.Remove(e.Name);
        }

        void watcher_Created(object sender, FileSystemEventArgs e)
        {
            Utility.debug("watcher_Created " + e.Name);
            if (this.ContainsFileOperatedFilename(e.Name))
            {
                //this.FilenameList.Remove(e.Name);
            }
            else
            {
                this.InterruptFileSystemEvent();
                FileSystemEventQueue.Enqueue(e);
            }
            this.FileDataList.Add(e.Name, new FileData(Path.Combine(this._path, e.Name)));
        }

        private Boolean ContainsFileOperatedFilename(string name)
        {
            if (FileOperatedFilenameList.Contains(name))
            {
                FileOperatedFilenameList.Remove(name);
                return true;
            }
            return false;
        }


        public FileData GetFileDataByIndex(int index)
        {
            if (FileDataList.ContainsKey(this.Items[index].Text))
                return FileDataList[this.Items[index].Text];
            else
                return null;
        }

        public FileData GetFileDataByIndex(string fname)
        {
            if (FileDataList.ContainsKey(fname))
                return FileDataList[fname];
            else
                return null;
        }

        public void ReadDirectory(string path)
        {
            this.ReadDirectory(path, this._currentsorttype);
        }

        public void ReadDirectory(string path, ListViewItemSortType sorttype)
        {
            if (ChangeDirectory != null)
                ChangeDirectory(this, path);

            watcher.EnableRaisingEvents = false;
            this._path = path;
            watcher.Path = this._path;
            if (worker.IsBusy)
            {
                worker.CancelAsync();
                while (worker.IsBusy)
                {
                    System.Threading.Thread.Sleep(100);
                    Application.DoEvents();
                }
            }

            FileDataList.Clear();
            FilenameList.Clear();
            this.Items.Clear();

            worker.RunWorkerAsync(new Object[] { path, sorttype });
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //this.BeginUpdate();

            //for (int i = 0; i < FileDataList.Count; i++)
            //{
            //    FileData fdata = FileDataList[FilenameList[i]];
            //    ListViewItem litem = new ListViewItem(FilenameList[i]);
            //    litem.Name = FilenameList[i];
            //    litem.ImageIndex = this.iconcache.GetNormalIcon(Path.Combine(_path, litem.Text), fdata.IsDirectory);
            //    this.Items.Add(litem);
            //}

            //if (this.View == View.Details)
            //    this.View = View.Details;


            //this.EndUpdate();
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            string path = ((Object[])e.Argument)[0] as string;
            ListViewItemSortType sorttype = (ListViewItemSortType)((Object[])e.Argument)[1];

            BackgroundWorker bworker = sender as BackgroundWorker;
            if (bworker.CancellationPending)
            {
                e.Cancel = true;
                return;
            }

            foreach (string fullpath in Directory.GetDirectories(_path))
            {
                if (bworker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }
                FileData filedata = new FileData(fullpath);
                FileDataList.Add(filedata.name, filedata);
                FilenameList.Add(filedata.name);
            }
            foreach (string fullpath in Directory.GetFiles(_path))
            {
                if (bworker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }
                FileData filedata = new FileData(fullpath);
                FileDataList.Add(filedata.name, filedata);
                FilenameList.Add(filedata.name);
            }

            Invoke((MethodInvoker)delegate()
            {
                this.BeginUpdate();

                for (int i = 0; i < FileDataList.Count; i++)
                {
                    FileData fdata = FileDataList[FilenameList[i]];
                    ListViewItem litem = new ListViewItem(FilenameList[i]);
                    litem.Name = FilenameList[i];
                    litem.ImageIndex = this.iconcache.GetNormalIcon(Path.Combine(_path, litem.Text), fdata.IsDirectory);
                    this.Items.Add(litem);
                }

                if (this.View == View.Details)
                    this.View = View.Details;

                if(sorttype != ListViewItemSortType.Name)
                    this.ListViewSort(sorttype);

                this.EndUpdate();
            });

            watcher.EnableRaisingEvents = true;
        }

        public void ListViewSort(ListViewItemSortType sorttype)
        {
            switch (sorttype)
            {
                case ListViewItemSortType.Name:
                    this.ListViewItemSorter = new ListViewItemNameComparer(this.FileDataList, false);
                    break;
                case ListViewItemSortType.Name_R:
                    this.ListViewItemSorter = new ListViewItemNameComparer(this.FileDataList, true);
                    break;
                case ListViewItemSortType.Size:
                    this.ListViewItemSorter = new ListViewItemSizeComparer(this.FileDataList, false);
                    break;
                case ListViewItemSortType.Size_R:
                    this.ListViewItemSorter = new ListViewItemSizeComparer(this.FileDataList, true);
                    break;
                default:
                    break;
            }
            this._currentsorttype = sorttype;
            this.ListViewItemSorter = null;
        }

        public void FileMask(string mask)
        {
            
            this.BeginUpdate();
            this.Items.Clear();
            foreach(FileData fdata in FileDataList.Values)
            {
                if (Win32API.PathMatchSpec(fdata.name, mask))
                {
                    ListViewItem item = new ListViewItem(fdata.name);
                    item.Name = fdata.name;
                    item.ImageIndex = this.iconcache.GetNormalIcon(fdata.fullpath, fdata.IsDirectory);
                    this.Items.Add(item);
                }
            }
            this.ListViewSort(this._currentsorttype);
            this.EndUpdate();
        }

        private KeyMap _keymap = KeyMap.GetInstance();
        string incstrbuffer = string.Empty;
        string incstrnextbuffer = string.Empty;
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            //return base.ProcessCmdKey(ref msg, keyData);
            //bool ret = base.ProcessCmdKey(ref msg, keyData);
            //if (!ret)
            //{
            //    System.Diagnostics.Debug.WriteLine("!ProcessCmdKey");
            //}

            switch (keyData)
            {
                case Keys.ShiftKey | Keys.Shift:
                case Keys.ControlKey | Keys.Control:
                    return base.ProcessCmdKey(ref msg, keyData);
                default:
                    break;
            }

            string s = _keymap.GetKeyMap(keyData);
            if(s != string.Empty)
            {
                incstrnextbuffer = string.Empty;
                incstrbuffer += s;
                this.IncSelectItem(incstrbuffer, new Predicate(IsOver10));
            }
            else
            {
                if(incstrnextbuffer == string.Empty)
                    incstrnextbuffer = incstrbuffer;
                incstrbuffer = string.Empty;
                return base.ProcessCmdKey(ref msg, keyData);
            }       

            return true;
        }

        delegate bool Predicate(string pat, ListViewItem n);
        private bool IsOver10(string pat, ListViewItem n) 
        {
            Regex reg = new Regex(pat, RegexOptions.IgnoreCase);
            return reg.IsMatch(n.Text, 0); 
        }
        private void IncSelectItem(string pat, Predicate pred)
        {
            int n = this.SelectedIndices.Count == 0 ? 0 : this.SelectedIndices[0];
            this.SelectedItems.Clear();
            for (int i = n; i < this.Items.Count; i++)
            {
                if (pred(pat, this.Items[i]))
                {
                    this.Items[i].Selected = true;
                    this.Items[i].Focused = true;
                    this.EnsureVisible(i);
                    return;
                }
            }
        }
        public void IncSelectNextItem()
        {
            if(this.SelectedIndices.Count == 0) return;

            int index = 0;
            if (this.SelectedIndices[0] != this.Items.Count-1)
            {
                index = this.SelectedIndices[0] + 1;
            }
            this.SelectedItems.Clear();
            ListViewItem item = this.Items[index];
            item.Selected = true;
            this.IncSelectItem(incstrnextbuffer, new Predicate(IsOver10));
        }

    }
}
