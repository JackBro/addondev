using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace lff.ListViewForm
{
    public delegate void ContextMenuStripPopupEventHander(object sender, Point e);
    public partial class ListViewPanel : Panel
    {
        private const uint CMD_COPY = 26;
        private const uint CMD_PASTE = 27;
        private const uint CMD_DELETE = 18;

        private Shell.ShellContextMenu shellcontextmenu = new lff.Shell.ShellContextMenu();
        private System.Timers.Timer infotimer;

        public event ContextMenuStripPopupEventHander ContextMenuStripPopup = null;
        public ListViewPanel()
        {
            InitializeComponent();

            //PathtextBox
            PathtextBox.TabIndex = 2;
            PathtextBox.KeyDown += new KeyEventHandler(PathtextBox_KeyDown);

            shellcontextmenu.ContextMenuClik += new lff.Shell.ContextMenuClikEventHandler(ShellContextMenu_ContextMenuClik);

            infotimer = new System.Timers.Timer();
            infotimer.Interval = 200;
            infotimer.Elapsed += new System.Timers.ElapsedEventHandler(infotimer_Elapsed);
        }

        private void UpDateStatusInfo()
        {
            if (ActiveListView.SelectedItems.Count == 0)
            {
                ListViewStatusLabel.Text = ActiveListView.Items.Count.ToString();
            }
            else
            {
                long fsize = 0;
                foreach (int i in ActiveListView.SelectedIndices)
                {
                    FileData filedata = ActiveListView.GetFileDataByIndex(i);
                    if (filedata != null)
                    {
                        fsize += filedata.size;
                    }
                }
                ListViewStatusLabel.Text = Utility.ConvertToBKMG(fsize);
            }
        }

        void infotimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            Invoke((MethodInvoker)delegate()
            {
                this.UpDateStatusInfo();
            });
            infotimer.Stop();
        } 

        void ShellContextMenu_ContextMenuClik(object sender, lff.Shell.ContextMenuClikEventArgs e)
        {
            FileListView listview = sender as FileListView;
            switch (e.cmdid)
            {
                case (uint)Shell.CMDID.CMD_CUT:
                    listview.CutToClipBoard();
                    break;
                case (uint)Shell.CMDID.CMD_COPY:
                    listview.CopyToClipBoard();
                    break;
                case (uint)Shell.CMDID.CMD_PASTE:
                    if (ClipBoardUtility.GetClipBoardState() == ClipBoardState.Copy)
                        listview.Copy(ClipBoardUtility.GetFromClipboard(), listview.CurrentPath);
                    else if (ClipBoardUtility.GetClipBoardState() == ClipBoardState.Cut)
                        listview.MoveCopy(ClipBoardUtility.GetFromClipboard(), listview.CurrentPath);
                    break;
                case (uint)Shell.CMDID.CMD_DELETE:
                    string path = Path.GetDirectoryName(e.files[0]);
                    if (listview.CurrentPath == path)
                    {
                        listview.Delete(e.files);
                    }
                    break;
                case (uint)Shell.CMDID.CMD_RENAME:
                    break;

                default:
                    break;
            }
        }

        void PathtextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                if (PathtextBox.Text != string.Empty
                    && Directory.Exists(PathtextBox.Text))
                {
                    TabPage tb = this.tabControl.SelectedTab;
                    FileListView listview = TabListViewDic[tb];
                    listview.ReadDirectory(PathtextBox.Text);
                }
            }                
        }

        public ListViewItem GetListViewItemByPos(Point p)
        {
            TabPage tb = this.tabControl.SelectedTab;
            FileListView listview = TabListViewDic[tb];
            if (listview.HitTest(p).Location == ListViewHitTestLocations.Label
                || listview.HitTest(p).Location == ListViewHitTestLocations.Image)
            {
                return listview.HitTest(p).Item;
            }

            return null;
        }

        public void UpDirectory(FileListView listview)
        {
            string path = Path.GetDirectoryName(listview.CurrentPath);
            if (listview.CurrentPath == Path.GetPathRoot(path))
            {
            }
            else
            {
                listview.ReadDirectory(path);
            }

        }
        public void OpenNewTab()
        {
            foreach (string path in this.ActiveListView.SelectedFileFullPath)
            {
                if (Directory.Exists(path))
                {
                    this.OpenNewTab(path);
                }
            }
        }

        void listview_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            infotimer.Start();
        }

        void listview_SelectedRangeChanged(object sender, EventArgs e)
        {
            FileListView listview = sender as FileListView;
            long fsize = 0;
            foreach (int i in listview.SelectedIndices)
            {
                FileData filedata = listview.GetFileDataByIndex(i);
                if (filedata != null)
                {
                    fsize += filedata.size;
                    ListViewStatusLabel.Text = Utility.ConvertToBKMG(fsize);
                }
            }
        }

        void listview_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                FileListView listview = sender as FileListView;
                Point pt = new Point(e.X, e.Y);
                pt = listview.PointToScreen(pt);

                string[] files = listview.SelectedFileFullPath;
                if (files.Length == 0)
                {
                    files = new string[1];
                    files[0] = listview.CurrentPath;
                    shellcontextmenu.CreateFolderMenu(listview, listview.CurrentPath, pt);
                }
                else
                {
                    shellcontextmenu.ShowContextMenu(listview, files, pt.X, pt.Y, true);
                }
            }
            else if (e.Button == MouseButtons.Middle)
            {
                FileListView listview = sender as FileListView;
                ListViewItem item = listview.GetItemAt(e.X, e.Y);
                if (item == null)
                {
                    if (ContextMenuStripPopup != null)
                    {
                        ContextMenuStripPopup(DirectoryListcontextMenuStrip, e.Location);
                    }

                    DirectoryListcontextMenuStrip.Show(listview.PointToScreen(e.Location));
                }
                else
                {
                    item.Selected = true;
                    string path = Path.Combine(listview.CurrentPath, item.Text);
                    if (Directory.Exists(path))
                    {
                        this.OpenNewTab(path);
                    }
                }
            }
        }

        void listview_DoubleClickEx(object sender, MouseEventArgs e)
        {
            FileListView listview = sender as FileListView;
            if (listview.SelectedIndices.Count > 0)
            {
                ListViewItem item = listview.Items[listview.SelectedIndices[0]];
                string path = Path.Combine(listview.CurrentPath, item.Text);
                if (Directory.Exists(path))
                {
                    listview.ReadDirectory(path);
                }
                else if (File.Exists(path))
                {
                    listview.Open(path);
                }
            }
            else
            {
                this.UpDirectory(listview);
            }
        }

        private TabPage GetTabPageByFileListView(FileListView listview)
        {
            foreach (TabPage tb in TabListViewDic.Keys)
            {
                if (TabListViewDic[tb] == listview)
                {
                    return tb;
                }
            }

            return null;
        }

        void listview_ChangeDirectory(object sender, string path)
        {
            FileListView listview = sender as FileListView;
            TabPage tb = GetTabPageByFileListView(listview);
            if (tb != null)
            {
                tb.Text = Path.GetFileName(path);

                if (tb == this.tabControl.SelectedTab)
                    PathtextBox.Text = path;
            }
        }

        void listviewtoolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender == OpenNewTabtoolStripMenuItem)
            {
                ListViewItem item = ActiveListView.Items[ActiveListView.SelectedIndices[0]];
                if (item != null)
                {
                    string path = Path.Combine(ActiveListView.CurrentPath, item.Text);
                    this.OpenNewTab(path);

                }
            }
            else if (sender == CloseTabtoolStripMenuItem)
            {
                ToolStripMenuItem menuitem = sender as ToolStripMenuItem;
                Point p = this.tabControl.PointToClient(menuitem.Owner.Location);
                TabPage tb = this.tabControl.GetTabPageByPoint(p);
                if (tb != null)
                {
                    FileListView listview = TabListViewDic[tb];
                    this.Basepanel.Controls.Remove(listview);
                    tabControl.TabPages.Remove(tb);
                }
            }
        }

        public FileListView ActiveListView
        {
            get 
            {
                TabPage tb = this.tabControl.SelectedTab;
                return TabListViewDic[tb];
             }
        }

        public void SetActive(string path)
        {
            foreach (TabPage tb in TabListViewDic.Keys)
            {
                if (TabListViewDic[tb].CurrentPath == path)
                {
                    tabControl.SelectedTab = tb;
                }
            }
        }

        public void ChangeView(View view)
        {
            ActiveListView.View = view;
        }

        public void MoveItemToLast()
        {
            ActiveListView.BeginUpdate();
            foreach (ListViewItem item in ActiveListView.SelectedItems)
            {
                ActiveListView.Items.Remove(item);
                ActiveListView.Items.Add(item);
            }
            ActiveListView.EndUpdate();
        }
    }
}
