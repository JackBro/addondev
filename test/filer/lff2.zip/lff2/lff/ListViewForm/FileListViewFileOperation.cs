using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.ComponentModel;

namespace lff.ListViewForm
{
    public partial class FileListView : ListView
    {
        private BackgroundWorker fileoperationworker = new BackgroundWorker(); 

        private void fileoperatioinit()
        {
            fileoperationworker.DoWork += new DoWorkEventHandler(fileoperationworker_DoWork);
            fileoperationworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(fileoperationworker_RunWorkerCompleted);
        }

        private void cancelfileoperationworker()
        {
            this.FileOperatedFilenameList.Clear();
        }

        void fileoperationworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.SelectedItems.Clear();
            this.BeginUpdate();
            FileOperationArgs fargs = e.Result as FileOperationArgs;
            if (fargs.FileOperationType == Win32API.FOFunc.FO_DELETE)
            {
                foreach (string fname in fargs.fromfiles)
                {
                    if (!FileOperatedFilenameList.Contains(fname))
                        this.Items.RemoveByKey(fname);
                }
            }
            else if (fargs.FileOperationType == Win32API.FOFunc.FO_COPY)
            {
                foreach (string fname in FileOperatedFilenameList)
                {
                    if (!FileOperatedFilenameList.Contains(fname))
                    {
                        ListViewItem item = new ListViewItem(fname);
                        item.Name = fname;
                        string fullpath = Path.Combine(this._path, fname);
                        item.ImageIndex = this.iconcache.GetNormalIcon(Path.Combine(this._path, fname), Directory.Exists(fullpath));
                        this.Items.Add(item);
                    }
                }
            }
            this.EndUpdate();
            this.FileOperatedFilenameList.Clear();
        }

        void fileoperationworker_DoWork(object sender, DoWorkEventArgs e)
        {
            FileOperationArgs fargs = e.Argument as FileOperationArgs;
            switch (fargs.FileOperationType)
            {
                case Win32API.FOFunc.FO_COPY:
                    FileOperation.Copy(fargs.Handle, fargs.fromfiles, fargs.topath);
                    break;
                case Win32API.FOFunc.FO_MOVE:
                    break;
                case Win32API.FOFunc.FO_DELETE:
                    FileOperation.Delete(fargs.Handle, fargs.fromfiles);
                    break;
                default:
                    break;
            }

            e.Result = fargs;
        }

        public void Open(string file)
        {
            string path  = config.ViewProperty.GetAssociateApp(Path.GetExtension(file));
            if (path != string.Empty)
            {
                FileOperation.Exec(this.Handle, path, file);
            }
            else
            {
                FileOperation.Exec(this.Handle, file);
            }
        }

        public void Delete(string[] files)
        {
            if (fileoperationworker.IsBusy)
            {

                return;
            }

            foreach (string path in files)
            {
                this.FileOperatedFilenameList.Add(Path.GetFileName(path));
            }

            FileOperationArgs fargs = new FileOperationArgs();
            fargs.Handle = this.Handle;
            fargs.FileOperationType = Win32API.FOFunc.FO_DELETE;
            fargs.fromfiles = files;
            fileoperationworker.RunWorkerAsync(fargs);
        }

        public void Copy(string[] files, string topath)
        {
            if (fileoperationworker.IsBusy)
            {
                return;
            }

            foreach (string path in files)
            {
                this.FileOperatedFilenameList.Add(Path.GetFileName(path));
            }

            FileOperationArgs fargs = new FileOperationArgs();
            fargs.Handle = this.Handle;
            fargs.FileOperationType = Win32API.FOFunc.FO_COPY;
            fargs.fromfiles = files;
            fargs.topath = topath;
            fileoperationworker.RunWorkerAsync(fargs);
        }
        public void MoveCopy(string[] files, string topath)
        {
            if (fileoperationworker.IsBusy)
            {

                return;
            }

            foreach (string path in files)
            {
                this.FileOperatedFilenameList.Add(Path.GetFileName(path));
            }

            FileOperationArgs fargs = new FileOperationArgs();
            fargs.Handle = this.Handle;
            fargs.FileOperationType = Win32API.FOFunc.FO_MOVE;
            fargs.fromfiles = files;
            fargs.topath = topath;
            fileoperationworker.RunWorkerAsync(fargs);
        }

        public void CutToClipBoard()
        {
            ClipBoardUtility.CopyToClipboard(this.SelectedFileFullPath, true);
            cutedlistviewitem.Set(this.CurrentPath, this.SelectedItems);
        }

        public void CopyToClipBoard()
        {
            ClipBoardUtility.CopyToClipboard(this.SelectedFileFullPath, false);
            cutedlistviewitem.Reset();
        }
    }
}