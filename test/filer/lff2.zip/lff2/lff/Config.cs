using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using System.Windows.Forms.Design;
using System.Drawing.Design;
using System.IO;
using System.Xml.Serialization;
using lff.ListViewForm;

namespace lff
{
    class Config
    {
        private static Config config = null;
        private ViewProperty _ViewProperty = new ViewProperty();

        private string _configdirectory = string.Empty;
        private const string sesstionxml = "sesstion.xml";
        private string _sesstionxml;

        private Config()
        {
            //_configdirectory = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), Environment.UserName);
            //if (!Directory.Exists(_configdirectory))
            //{
            //    Directory.CreateDirectory(_configdirectory);
            //}

            //_sesstionxml = Path.Combine(_configdirectory, sesstionxml);
        }

        public static Config GetInstance()
        {
            if (config == null)
            {
                config = new Config();
            }
            
            return config;
        }

        public string ConfigDirectory
        {
            get { return this._configdirectory; }
            set 
            { 
                this._configdirectory = value;
                _sesstionxml = Path.Combine(_configdirectory, sesstionxml);
            }
        }

        public string SesstionXML
        {
            get { return this._sesstionxml; }
        }

        public ViewProperty ViewProperty
        {
            get { return this._ViewProperty;}
            set { this._ViewProperty = value; }
        }
    }


    enum FileView
    {
        Details = 1,
        List = 3,
    }

    class PropertyBase : ICloneable
    {

        #region ICloneable �����o

        public object Clone()
        {
            return this.MakeCloneObject();
        }

        #endregion

        public virtual object MakeCloneObject()
        {
            return this.MemberwiseClone();
        }
    }

    class Attitem
    {
        //private string _name;
        private string _exts;
        private string _apppath;

        public string Exts
        {
            get { return this._exts; }
            set { this._exts = value; }
        }

        [Editor(typeof(FileNameEditor), typeof(UITypeEditor))]
        public string AppPath
        {
            get { return this._apppath; }
            set { this._apppath = value; }
        }
    }

    class ViewProperty : PropertyBase
    {
        private FileView _View;
        private List<Attitem> _Collection = new List<Attitem>();
        private Dictionary<string, string> AssociateDic = new Dictionary<string, string>(); 

        [Description("View")]
        public FileView View
        {
            get { return this._View; }
            set { this._View = value; }
        }


        [Description("Items")]
        public List<Attitem> Collection
        {
            get { return _Collection; }
            set 
            { 
                this._Collection = value;
                AssociateDic.Clear();
                foreach (Attitem item in this._Collection)
                {
                    string[] exts = item.Exts.Split(new string[]{ ";"}, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string ext in exts)
                    {
                        if (!AssociateDic.ContainsKey(ext))
                        {
                            AssociateDic.Add(ext, item.AppPath);
                        }
                    }
                }
            }
        }

        public string GetAssociateApp(string ext)
        {
            if (AssociateDic.ContainsKey(ext))
                return AssociateDic[ext];
            else
                return string.Empty;
        }

        public override object MakeCloneObject()
        {
            ViewProperty obj = (ViewProperty)this.MemberwiseClone();
            List<Attitem> cCollection = new List<Attitem>();
            foreach(Attitem item in obj._Collection )
            {
                Attitem citem =new Attitem();
                citem.Exts = item.Exts;
                citem.AppPath = item.AppPath;
                cCollection.Add(citem);
            }
            obj.Collection = cCollection;
            return obj;
        }
    }

    //class KeyProperty
    //{
    //    private Dictionary<>
    //}

    public class MouseProperty
    {

    }

    public class PropertyBase<T>
    {
        public void save(string filename, Object obj)
        {
            XmlSerializer serializer1 = new XmlSerializer(typeof(T));
            FileStream fs1 = new FileStream(filename, FileMode.Create);
            serializer1.Serialize(fs1, obj);
            fs1.Close();
        }

        public T load(string filename)
        {
            XmlSerializer serializer2 = new XmlSerializer(typeof(T));
            FileStream fs2 = new FileStream(filename, FileMode.Open);
            T loadClasses;
            loadClasses = (T)serializer2.Deserialize(fs2);
            fs2.Close();
            return loadClasses;
        }
    }

    public class ListViewFormsP
    {
        private Config config = Config.GetInstance();
        private PropertyBase<List<ListViewFormProperty>> pro = new PropertyBase<List<ListViewFormProperty>>();
        
        public void save(List<lff.ListViewForm.ListViewPanel> FormList)
        {
            string filename = config.SesstionXML;

            List<ListViewFormProperty> formprolist = new List<ListViewFormProperty>();
            foreach (lff.ListViewForm.ListViewPanel form in FormList)
            {
                List<ListViewProperty> list = new List<ListViewProperty>();
                foreach (ListViewForm.FileListView listview in form)
                {
                    list.Add(new ListViewProperty(
                        listview.CurrentPath,
                        listview.View,
                        ListViewItemSortType.Name
                        )
                        );
                }

                ListViewFormProperty formpro = new ListViewFormProperty();
                formpro.ActiveTab = 0;
                formpro.ListViewPropertyList = list;
                formprolist.Add(formpro);
            }
            pro.save(filename, formprolist);
        }

        public void load(List<lff.ListViewForm.ListViewPanel> formlist)
        {
            string filename = config.SesstionXML;
            if (!File.Exists(filename)) return;

            List<ListViewFormProperty> formprolist = pro.load(filename);
            for (int i = 0; i < formprolist.Count; i++ )
            {
                lff.ListViewForm.ListViewPanel form = formlist[i];
                foreach (ListViewProperty listviewpro in formprolist[i].ListViewPropertyList)
                {
                    if (Directory.Exists(listviewpro.path))
                        form.OpenNewTab(listviewpro.path);
                }
                if (form.TabPageCount == 0)
                    form.Close();
            }
        }
    }

    public class ListViewFormProperty
    {
        private int _activetab;
        private List<ListViewProperty> _ListViewPropertyList;

        public int ActiveTab
        {
            get { return this._activetab; }
            set { this._activetab = value; }
        }

        public List<ListViewProperty> ListViewPropertyList
        {
            get { return this._ListViewPropertyList; }
            set { this._ListViewPropertyList = value; }
        }
    }
    public class ListViewProperty
    {
        public string path;
        public View view;
        public ListViewItemSortType sorttype;

        public ListViewProperty()
        {
        }
        public ListViewProperty(string path, View view, ListViewItemSortType sorttype)
        {
            this.path = path;
            this.view = view;
            this.sorttype = sorttype;
        }
    }


}
