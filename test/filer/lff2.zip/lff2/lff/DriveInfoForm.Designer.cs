﻿namespace lff
{
    partial class DriveInfoForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.DriveInfolistView = new System.Windows.Forms.ListView();
            this.columnName = new System.Windows.Forms.ColumnHeader();
            this.columnSize = new System.Windows.Forms.ColumnHeader();
            this.columnType = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // DriveInfolistView
            // 
            this.DriveInfolistView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnName,
            this.columnType,
            this.columnSize});
            this.DriveInfolistView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DriveInfolistView.Location = new System.Drawing.Point(0, 0);
            this.DriveInfolistView.Name = "DriveInfolistView";
            this.DriveInfolistView.Size = new System.Drawing.Size(292, 273);
            this.DriveInfolistView.TabIndex = 0;
            this.DriveInfolistView.UseCompatibleStateImageBehavior = false;
            this.DriveInfolistView.View = System.Windows.Forms.View.Details;
            // 
            // columnName
            // 
            this.columnName.Text = "Name";
            this.columnName.Width = 63;
            // 
            // columnSize
            // 
            this.columnSize.Text = "Free/Total";
            this.columnSize.Width = 85;
            // 
            // columnType
            // 
            this.columnType.Text = "Type";
            this.columnType.Width = 98;
            // 
            // DriveInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.DriveInfolistView);
            this.Name = "DriveInfoForm";
            this.Text = "DriveInfoForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView DriveInfolistView;
        private System.Windows.Forms.ColumnHeader columnName;
        private System.Windows.Forms.ColumnHeader columnType;
        private System.Windows.Forms.ColumnHeader columnSize;

    }
}