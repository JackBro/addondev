using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace lff
{
    public partial class DriveInfoForm : Form
    {
        public DriveInfoForm()
        {
            InitializeComponent();
            init();    
        }
        private void init()
        {
            DriveInfo[] allDrives = DriveInfo.GetDrives();
            foreach (DriveInfo info in allDrives)
            {
                ListViewItem item = new ListViewItem();
                item.Text = info.Name;
                item.SubItems.Add(info.DriveType.ToString());
                if(info.IsReady)
                    item.SubItems.Add(string.Format(
                        "{0}/{1}", 
                        Utility.ConvertToBKMG(info.AvailableFreeSpace), 
                        Utility.ConvertToBKMG(info.TotalSize))
                        );

                DriveInfolistView.Items.Add(item);
            }
        }
    }
}