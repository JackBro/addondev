using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace lff
{
    public class FileOperationArgs
    {
        public IntPtr Handle;
        public Win32API.FOFunc FileOperationType; 
        public string[] fromfiles;
        public string[] tofiles;
        public string topath;
    }

    public static class FileOperation
    {
        public static void Copy(IntPtr hwnd, string[] files, string topath)
        {
            Win32API.SHFILEOPSTRUCT sf = new Win32API.SHFILEOPSTRUCT();
            sf.hwnd = hwnd;
            sf.wFunc = Win32API.FOFunc.FO_COPY;
            sf.pFrom = String.Join("\0", files) + '\0';
            //sf.pTo = topath + '\0'+'\0';
            sf.pTo = topath;
            sf.fFlags = Win32API.FOFlags.FOF_ALLOWUNDO;
            sf.fAnyOperationsAborted = false;
            sf.lpszProgressTitle = "Copy";
            Win32API.SHFileOperation(ref sf);
        }

        public static void Delete(IntPtr hwnd, string[] files)
        {
            Win32API.SHFILEOPSTRUCT sf = new Win32API.SHFILEOPSTRUCT();
            sf.hwnd = hwnd;
            sf.wFunc = Win32API.FOFunc.FO_DELETE;
            sf.pFrom = String.Join("\0", files) + '\0';
            sf.pTo = null;
            sf.fFlags = Win32API.FOFlags.FOF_ALLOWUNDO;
            sf.fAnyOperationsAborted = false;
            sf.lpszProgressTitle = "Delete";
            Win32API.SHFileOperation(ref sf);
        }


        public static void Exec(IntPtr hwnd, string file)
        {
            try
            {
                ProcessStartInfo psinfo = new ProcessStartInfo();
                psinfo.FileName = file;
                psinfo.WorkingDirectory = Path.GetDirectoryName(file);
                psinfo.UseShellExecute = true;
                psinfo.ErrorDialogParentHandle = hwnd;
                psinfo.Verb = "open";
                Process p = Process.Start(psinfo);
            }
            catch (System.ComponentModel.Win32Exception e)
            {

            }
        }

        public static void Exec(IntPtr hwnd, string file, string param)
        {
            try
            {
                ProcessStartInfo psinfo = new ProcessStartInfo();
                psinfo.FileName = file;
                psinfo.Arguments = param;
                psinfo.WorkingDirectory = Path.GetDirectoryName(file);
                psinfo.UseShellExecute = true;
                psinfo.ErrorDialogParentHandle = hwnd;
                psinfo.Verb = "open";
                Process p = Process.Start(psinfo);
            }
            catch (System.ComponentModel.Win32Exception e)
            {

            }
        }
    }
}
