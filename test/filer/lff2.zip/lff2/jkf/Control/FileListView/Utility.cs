using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace lff
{
    public static class Utility
    {
        private const long SIZE_K = 1024;
        private const long SIZE_M = 1024*1024;
        private const long SIZE_G = 1024 * 1024 * 1024;

        public static string ConvertToBKMG(long fsize)
        {
            string cnv = string.Empty;
            if(fsize < SIZE_K)
            {
                cnv = fsize.ToString() + "B";
            }
            else if(fsize < SIZE_M)
            {
                long tmp = fsize/SIZE_K;
                cnv = tmp.ToString() + "KB";
            }
            else if(fsize < SIZE_G)
            {
                long tmp = fsize/SIZE_M;
                cnv = tmp.ToString() + "MB";
            }
            else
            {
                long tmp = fsize/SIZE_G;
                cnv = tmp.ToString() + "GB";
            }

            return cnv;
        }

        public static void debug(string msg)
        {
            Debug.WriteLine(msg);
        }
    }
    
    public enum ClipBoardState
    {
        Non,
        Cut,
        Copy
    }

    public static class ClipBoardUtility
    {
        public static void CopyToClipboard(string[] files, bool cut)
        {
            if (files != null)
            {
                IDataObject data = new DataObject(DataFormats.FileDrop, files);
                MemoryStream memo = new MemoryStream(4);
                byte[] bytes = new byte[] { (byte)(cut ? 2 : 5), 0, 0, 0 };
                memo.Write(bytes, 0, bytes.Length);
                data.SetData("Preferred DropEffect", memo);
                Clipboard.SetDataObject(data);
            }
        }

        public static ClipBoardState GetClipBoardState()
        {
            IDataObject data = Clipboard.GetDataObject();
            if (!data.GetDataPresent(DataFormats.FileDrop))
                return ClipBoardState.Non;

            MemoryStream stream = (MemoryStream)
              data.GetData("Preferred DropEffect", true);
            int flag = stream.ReadByte();
            if (flag != 2 && flag != 5)
                return ClipBoardState.Non;

            if (flag == 2)
                return ClipBoardState.Cut;
            else
                return ClipBoardState.Copy;
        }

        public static string[] GetFromClipboard()
        {
            IDataObject data = Clipboard.GetDataObject();
            if (!data.GetDataPresent(DataFormats.FileDrop))
                return null;

            return (string[]) data.GetData(DataFormats.FileDrop);
        }
    }
}
