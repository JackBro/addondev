using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.ComponentModel;
using System.Drawing;

namespace lff.ListViewForm
{
    public partial class FileListView : ListView
    {
        //private class FileEvevtResult
        //{
        //    public Boolean IsDelete;
        //    public int DeletedIndex;
        //}

        private uint starttime;
        private System.Timers.Timer timer;
        private Queue<Object> FileSystemEventQueue = new Queue<object>();
        private List<string> FileSystemChangedEventList = new List<string>();
        private BackgroundWorker eventworker = null;

        public void InitFileSystemEventCheck()
        {
            timer = new System.Timers.Timer(200);
            timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
            timer.Stop();

            if (eventworker == null)
            {
                eventworker = new BackgroundWorker();
                eventworker.WorkerReportsProgress = true;
                eventworker.DoWork += new DoWorkEventHandler(eventworker_DoWork);
                eventworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(eventworker_RunWorkerCompleted);
            }
        }

        void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            timer.Stop();
            if (eventworker.IsBusy)
            {
                while (eventworker.IsBusy)
                {
                    System.Threading.Thread.Sleep(100);
                    Application.DoEvents();
                }
            }          
            eventworker.RunWorkerAsync();
        }

        void eventworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //Invoke((MethodInvoker)delegate()
            //{
                //int count = this.FilenameList.Count - this.ListViewItemList.Count;
                //if (count > 0)
                //{
                //    for (int i = 0; i < count; i++)
                //        this.ListViewItemList.Add(new ListViewItem());
                //}

                //FileEvevtResult re = e.Result as FileEvevtResult;
                //if (re.IsDelete)
                //{
                //    if (this.View == View.Details)
                //    {
                //        for (int i = re.DeletedIndex; i < this.FilenameList.Count; i++)
                //        {
                //            FileData fdata = FileDataList[FilenameList[i]];
                //            //this.ListViewItemList[i].Text = FilenameList[i];
                //            this.ListViewItemList[i].SubItems[1].Text = Utility.ConvertToBKMG(fdata.size);
                //            this.ListViewItemList[i].SubItems[2].Text = fdata.ext;
                //            this.ListViewItemList[i].SubItems[3].Text = fdata._lastwritetimeTostr;

                //            //this.ListViewItemList[i].ImageIndex =
                //            //    this.iconcache.RegIcon(Path.Combine(_path, fdata.name), fdata.IsDirectory, fdata.ext);
                //        }
                //    }
                //}
                //this.VirtualListSize = this.FilenameList.Count;
            //});
        }

        void eventworker_DoWork(object sender, DoWorkEventArgs e)
        {
            //if (InvokeRequired)
            //{
            //    Invoke(new MethodInvoker(this.Sync));
            //}
            //else
            //{
            Invoke((MethodInvoker)delegate()
            {
                if(TopItem != null)
                TopItem.Focused = true;
            });
            //FileEvevtResult re = new FileEvevtResult();
            //re.DeletedIndex = this.FilenameList.Count - 1;

            FileSystemEventOrder forder = new FileSystemEventOrder();
            List<FileSystemEventObj> eventlist = forder.Order(FileSystemEventQueue, FileSystemEventQueue.Count);
            
        
            foreach (FileSystemEventObj fobj in eventlist)
            {
                System.Diagnostics.Debug.WriteLine("EventObj " + fobj.changetype.ToString() + " oldname=" + fobj.oldname + " name=" + fobj.name);
                if (fobj.changetype == WatcherChangeTypes.Deleted)
                {
                    if (!FileDataList.ContainsKey(fobj.name))
                    {
                        //BackgroundWorker worker = (BackgroundWorker)sender;
                        //re.IsDelete = true;
                        //int tmp = this.FilenameList.IndexOf(fobj.name);
                        //this.FilenameList.RemoveAt(tmp);
                        //this.ListViewItemList.RemoveAt(tmp);
                        //if (tmp < re.DeletedIndex)
                        //{
                        //    re.DeletedIndex = tmp;
                        //}
                        Invoke((MethodInvoker)delegate()
                        {
                            this.Items.RemoveByKey(fobj.name);
                        });
                    }
                }
                else if (fobj.changetype == WatcherChangeTypes.Created)
                {
                    if (FileDataList.ContainsKey(fobj.name))
                    {
                        //this.FilenameList.Add(fobj.name);
                        Invoke((MethodInvoker)delegate()
                        {
                            ListViewItem item = new ListViewItem(fobj.name);
                            item.Name = fobj.name;
                            FileData fdata = this.FileDataList[fobj.name];
                            item.ImageIndex = this.iconcache.GetNormalIcon(Path.Combine(this._path, fobj.name), fdata.IsDirectory);
                            this.Items.Add(item);
                        });
                    }
                }
                else if (fobj.changetype == WatcherChangeTypes.Renamed)
                {
                    //if (FileDataList.ContainsKey(fobj.name)
                    //    && FilenameList.Contains(fobj.oldname))
                    //{
                    //    int index = this.FilenameList.IndexOf(fobj.oldname);
                    //    this.FilenameList[index] = fobj.name;
                    //    Invoke((MethodInvoker)delegate()
                    //    {
                    //        this.RedrawItems(index, index, false);
                    //    });
                    //}
                    Invoke((MethodInvoker)delegate()
                    {
                        if (FileDataList.ContainsKey(fobj.name)                              
                            && !this.Items.ContainsKey(fobj.name))
                        {
                            //create
                            ListViewItem item = new ListViewItem(fobj.name);
                            item.Name = fobj.name;
                            FileData fdata = FileDataList[fobj.name];
                            item.ImageIndex = this.iconcache.GetNormalIcon(Path.Combine(this._path, fobj.name), fdata.IsDirectory);
                            this.Items.Add(item);
                        }
                        else if (FileDataList.ContainsKey(fobj.name)
                            && this.Items.ContainsKey(fobj.oldname))
                        {
                            this.Items.RemoveByKey(fobj.oldname);
                        }
                        else if (!FileDataList.ContainsKey(fobj.name) 
                            && this.Items.ContainsKey(fobj.name))
                        {
                            //ListViewItem item = this.Items[fobj.oldname];
                            //item.Text = fobj.name;
                            //item.Name = fobj.name;
                            //item.ImageIndex = this.iconcache.RegIcon(Path.Combine(this._path, fobj.name));

                            //ListViewItem item = new ListViewItem(fobj.name);
                            //item.Name = fobj.name;
                            //item.ImageIndex = this.iconcache.RegIcon(Path.Combine(this._path, fobj.name));
                            //this.Items.Add(item);
                            this.Items.RemoveByKey(fobj.name);
                        }
                        else if (FileDataList.ContainsKey(fobj.name)
                            && this.Items.ContainsKey(fobj.oldname)
                            && this.Items.ContainsKey(fobj.name))
                        {
                            //ListViewItem item = new ListViewItem(fobj.name);
                            //item.Name = fobj.name;
                            //item.ImageIndex = this.iconcache.RegIcon(Path.Combine(this._path, fobj.name));
                            //this.Items.Add(item);

                            //ListViewItem item = this.Items[fobj.oldname];
                            //item.Text = fobj.name;
                            //item.Name = fobj.name;
                            //item.ImageIndex = this.iconcache.RegIcon(Path.Combine(this._path, fobj.name));

                        }
                        else if (FileDataList.ContainsKey(fobj.name)
                            && this.Items.ContainsKey(fobj.oldname)
                            && !this.Items.ContainsKey(fobj.name))
                        {
                            //Rename

                            //ListViewItem item = new ListViewItem(fobj.name);
                            //item.Name = fobj.name;
                            //item.ImageIndex = this.iconcache.RegIcon(Path.Combine(this._path, fobj.name));
                            //this.Items.Add(item);

                            ListViewItem item = this.Items[fobj.oldname];
                            item.Text = fobj.name;
                            item.Name = fobj.name;
                            FileData fdata = FileDataList[fobj.name];
                            item.ImageIndex = this.iconcache.GetNormalIcon(Path.Combine(this._path, fobj.name), fdata.IsDirectory);
                        }
                    });
                }
            }

            lock (FileSystemChangedEventList)
            {
                foreach (string fname in FileSystemChangedEventList)
                {
                    if (FileDataList.ContainsKey(fname))
                    {
                        FileData fdata = FileDataList[fname];
                        fdata.RefreshFileInfo(fdata.fullpath);
                        if ((fdata.attribute & FileAttributes.ReadOnly) > 0)
                        {
                            Invoke((MethodInvoker)delegate()
                            {
                                ListViewItem item = this.Items[fname];
                                item.ForeColor = Color.Red;
                            });
                        }
                        else
                        {
                            Invoke((MethodInvoker)delegate()
                            {
                                ListViewItem item = this.Items[fname];
                                item.ForeColor = Color.Black;
                            });
                        }
                    }
                }
                FileSystemChangedEventList.Clear();
            }
            //}
            //e.Result = re;
        }

        public void Reset()
        {
            starttime = Win32API.GetTickCount();
        }

        public void InterruptFileSystemEvent()
        {
            uint t =  Win32API.GetTickCount();
            if (t - starttime < 100)
            {
                timer.Stop();
                timer.Start();
            }
            else
            {    
                timer.Start();
            }
            starttime = Win32API.GetTickCount();
        }
    }

    public class FileSystemEventObj
    {
        public WatcherChangeTypes changetype;
        public string name;
        public string oldname;

        public FileSystemEventObj(WatcherChangeTypes changetype, string name)
        {
            this.changetype = changetype;
            this.name = name;
            this.oldname = string.Empty;
        }

        public FileSystemEventObj(WatcherChangeTypes changetype, string name, string oldname)
        {
            this.changetype = changetype;
            this.name = name;
            this.oldname = oldname;
        }

    }
    class FileSystemEventOrder
    {
        

        private List<FileSystemEventObj> eventlist = new List<FileSystemEventObj>();
        public FileSystemEventOrder()
        {

        }

        private FileSystemEventObj GetEventObj(string name)
        {
            foreach (FileSystemEventObj eventobj in eventlist)
            {
                if (eventobj.name == name)
                    return eventobj;
            }
            return null;
        }

        public List<FileSystemEventObj> Order(Queue<Object> FileSystemEventQueue, int count)
        {
            for (int i = 0; i < count; i++ )
            {
                Object obj = FileSystemEventQueue.Dequeue();
                if (obj.GetType() == typeof(FileSystemEventArgs))
                {
                    FileSystemEventArgs arg = obj as FileSystemEventArgs;
                    switch (arg.ChangeType)
                    {
                        case WatcherChangeTypes.Created:
                            eventlist.Add(new FileSystemEventObj(arg.ChangeType, arg.Name));
                            break;
                        case WatcherChangeTypes.Deleted:
                            FileSystemEventObj eventobj = this.GetEventObj(arg.Name);
                            if (eventobj != null)
                            {
                                eventobj.changetype = arg.ChangeType;
                            }
                            else
                            {
                                eventlist.Add(new FileSystemEventObj(arg.ChangeType, arg.Name));
                            }
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    //rename
                    RenamedEventArgs arg = obj as RenamedEventArgs;
                    FileSystemEventObj eventobj = this.GetEventObj(arg.Name);
                    if (eventobj != null)
                    {
                        eventobj.changetype = arg.ChangeType;
                        eventobj.name = arg.Name;
                    }
                    else
                    {
                        eventlist.Add(new FileSystemEventObj(arg.ChangeType, arg.Name, arg.OldName));
                    }
                }
            }
            return eventlist;
        }
    }
}
