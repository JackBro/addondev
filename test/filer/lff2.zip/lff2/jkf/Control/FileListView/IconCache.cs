using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Drawing.Imaging;

namespace lff
{
    class CutedListViewItem
    {
        private List<ListViewItem> listviewlist;
        private IconCache iconcache;

        private static CutedListViewItem cutedlistviewitem = null;
        private CutedListViewItem()
        {
            listviewlist = new List<ListViewItem>();
            iconcache = IconCache.GetInstance();
        }
        public static CutedListViewItem GetInstance()
        {
            if (cutedlistviewitem == null)
                cutedlistviewitem = new CutedListViewItem();

            return cutedlistviewitem;
        }

        public void Set(string path, ListView.SelectedListViewItemCollection items)
        {
            this.Reset();

            foreach (ListViewItem item in items)
            {
                string fullpath = Path.Combine(path, item.Text);
                item.ImageIndex = iconcache.GetAlphaIcon(fullpath, Directory.Exists(fullpath));
                listviewlist.Add(item);
            }
        }

        public void Reset()
        {
            if (listviewlist.Count > 0 && listviewlist[0].ListView != null)
            {
                lff.ListViewForm.FileListView listview = listviewlist[0].ListView as lff.ListViewForm.FileListView;
                string path = listview.CurrentPath;
                foreach (ListViewItem item in listviewlist)
                {
                    string fullpath = Path.Combine(path, item.Text);
                    item.ImageIndex = iconcache.GetNormalIcon(fullpath, Directory.Exists(fullpath));
                }
            }
            listviewlist.Clear();
        }
    }

    class IconCache:IDisposable
    {
        private ImageList IconList = new ImageList();
        private List<string> NeedFileNameExtList = new List<string>(new string[]{".exe", ".ico"});
        private static IconCache iconcache = null;

        private IconCache()
        {
            IconList.ColorDepth = ColorDepth.Depth32Bit;
            IconList.ImageSize = new Size(16, 16);
        }

        public static IconCache GetInstance()
        {
            if (iconcache == null)
                iconcache = new IconCache();
            
            return iconcache;
        }

        public ImageList ImageList
        {
            get { return this.IconList; }
        }

        //public int RegIcon(string path)
        //{
        //    string key;
        //    Boolean IsDirectory = Directory.Exists(path);
        //    if (IsDirectory)
        //        key = "/directory";
        //    else
        //    {
        //        string ext = Path.GetExtension(path);
        //        if (ext == string.Empty)
        //            key = "/NoExt";
        //        else
        //            key = "/" + ext;
        //    }
        //    return this.GetIcon(path, key);
        //}

        //public int RegAlphaIcon(string path)
        //{
        //    string key;
        //    string ext = string.Empty;
        //    Boolean IsDirectory = Directory.Exists(path);
        //    if (IsDirectory)
        //        key = "//directory";
        //    else
        //    {
        //        ext = Path.GetExtension(path);
        //        if (ext == string.Empty)
        //            key = "//NoExt";
        //        else
        //            key = "//" + ext;
        //    }
        //    return this.GetAlphaIcon(path, ext, key, IsDirectory);
        //}

        private string GetKey(string path, Boolean IsDirectory, string prefix)
        {
            string key;
            string ext = string.Empty;
            if (IsDirectory)
                key = "directory";
            else
            {
                ext = Path.GetExtension(path);
                if (ext == string.Empty)
                    key = "NoExt";
                else
                {
                    if (NeedFileNameExtList.Contains(ext))
                    {
                        key = Path.GetFileName(path);
                    }
                    else
                    {
                        key = ext;
                    }     
                }
            }
            return prefix + key;
        }

        public int GetNormalIcon(string path, Boolean IsDirectory)
        {
            string key = GetKey(path, IsDirectory, "/");

            if (IconList.Images.ContainsKey(key))
                return IconList.Images.IndexOfKey(key);
 
            Win32API.SHFILEINFO shinfo = new Win32API.SHFILEINFO();
            IntPtr hSuccess = Win32API.SHGetFileInfo(path, 0, ref shinfo, (uint)Marshal.SizeOf(shinfo), Win32API.SHGFI_ICON | Win32API.SHGFI_SMALLICON);
            if (hSuccess != IntPtr.Zero)
            {
                IconList.Images.Add(key, Icon.FromHandle(shinfo.hIcon));
                int index = IconList.Images.Count - 1;

                Win32API.DestroyIcon(shinfo.hIcon);
                return index;
            }
            return -1;
        }

        public int GetAlphaIcon(string path, Boolean IsDirectory)
        {
            string key = GetKey(path, IsDirectory, "//");

            if (IconList.Images.ContainsKey(key))
                return IconList.Images.IndexOfKey(key);

            string key2 = GetKey(path, IsDirectory, "/");
            //if (IsDirectory)
            //    key2 = "/directory";
            //else
            //{
            //    if (ext == string.Empty)
            //        key2 = "/NoExt";
            //    else
            //        key2 = "/" + ext;
            //}

            Image image = IconList.Images[IconList.Images.IndexOfKey(key2)];
            Bitmap dest = new Bitmap(image.Width, image.Height);
            Graphics g = Graphics.FromImage(dest);

            Bitmap bitmap = new Bitmap(image);
            float[][] ptsArray ={ 
                    new float[] {1, 0, 0, 0, 0},
                    new float[] {0, 1, 0, 0, 0},
                    new float[] {0, 0, 1, 0, 0},
                    new float[] {0, 0, 0, 0.5f, 0}, 
                    new float[] {0, 0, 0, 0, 1}};
            ColorMatrix clrMatrix = new ColorMatrix(ptsArray);
            ImageAttributes imgAttributes = new ImageAttributes();
            imgAttributes.SetColorMatrix(clrMatrix,
                    ColorMatrixFlag.Default,
                    ColorAdjustType.Bitmap);
            g.DrawImage(bitmap,
                new Rectangle(0, 0, bitmap.Width, bitmap.Height),
                0, 0, bitmap.Width, bitmap.Height,
                GraphicsUnit.Pixel, imgAttributes);
            
            // Dispose
            g.Dispose();

            IconList.Images.Add(key, dest);
            return IconList.Images.Count - 1;
        }

        #region IDisposable �����o

        public void Dispose()
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
