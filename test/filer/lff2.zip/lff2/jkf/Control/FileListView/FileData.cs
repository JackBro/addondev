using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace lff
{
    public class FileData
    {
        public string name;
        public string fullpath;
        public long size;
        public Boolean IsDirectory;
        public string ext;
        public FileAttributes attribute;
        private DateTime _lastwritetime;
        public string _lastwritetimeTostr;

        public FileData(string path)
        {
            this.RefreshFileInfo(path);
        }

        public void RefreshFileInfo(string path)
        {
            FileInfo info = new FileInfo(path);
            attribute = info.Attributes;
            if ((attribute & FileAttributes.Directory) > 0)
            {
                IsDirectory = true;
                size = 0;
            }
            else
            {
                IsDirectory = false;
                size = info.Length;
            }

            name = info.Name;
            ext = info.Extension;
            _lastwritetime = info.LastWriteTime;
            _lastwritetimeTostr = string.Format("{1}", "G", _lastwritetime.ToString());

            fullpath = path;
        }
    }
}
