# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ajaxtest::Application.config.secret_token = '5ce0509f9c2939e9c60c73618d49dba8f2981c6dddfdca9d4f5abaf036e36245a472d3537ccc455a26baa0e6ab4d80d94d5c63ab5d2a21e1d0132e70e4b6ab26'
