class EventsController < ApplicationController
#respond_to :html, :js


  def index
  end
  
  def ajax
    #@event = Event.new(:endtime => 1.hour.from_now)
    #respond_with @event
		#respond_to do |format|
		#    format.js {render :content_type => 'text/javascript'}
		#end
		respond_to do |format|
		    format.js {render :layout=>false}
		end
    #render :layout => false
    #render :update do |page|
		#	page<<"$('#desc_dialog').dialog('destroy')" 
		#end
  end
end
