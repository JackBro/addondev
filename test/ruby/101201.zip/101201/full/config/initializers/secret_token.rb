# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Full::Application.config.secret_token = '008b8aaef9f1829f287b6579a2c660bad2899c2c42629d08ea8c72a932920b750a300fa66c7503de54967174f90da552fbd0b5c18844aa872c07e1a83a9129b9'
