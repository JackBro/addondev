  (int)(long)&((struct stringpool2_t *)0)->stringpool_osf1_0,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_osf1_1,
