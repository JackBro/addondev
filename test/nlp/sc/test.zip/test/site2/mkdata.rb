# -*- coding: utf-8 -*-
#http://embeddedcontrol-job.com/private/index.html?utm_source=overture&utm_medium=cpc&utm_campaign=embeddedcontrol_search

require 'nokogiri'
require 'kconv'
require 'open-uri'

user_agent = 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)'
parent = "http://embeddedcontrol-job.com/"
if ARGV.size==0
	links=[]
	Dir::glob("data/*.*").each {|f|
		doc = Nokogiri::HTML.parse(File.read(f, :encoding => Encoding::UTF_8), nil, 'UTF-8')
		doc.xpath("//a[@class='moreDetail']").each do |a|
			print a["href"].to_s.tosjis, "\n"
			links.push(parent + a["href"].to_s)
		end
	}
	links.uniq!

	File.open("links.txt","w") do |io|
	  io.write links.join("\n")
	end
elsif ARGV.size==1
	i=0
	IO.foreach("links.txt") do |s|
		print "get #{s}", "\n"
	  html = open(s, 'User-Agent' => user_agent).read
		File.open("data/detaile#{i.to_s}.htm","w") do |io|
		  io.write html
		end
		i=i+1
		#break
		sleep(5)
	end
end

#url="http://embeddedcontrol-job.com/jobdetail/NJB849737;jsessionid=czt1hsh3fz6d?list=%E3%83%87%E3%82%B8%E3%82%BF%E3%83%AB%E5%AE%B6%E9%9B%BB&search_category=pro"
#html = open(url, 'User-Agent' => user_agent).read
#print html

#print ans[0].size, "\n"
#print ans[0]["ポジション"].tosjis, "\n"
#print ans[0]["仕事内容"].tosjis, "\n"
#print ans[0]["必須"].tosjis, "\n"
#doc.xpath("//table").each do |t|
#	if t["class"] == "tbl_jobDetail" then
#		t.xpath(".//tbody/tr").each do |tb|
#			print tb.xpath(".//th").to_s.tosjis, "\n"
#			print tb.xpath(".//td").to_s.tosjis, "\n"
#		end
#		break
#	end
#end
