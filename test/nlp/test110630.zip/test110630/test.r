library(RMeCab)

setwd("C:/nlp/test")
source("site3/LSA.txt")

#docterm  <-  docMatrix("site3/text")
docterm  <-docMatrix("site3/text", pos = c("名詞") )
head(docterm)
 docterm  <-docterm[-(1:5),]
 docterm2  <-  Kyoki(docterm,  minDocFreq=2)
 svd.docterm<-svd(docterm2)
 rslt  <-  dimReducShare(svd.docterm,  share=0.5,  docterm=docterm2)
 str(rslt)
 myCosine(a=t(rslt$dk))

 unmei  <-  RMeCabC("装置で動作。制御ソフトの開発。C")
 tmp  <-  unlist(unmei)
  lst  <-  names(tmp)  %in%  c("名詞",  "動詞",  "形容詞")
  unmei  <-  tmp[lst]
 unmei.q  <-  myQuery(unmei,  rownames(rslt$tk))

unmei.vec  <-  t(unmei.q)  %*%  rslt$tk  %*%  solve(diag(rslt$sk))
unmei.vec  <-  as.vector(unmei.vec)
unmei.cos  <-  myCosine(a=t(rslt$dk),  b=unmei.vec)
names(unmei.cos)  <-  as.character(1:11)
round(sort(unmei.cos,  decreasing=T),3)[1:5]
