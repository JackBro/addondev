# -*- coding: utf-8 -*-

#http://embeddedcontrol-job.com/private/index.html?utm_source=overture&utm_medium=cpc&utm_campaign=embeddedcontrol_search

require 'nokogiri'
require 'kconv'
require 'nkf'

def tocsv(lines)
	if lines==nil
		lines=""
	end
	#input = lines.encode('Shift_JIS')
	#lines = NKF.nkf('-SsZ4',input )
	lines = lines.tr('ａ-ｚＡ-Ｚ０-９', 'a-zA-Z0-9')
	lines.gsub!(/,/, '、')
	lines.gsub!(/　/, ' ')
	lines.gsub!(/（/, '(')
	lines.gsub!(/）/, ')')
	lines.gsub!(/[◇◆●○■▼★△◎\?]/, '')

	s = ""
	lines.split("\n").each{|l|
		if l!="" && /$。/!~l
			l=l+"。" #.force_encoding("UTF-8")
		end
		s=s+l
	}
	return s
end

def sp(oubo)
	re ={}
	h = oubo.scan(/【(.*)】([^【】]+)/)
	h.each{|v|
		if v[0].index("必須")
			re["必須"] = v[1]
		elsif v[0].index("歓迎")
			re["歓迎"] = v[1]
		end
	}
	if re.size ==0
		re["必須"] = oubo
		re["歓迎"] = ""
	end

	if re["歓迎"] == nil
		re["歓迎"] = ""
	end

	return re["必須"], re["歓迎"]
end

#id	名前	url	何	内容	必須	歓迎
def k(hs)
	re = ""
	hs.each{|h|
		if h.size>0
		re = re + ["",h["社名"],"",h["ポジション"],h["業務内容"],h["必須"],h["歓迎"]].join(',') + "\n"
		end
	}
	return re
end
#name, pos, det, ess, well


$ans=[]

def parse(filename)
	h={}
	doc = Nokogiri::HTML.parse(File.read(filename, :encoding => Encoding::UTF_8), nil, 'UTF-8')
	doc.xpath("//table/tr").each do |a|
		#print a["href"].to_s.tosjis, "\n"
		i=1
		a.xpath(".//th").each do |th|
			key = th.inner_text
			#val = a.xpath(".//td").inner_text
			a.xpath(".//td[#{i}]/div").remove
			val = a.xpath(".//td[#{i}]").inner_html.gsub(/<br>/, "\n")
			val = val.delete("\t")
			if key == "社名" || key == "業務内容"
				#print key.tosjis, " : ", tocsv(val).tosjis, "\n" #val.tosjis.delete("\t"), "\n"
				#print val.tosjis, "\n"
				h[key] = tocsv(val)
			elsif key == "求める経験"
				hi,kan = sp(val)
				#print "必須".tosjis, " : ", hi, "\n"
				#print "歓迎".tosjis, " : ", kan, "\n"
				#print "必須".tosjis, " : ", tocsv(hi).tosjis, "\n"
				#print "歓迎".tosjis, " : ", tocsv(kan).tosjis, "\n"
				h["必須"] = tocsv(hi)
				h["歓迎"] = tocsv(kan)
			end
			i=i+1
		end
	end
	$ans.push(h)
end

#parse("data/detaile16.htm")
#return

Dir::glob("data/*.htm").each {|f|
	print "cnv #{f}","\n"
	parse(f)
}

print $ans.size, "\n"
cs = k($ans)
File.open("data.csv","w") do |io|
  io.write cs
end
