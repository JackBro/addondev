# -*- coding: utf-8 -*-

require 'kconv'

def cos_sim(v1, v2)
  return dot_product(v1, v2) / (vec_abs(v1) * vec_abs(v2))
end

def dot_product(v1, v2)
  v = 0
  v1.keys.each do |key|
    if v1[key] and v2[key] then
      v += v1[key] * v2[key]
    end
  end
  return v
end

def vec_abs(v)
  l = 0;
  v.values.each do |value|
    l += value * value
  end
  return Math::sqrt(l)
end

def parse_tags(tags)
  vec = Hash.new(0)
  tags.each do |value|
    tag, occ = value.split(":")
    vec[tag] += occ.to_i
  end
  return vec
end

begin
  dat = ARGV[0]
  fh = open(dat, "r")
  
  doc = {}
  while line = fh.gets
		line = line.force_encoding("UTF-8")
    field = line.chomp.split(",")
    doc_id, url, title, tags = field[0].to_i, field[1], field[2], field[3, field.length - 1]
    doc[doc_id] = {"url" => url, "title" => title, "tags" => parse_tags(tags)}
  end

  input_vec = {"book" => 29, "梅田望夫" => 27, "将棋" => 16, "書評" => 13, "本" => 11}

  sim = Hash.new(0)
  doc.keys.each do |doc_id|
    sim[doc_id] = cos_sim(input_vec, doc[doc_id]["tags"])
  end
  
  result = sim.to_a
  result.sort! do |a, b|
    b[1] <=> a[1]
  end
  result.each do |value|
    print sprintf("%2d: %.2f %s\n", value[0], value[1], doc[value[0]]["title"].tosjis)
  end
ensure
  # abort("usage: %0 <csv>\n")
end
