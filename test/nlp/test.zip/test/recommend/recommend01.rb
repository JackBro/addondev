def cos_sim(v1, v2)
  return dot_product(v1, v2) / (vec_abs(v1) * vec_abs(v2))
end

def dot_product(v1, v2)
  v = 0
  v1.keys.each do |key|
    if v1[key] and v2[key] then
      v += v1[key] * v2[key]
    end
  end
  return v
end

def vec_abs(v)
  l = 0;
  v.values.each do |value|
    l += value * value
  end
  return Math::sqrt(l)
end

v1 = {"perl" => 5, "web" =>  2, "google" =>  1};
v2 = {"perl" => 0, "web" =>  5, "google" => 10};
v3 = {"perl" => 0, "web" => 10, "google" =>  5};

print cos_sim(v1, v2), "\n"
print cos_sim(v1, v3), "\n"
print cos_sim(v2, v3), "\n"
