require 'mkmf'



have_header('mecab.h') && create_makefile('MeCab')
