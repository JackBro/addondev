
const Cc = Components.classes;
const Ci = Components.interfaces;

function selectFile(node) {
    var filePicker = Cc["@mozilla.org/filepicker;1"].createInstance(Ci.nsIFilePicker);
    filePicker.init(window, "Choose a file.", filePicker.modeOpen);
    if (filePicker.show() == filePicker.returnOK) {
    /*
        editorFile = filePicker.file;
        node.value = editorFile.path;
        */
    }
}

function updateCssUse(name)
{
	let n;
	var pref = document.getElementById(name).getAttribute("preference");
	var val = document.getElementById(pref).value;
	//if(val)
	//{
		var elts = document.getElementsByAttribute("group", name);
		Array.forEach(elts, function(elt) {
			elt.disabled = !val;
		});
	//}
}

function updateCss(node)
{
	var css = node.value;
	if(!css || css =='' ) return;
	
	var sss = Cc['@mozilla.org/content/style-sheet-service;1'].getService(Ci.nsIStyleSheetService);
	var ios = Cc['@mozilla.org/network/io-service;1'].getService(Ci.nsIIOService);

	//Application.console.log("loadAndRegisterSheet css = " + css);
	try
	{
		var cssfile = Cc['@mozilla.org/file/local;1'].createInstance(Ci.nsILocalFile);
		cssfile.initWithPath(css);
		var uri = ios.newURI(ios.newFileURI(cssfile).spec, null,null);
		    	    
		if(sss.sheetRegistered(uri, sss.USER_SHEET))
			sss.unregisterSheet(uri, sss.USER_SHEET);
		    
		if(! sss.sheetRegistered(uri, sss.USER_SHEET)) {
			sss.loadAndRegisterSheet(uri, sss.USER_SHEET);
		}
	}catch(ex)
	{
		
	}
}

function onDialogAccept()
{	
	var recentWindow = Cc['@mozilla.org/appshell/window-mediator;1']
		.getService(Ci.nsIWindowMediator)
		.getMostRecentWindow('navigator:browser');
	var cmd_setpref = 	recentWindow.document.getElementById("stacklink_cmd_setpref");
	cmd_setpref.doCommand();
//		var fc =popupset.firstChild;
//	fc.setAttribute("width", 500);
}