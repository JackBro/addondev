function String(){};
String.prototype.length =1;
String.prototype.charAt= function(index){return "";};
String.prototype.concat= function(value){return "";};

var m = "";
