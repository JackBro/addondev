//MyObject = 
//{
//    message3: null,
//    hello3: function (arg0){
//		arg0=100;
//    }
//}
//
//MyObject.hello3("b");
//MyObject.message3="jj";
//MyObject.add = {};

//function func0(arg0)
//{
//	var gg=20.4;
//	function func1(arg1, argg)
//	{
//	}
//}

//
//function func0(arg0)
//{
//	this.h0=0;
//	this.h0=10;
//	h0=3;
//	
//	this.h1=0;
//	arg0=0;
//	arg=p;
//	arg=100;
//	var ttt=0;
//	ttt = 100;
//}
//
//func0("e");

//
//MyObject3.test={
//		nn:null
//}
//MyObject3.prototype = 
//{
//    message3: null,
//    hello3: function (arg0){
//    }
//}
//
//MyObject3.test.add = {};

//var mobj = new Object();
//mobj.start = function() {
//  this.obj = "obj";
//  this.prop = "prop";	
//}
//

//function Accelimation(obj, prop, to, time, zip, unit) {
//  this.obj = obj;
//  this.prop = prop;
//}
//
//Accelimation = function(o) {
//	this.test0 = o;
//	this.test1 = 1;
//	//var hh=0;
//};
//
//Accelimation._add = function(o) {
//	this.test = 1;
//};
//
//Accelimation.prototype.start = function() {
//		var tt=0;
//  this.t0 = Time;
//  this.t1 = Time;
//  Accelimation._add(this);
//  //var hh2=0;
//};


//
//function ArrayEnumerator(array)
//{
//	var tt=0;
//	this.index = 0;
//	this.index2 = 0;
//	//this.array = array;
//	this.hasMoreElements = function()
//	{
//		//return (this.index < array.length);
//	}
//	this.getNext = function()
//	{
//		//return this.array[++this.index];
//	}
//}

//var test0, tes1, test2;

//Firebug.Debugger = extend(Firebug.ActivableModule,
//{
//	fbs: fbs,
//	
//    initialize: function()
//    {
//        this.nsICryptoHash = Components.interfaces["nsICryptoHash"];
//        this.debuggerName =  window.location.href+"--"+FBL.getUniqueId(); /*@explore*/
//        this.toString = function() { return this.debuggerName; } /*@explore*/ //bug
//        this.hash_service = CCSV("@mozilla.org/security/hash;1", "nsICryptoHash");
//
//        this.wrappedJSObject = this;  // how we communicate with fbs
//        this.panelName = "script";
//
//        Firebug.broadcast = function encapsulateFBSBroadcast(message, args)
//        {
//            fbs.broadcast(message, args);
//        }
//        
//        this.onFunctionCall = bind(this.onFunctionCall, this);  
//        Firebug.ActivableModule.initialize.apply(this, arguments);
//    },
//    
//    getCurrentFrameKeys: function()
//    {
//		this.hhhh=200;
//		var tt = 10;
//    },
//    
//    focusWatch: function(context)
//    {
//        if (context.detached)
//            context.chrome.focus();
//        else
//            Firebug.toggleBar(true);
//
//        context.chrome.selectPanel("script");
//
//        var watchPanel = context.getPanel("watches", true);
//        if (watchPanel)
//        {
//        	Firebug.CommandLine.isReadyElsePreparing({title:"reaady", tf:function(){var p = tr;}});
//            watchPanel.editNewWatch();
//        }
//    },
//});
FBL.ns(function() {
	var tt=0;
	const p=0;
	function aa()
	{
		
	}
	aa();
	h=o;
	Firebug.Debugger = extend(Firebug.ActivableModule,
	{
	    fbs: fbs, // access to firebug-service in chromebug under browser.xul.DOM.Firebug.Debugger.fbs /*@explore*/
	    getCurrentFrameKeys: function(context)
	    {        
	        this.getFrameKeys(context);
	    }
	});
	aa();
	//var tt=0;
	//nn=0;
});
//
//function Car(brand) {
//   this.brand = brand;
//}
//Car.prototype.getBrand = function() {
//	this.ch = 10;
//   return this.brand;
//}
//
//Car.prototype.getBrand.bb = function() {
//	this.ch2 = 10;
//}
//
//var b = new Car("");

//for (var index = 0, test=0; index < array.length; index++) {
//	m=0;
//	m++;
//}
//
//CmdUtils.CreateCommand({
//	   name:'macro',
//	   author: { name: "Kurt Cagle", email: "kurt@oreilly.com"}
//	});
