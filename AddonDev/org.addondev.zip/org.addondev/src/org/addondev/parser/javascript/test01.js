
function test(){};
test.hh = function(){};

function test2(){};
test2 = {
	n:null,
	hh2:function(){
		
	}
}

var m = test;
var n= test2;
//m.hh=function(){};
//var n= m.length;

