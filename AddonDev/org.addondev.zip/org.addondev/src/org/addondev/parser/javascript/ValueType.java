package org.addondev.parser.javascript;

public enum ValueType {
	VAR,
	FUNCTION
	
}
