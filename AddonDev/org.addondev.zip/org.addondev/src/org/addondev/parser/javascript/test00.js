
//var m="100";
//
//var MyObject = function(){};
//MyObject.prototype = 
//{
//    message3: null,
//    
//    hello3: function (arg0){
//    	//arg0 = 100;
//    	//var aa=0;
//    }
//};
//
//var tmp = new MyObject();

var stacklink_106ec9de_7db3_40c6_93c2_39563e25a8d6 = {};

(function(){

var tmp = stacklink_106ec9de_7db3_40c6_93c2_39563e25a8d6;

tmp.stackpanel = {
	isItemAppended:false
};

})();