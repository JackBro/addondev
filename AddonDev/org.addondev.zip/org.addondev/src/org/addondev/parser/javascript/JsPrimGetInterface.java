package org.addondev.parser.javascript;

import java.util.ArrayList;
import java.util.List;

public class JsPrimGetInterface implements IJsPrimFunction {

	@Override
	public String Call(ArrayList<JsNode> args) {
		// TODO Auto-generated method stub
		if(args.size() > 0)
		{
			
		}
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
