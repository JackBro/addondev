package org.addondev.parser.javascript;

public class NumberNode {

}
