package org.addondev.parser.javascript;

public class ParserException extends Exception {
	public ParserException() {
		super("PaeserError");
	}
}
