package org.addondev.parser.javascript;

public enum ObjectType {
	object,
	array,
	function,
	string,
	numbser,
	nsIIOService,
	nsILocalFile,
	nsIFileOutputStream
}
