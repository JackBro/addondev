function nsILocalFile(){};
