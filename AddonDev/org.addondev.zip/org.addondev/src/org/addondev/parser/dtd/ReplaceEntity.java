package org.addondev.parser.dtd;

public class ReplaceEntity {
	

}
