package org.addondev.wizard;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;

public class NewJavaScriptFileWizardPage extends WizardNewFileCreationPage {

	public NewJavaScriptFileWizardPage(String pageName,
			IStructuredSelection selection) {
		super(pageName, selection);
		// TODO Auto-generated constructor stub
	}

}
