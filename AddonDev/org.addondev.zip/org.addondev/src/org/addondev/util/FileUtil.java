package org.addondev.util;

import org.eclipse.core.resources.IFile;

public class FileUtil {
	
//	public static String getContent(IFile file)
//	{
//		
//	}
}
