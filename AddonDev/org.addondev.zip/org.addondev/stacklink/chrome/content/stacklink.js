var stacklink_106ec9de_7db3_40c6_93c2_39563e25a8d6 = {};

(function(){
	
const Cc = Components.classes;
const Ci = Components.interfaces;

const SAVEFILE = '';
const version = '0.1.0';

var viewtypeAry = ['start','center','end','wrap'];

var $ = stacklink_106ec9de_7db3_40c6_93c2_39563e25a8d6;
var $_ = 'stacklink_106ec9de_7db3_40c6_93c2_39563e25a8d6';

$.stackpanel = {
	isItemAppended:false,
		
	load: function()
	{
		this.mousefuncmap={};
		this.mousefuncmap[0] = $.util.loadCurrentTab;
		this.mousefuncmap[1] = $.util.openNewTab;
		this.mousefuncmap[2] = $.util.selectTab;
		this.mousefuncmap[3] = $.util.closeTab;
		this.mousefuncmap[4] = $.util.non;
		
		this._panel = document.createElement("panel");
		this._panel.className = "root-panel";
		this._panel.setAttribute("noautofocus", "true");
		this._panel.setAttribute("noautohide", "true");
		this._panel.id = "root-panel";
		var popupset = document.getElementById("stacklink-popupset");
		popupset.appendChild(this._panel);

		this._mainPanel = document.createElement("vbox");
		this._mainPanel.className = "main-panel";
		
		this.setPref();
		
		this._panel.appendChild(this._mainPanel);

		if(this.save_restore)
		{
			try
			{
				var file = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsILocalFile);
				file.append('stacklink.js');
				if(file.exists())
				{
					var stritems = $.util.read(file);
					if (typeof(JSON) == "undefined") {
					  Components.utils.import("resource://gre/modules/JSON.jsm");
					  JSON.parse = JSON.fromString;
					  JSON.stringify = JSON.toString;
					}

					this.tmpitems = JSON.parse(stritems);	
				}
			}
			catch(ex)
			{
				Components.utils.reportError("load restor error : " + ex);
				this.tmpitems = null;
			}
		}
		
	    this.tabContext = document.getAnonymousElementByAttribute(gBrowser, "anonid", "tabContextMenu");
	    this.tabContext.addEventListener("popupshowing", this.onpPopupShowing, false);
	},
	
	unload: function()
	{
		if(this.save_restore)
		{
			try
			{
				var saveitems = [];
				var groups = this._mainPanel.groups;
				var itempanels = this._mainPanel.itemPanels;
				
				for(var i=0; i < groups.length; i++)
				{
					let key = groups[i].getAttribute('key');
					let title = groups[i].title;
	
					var panelitems = itempanels[key].items;
					let items = [];
					for(var j=0; j<panelitems.length; j++)
					{
						items.push({title:panelitems[j].title, url:panelitems[j].url});
					}
					saveitems.push({title:title, items:items});
				}
				
				if (typeof(JSON) == "undefined") {
				  Components.utils.import("resource://gre/modules/JSON.jsm");
				  JSON.parse = JSON.fromString;
				  JSON.stringify = JSON.toString;
				}				
				var strings = JSON.stringify(saveitems);	
				
				var dir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsILocalFile);
				dir.append('stacklink.js');
				$.util.write(dir, strings);
			}
			catch(ex)
			{
				Components.utils.reportError("unload save error : " + ex);
			}
		}
	},
	
	onpPopupShowing:function(event)
	{
	    if (!this.menuitem) 
	    {
	    	var separator = document.createElement("menuseparator");
	    	$.stackpanel.tabContext.appendChild(separator);
	    	
	    	this.menuitem = document.createElement("menuitem");
	    	this.menuitem.setAttribute("id", "stacklink-addFromTabMenu");
	    	this.menuitem.setAttribute("label", 'test');
	    	//this.menuitem.setAttribute("accesskey", stringbundle.getString('undoDetachTabMenuaccesskey'));
	    	this.menuitem.setAttribute("oncommand", $_ + '.stackpanel.addFromTab(event);');
	    	$.stackpanel.tabContext.appendChild(this.menuitem);
	    }
	},
	
	addFromTab:function(event)
	{
		var title = gBrowser.getBrowserForTab(gBrowser.mContextTab).contentDocument.title;
		var url = gBrowser.getBrowserForTab(gBrowser.mContextTab).contentDocument.location;
		var items =[{title:title, url:url}];
		this.addItems(items);		
	},
	
	setPref:function()
	{
		if(Application.prefs.getValue("extensions.stacklink.css.use", false))
		{
			var css = Application.prefs.getValue("extensions.stacklink.css.path", "");
			this.updateCss(css);
		}
		
		this.panelpos = Application.prefs.getValue("extensions.stacklink.panel.pos", 0)==0?'before_start':'before_end';
		
		var panelwidth = Application.prefs.getValue("extensions.stacklink.panel.size.width", 200);
		var panelmaxheight = Application.prefs.getValue("extensions.stacklink.panel.size.maxheight", 200);
		var viewtype = viewtypeAry[Application.prefs.getValue("extensions.stacklink.label", 0)];
		
		this.save_restore = Application.prefs.getValue("extensions.stacklink.save_restore", false);
		

		this._mainPanel.setAttribute("width", panelwidth);
		this._mainPanel.setAttribute("maxheight", panelmaxheight);	
		this._mainPanel.setAttribute('viewtype', viewtype);
		
		if(this.isItemAppended)
		{
			this._mainPanel.applyFunc('item-box', function(elem)
			{
				elem.setAttribute("maxheight", panelmaxheight);	
				elem.setAttribute("viewtype", viewtype);	
				
				var items = [];
				var ns = elem.items;
				for(var i=0; i < ns.length; i++)
				{
					items.push({title:ns[i].title, url:ns[i].url, itemClicked:ns[i].itemClicked});
				}
				var collapsed = elem.collapsed;
				elem.collapsed = false;
				elem.removeItem();
				elem.reset();
				items.reverse();
				for(i=0; i < items.length; i++)
				{
					Application.console.log("items[i].title = " + items[i].title);
					elem.addItem(items[i].title, items[i].url, $.stackpanel.itemClick, items[i].itemClicked);
				}
				elem.collapsed = collapsed;			
			});
		}

		this.map={};
		this.map["left"]        = Application.prefs.getValue("extensions.stacklink.mouse.left",      0);
		this.map["altleft"]     = Application.prefs.getValue("extensions.stacklink.mouse.alt_left",  4);
		this.map["ctrlleft"]    = Application.prefs.getValue("extensions.stacklink.mouse.ctrl_left", 4);
		this.map["shiftleft"]   = Application.prefs.getValue("extensions.stacklink.mouse.shift_left",4);
		
		this.map["middle"]      = Application.prefs.getValue("extensions.stacklink.mouse.middle",       1);
		this.map["altmiddle"]   = Application.prefs.getValue("extensions.stacklink.mouse.alt_middle",   4);
		this.map["ctrlmiddle"]  = Application.prefs.getValue("extensions.stacklink.mouse.ctrl_middle",  4);
		this.map["shiftmiddle"] = Application.prefs.getValue("extensions.stacklink.mouse.shift_middle", 4);
		
		this.map["right"]       = Application.prefs.getValue("extensions.stacklink.mouse.right",      4);
		this.map["altright"]    = Application.prefs.getValue("extensions.stacklink.mouse.alt_right",  4);
		this.map["ctrlright"]   = Application.prefs.getValue("extensions.stacklink.mouse.ctrl_right", 4);
		this.map["shiftright"]  = Application.prefs.getValue("extensions.stacklink.mouse.shift_right",4);	
	},
	
	onClickStatusbarIcon: function(event)
	{
	
		var test = true;
		
		if (event.button != 0) return;
		
		this.isOpen = !this.isOpen ? true : false;
		var fbmStatusIcon = document.getElementById('stacklinkStatusBarIcon');
		fbmStatusIcon.setAttribute("enable", this.isOpen == true?"on":"off");
		
		if(this.isOpen){
			
			$.DragdeGo.onLoad();
			
			if(this.isItemAppended)
			{
				this.showPanel();
			}
			else
			{
				if(this.save_restore)
				{
			  		this.showPanel();	
					this._addItemsWaitShowPopup(); 	
				}
				else
				{
					this.tmpitems = null;
			  		this.showPanel();	
					this._addItemsWaitShowPopup(); 						
				}
			}
		}else{
			this._panel.hidePopup();
			$.DragdeGo.unLoad();
		}
	},
	
	movePanelPos : function(panelPos)
	{	
		this.panelpos = panelPos;
		if(this.isOpen)
		{
			this._panel.hidePopup();
			this.showPanel();
		}
	},
	
	showPanel : function()
	{
		var button = document.getElementById("status-bar");
		this._panel.openPopup(button, this.panelpos, 0, 0, false, false);		
	},
	
  	showPreference : function()
  	{
  		var fu = "modal,titlebar,toolbar,centerscreen";
  		openDialog("chrome://stacklink/content/preference.xul", "Preferences", fu);
  	},
  	
	addItems : function(items)
	{	
  		if(!this.isItemAppended)
  		{
  			this.tmpitems = items;
  			this.showPanel();
			
			this._addItemsWaitShowPopup();
  		}
  		else
  		{
  			this._addItems(items); 
  		}  			
	},
	
	_addItemsWaitShowPopup:function()
	{
		if (this._panel.state == 'open')
		{ 
			if(!this.isItemAppended)
			{
				this._mainPanel.init(this.tmpitems, this.itemClick);
				//this.tmprestoredata = null;
				this.tmpitems = null;
				this.isItemAppended = true;
			}
			else
			{
				this._addItems(this.tmpitems);
			}
			return 0;
		}
		return setTimeout($_ + '.stackpanel._addItemsWaitShowPopup();', 200);		
	}, 	
	
	_addItems : function(items)
	{	  	
		
  		for(var index in items)
  		{
  			this._mainPanel.itemPanel.addItem(items[index].title, items[index].url, this.itemClick, items[index].itemClicked);
  		}
  		this.isItemAppended = true;
	},
	
	removeItem : function()
	{
		
	},
	
	itemClick:function(e)
	{
		if(e.target == 'close')
		{
			$.stackpanel._mainPanel.itemPanel.removeItem(e.element);
		}
		else if(e.target == 'item')
		{	
			var key = $.util.getKey(e.event);		
			if($.stackpanel.mousefuncmap[$.stackpanel.map[key]])
			{
				$.stackpanel.mousefuncmap[$.stackpanel.map[key]](e);
			}
		}
	},
	
	groupItemContextMenuClick:function(elem, type)
	{
		var parent = elem.parentNode.parentNode;
		
		switch (type) {
		case 'new': 
			this._mainPanel.addGroup('undefined');
			break;
		case 'rename': 
			var ret = window.prompt("Enter name", parent.title, "");
			if(ret && ret != parent.title)
				parent.title = ret;
			break;
		case 'delete': 
			$.stackpanel._mainPanel.deleteGroup(parent);
			break;
		}	
	},
	
	updateCss : function(path)
	{
		if(!path || path =='' ) return;
		
		var sss = Cc['@mozilla.org/content/style-sheet-service;1'].getService(Ci.nsIStyleSheetService);
		var ios = Cc['@mozilla.org/network/io-service;1'].getService(Ci.nsIIOService);
	
		try
		{
			var cssfile = Cc['@mozilla.org/file/local;1'].createInstance(Ci.nsILocalFile);
			cssfile.initWithPath(path);
			var uri = ios.newURI(ios.newFileURI(cssfile).spec, null,null);
			    	    
			if(sss.sheetRegistered(uri, sss.USER_SHEET))
				sss.unregisterSheet(uri, sss.USER_SHEET);
			    
			if(! sss.sheetRegistered(uri, sss.USER_SHEET)) {
				sss.loadAndRegisterSheet(uri, sss.USER_SHEET);
			}
		}catch(ex)
		{
			
		}
	}
};

///////////////////////////////////////////////////
//util
$.util =
{
    regfilename:/([^\/]*)$/,
    
	loadCurrentTab:function(e)
	{
		loadURI(e.url);
		$.util.changeClickedElement(e.element);
	},
		
	openNewTab:function(e)
	{
		getBrowser().addTab(e.url);
		$.util.changeClickedElement(e.element);
	},
	
	selectTab:function(e)
	{
		var tabs = gBrowser.tabContainer;
		var num = gBrowser.browsers.length;
		for (var i = 0; i < num; i++) {
		  var b = gBrowser.getBrowserAtIndex(i);
		  try {
		    if(b.currentURI.spec == e.url)
		    {
		    	gBrowser.selectedTab = tabs.childNodes[i];
		    	$.util.changeClickedElement(e.element);
		    	break;
		    }
		  } catch(ex) {
		    Components.utils.reportError(ex);
		  }
		}
	},
	
	closeTab:function(e)
	{
		
	},
	
	non:function(e){},
	
	changeClickedElement:function(element)
	{
		if($.stackpanel.changefontcolor)
		{
			element.itemClicked = true;
			element.style.color = $.stackpanel.clickedfontcolor;
		}
	},
	
	getItems:function(document, htmldata)
	{
		var title;
		var url;
		var items = [];
		var elem=document.createElement('div');
		
		elem.innerHTML = htmldata;
		var elements = elem.getElementsByTagName('*');
		if(elements.length > 0)
		{
			for (var i = 0; i < elements.length; i++){
				if (elements[i].href)
				{
					title = elements[i].innerHTML.toString();
					url = elements[i].toString();
					items.push({title:title, url:url});
				}
			}
		}	
		return items;
	},
	
	getImageItems:function(document, htmldata)
	{
		var title;
		var href;
		var src;
		var items = [];
		var elem=document.createElement('div');
		
		elem.innerHTML = htmldata;
		var elements = elem.getElementsByTagName('*');	
		if(elements.length > 0)
		{
			for (var i = 0; i < elements.length; i++)
			{	
				if (elements[i].href)
				{
					href = elements[i].toString();
				}
				if(elements[i].src)
				{
					src = elements[i].getAttribute('src');
				}
			}
			
			if(!href)
			{
				href = src.toString();
			}
			
			var res = href.toString().match($.util.regfilename);
			title = res[0];					
			items.push({title:title, url:href});			
			
		}	
		return items;
	},
	
	write : function(file, text)
	{
		if (!file.exists()) {
			file.create(file.NORMAL_FILE_TYPE, 0666);
		}
		var charset = 'UTF-8';
		var fileStream = Cc['@mozilla.org/network/file-output-stream;1'].createInstance(Ci.nsIFileOutputStream);
		fileStream.init(file, 0x02 | 0x20 , 0x200, false);
		
		var converterStream = Cc['@mozilla.org/intl/converter-output-stream;1'].createInstance(Ci.nsIConverterOutputStream);
		converterStream.init(fileStream, charset, text.length, Ci.nsIConverterInputStream.DEFAULT_REPLACEMENT_CHARACTER);
		converterStream.writeString(text);
		converterStream.close();
		fileStream.close();
	},

	read : function(file)
	{
		var charset = 'UTF-8';
		var fileStream = Cc['@mozilla.org/network/file-input-stream;1'].createInstance(Ci.nsIFileInputStream);
		fileStream.init(file, 1, 0, false);
		var converterStream = Cc['@mozilla.org/intl/converter-input-stream;1'].createInstance(Ci.nsIConverterInputStream);
		converterStream.init(fileStream, charset, fileStream.available(),
		converterStream.DEFAULT_REPLACEMENT_CHARACTER);

		var out = {};
		converterStream.readString(fileStream.available(), out);
		var fileContents = out.value;
		converterStream.close();
		fileStream.close();
		return fileContents;
	},
	
	getKey : function(event)
	{
		var key = event.altKey?'alt':'';
		key += event.ctrlKey?'ctrl':'';
		key += event.shiftKey?'shift':'';
		switch (event.button) {
		case 0: 
			key += 'left';
			break;
		case 1: 
			key += 'middle';
			break;
		case 2: 
			key += 'right';
			break;
		}		
		return key;
	}
}


///////////////////////////////////////////////////
//drag/drop
$.DragdeGoDNDObserver = {
	init:false,
	getSupportedFlavours : function () {
    	var flavours = new FlavourSet();
    	flavours.appendFlavour("text/html");
    	flavours.appendFlavour("text/x-moz-url");  
    	
    	//flavours.appendFlavour('application/x-moz-file', 'nsIFile');

    	return flavours;
  	},

	onDragStart: function (evt,transferData,action){
//  	    var txt=evt.target.getAttribute("href");
//  	  Application.console.log("onDragStart txt= " + txt);
//
//  	    transferData.data=new TransferData();
//  	    transferData.data.addDataForFlavour("text/unicode",txt);
 		
	},
	onDragOver: function (evt,flavour,session)
	{
		var dragenable = false;
		
		if (session.isDataFlavorSupported("text/html") || session.isDataFlavorSupported("text/x-moz-url"))
		//if (session.sourceNode && session.sourceNode == '#text')
		{
			if(!this.init)
			{
				this.init = true;
				$.DenDZones_CheckDZStillDragging();
			}
			dragenable = true;
		}
		
		session.canDrop = dragenable;
		if(dragenable)
		{
			evt.stopPropagation();
			//evt.preventDefault();
			//evt.stopPropagation();
		}
		return session.canDrop;
		
	},
	onDrop: function (evt,dropdata,session)
	{
			
		//Application.console.log("dropdata.data = " + dropdata.data);
		//Application.console.log("session.sourceNode.nodeName = " + session.sourceNode.nodeName);
		
		//Application.console.log("session.sourceDocument.parentNode = " + session.sourceDocument.parentNode);
		if (session.isDataFlavorSupported("text/html") || session.isDataFlavorSupported("text/x-moz-url"))
		{
			var enable = false;
			if(dropdata.data && dropdata.data!="")
			{
				var items = [];
				var title;
				var url;
				switch (session.sourceNode.nodeName) {
					case '#text':
					case 'A': //3.5
						items = $.util.getItems(gBrowser.selectedBrowser.contentDocument, dropdata.data);
						break;
						
					case 'treechildren':
						if(session.sourceDocument.documentURI == 'chrome://browser/content/bookmarks/bookmarksPanel.xul')
						{
							items = $.util.getItems(gBrowser.selectedBrowser.contentDocument, dropdata.data);
						}
						else if(session.sourceDocument.documentURI == 'chrome://scrapbook/content/scrapbook.xul')
						{
							try
							{
								var sbtree = window.document.getElementById("sidebar").contentWindow.sbTreeHandler;
								var selindex = sbtree.TREE.view.selection.currentIndex;
								var seltext = sbtree.TREE.view.getCellText(selindex, {index:0});

								if(dropdata.data.indexOf('chrome://', 0) < 0)
								{
									title = seltext?seltext:dropdata.data;
									url =  dropdata.data;
									items.push({title:title, url:dropdata.data});	
								}
							}
							catch(ex)
							{
								Components.utils.reportError("stacklink Error : " + ex);
							}
						}
						break;
						
					case 'IMG':
						items = $.util.getImageItems(gBrowser.selectedBrowser.contentDocument, dropdata.data);
						break;
				}
				
				if(items.length>0)
				{
					$.stackpanel.addItems(items);
					enable = true;	
				}
			}
		}
		if(enable)
		{
			session.canDrop = true;
			evt.preventDefault();
			evt.stopPropagation();
		}
		return true;
	},
	onDragExit: function (evt,session)
	{
		return true;
	}
}

$.DenDZones_DragOver = function(oEvent)
{
    var oSession = nsDragAndDrop.mDragSession;
    if (!oSession) nsDragAndDrop.mDragService.getCurrentSession();
 	if (oSession && (oSession.isDataFlavorSupported("text/html") || oSession.isDataFlavorSupported("text/x-moz-url")))
	{ 
 		nsDragAndDrop.dragOver(oEvent, $.DragdeGoDNDObserver);
	}
}

$.DenDZones_Drop = function(oEvent)
{	
	var oSession = nsDragAndDrop.mDragSession;
    if (!oSession) nsDragAndDrop.mDragService.getCurrentSession();
	if (oSession && (oSession.isDataFlavorSupported("text/html") || oSession.isDataFlavorSupported("text/x-moz-url")))
	{  
		nsDragAndDrop.drop(oEvent, $.DragdeGoDNDObserver);
	}
}

$.DenDZones_DragDropExit = function(oEvent)
{
	nsDragAndDrop.dragExit(oEvent, $.DragdeGoDNDObserver);	
}

$.DenDZones_CheckDZStillDragging= function()
{
	if ($.DragdeGo.iDenDZones_StillDragging && $.DragdeGo.iDenDZones_StillDragging <= 0)
	{
		return 0;
	}

	$.DragdeGo.iDenDZones_StillDragging --;
	return setTimeout($_ + '.DenDZones_CheckDZStillDragging();', 500);
}

$.DragdeGo = 
{
    iDenDZones_StillDragging :1,
	onLoad: function(){
		window.addEventListener('unload', $.DragdeGo.unLoad, false);
		window.removeEventListener('load', $.DragdeGo.onLoad, false);
		getBrowser().mPanelContainer.addEventListener('dragover', $.DenDZones_DragOver, true);
		getBrowser().mPanelContainer.addEventListener('dragdrop', $.DenDZones_Drop, true);
		getBrowser().mPanelContainer.addEventListener('drop', $.DenDZones_Drop, true);
		getBrowser().mPanelContainer.addEventListener('dragexit', $.DenDZones_DragDropExit, true);
	},
	unLoad: function(){
		window.removeEventListener('unload', $.DragdeGo.unLoad, false);
		getBrowser().mPanelContainer.removeEventListener('dragover', $.DenDZones_DragOver, true);
		getBrowser().mPanelContainer.removeEventListener('dragdrop', $.DenDZones_Drop, true);
		getBrowser().mPanelContainer.removeEventListener('drop', $.DenDZones_Drop, true);
		getBrowser().mPanelContainer.removeEventListener('dragexit', $.DenDZones_DragDropExit, true);
	}	
}

window.addEventListener("load", function(e) { $.stackpanel.load(e); }, false);
window.addEventListener("unload", function(e) { $.stackpanel.unload(e); }, false);

})();
