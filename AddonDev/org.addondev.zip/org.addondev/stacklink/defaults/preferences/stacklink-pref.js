pref("extensions.stacklink.label", 2);

pref("extensions.stacklink.panel.pos", 1);
pref("extensions.stacklink.panel.size.maxheight", 200);
pref("extensions.stacklink.panel.size.width",     200);

pref("extensions.stacklink.css.use", false);
pref("extensions.stacklink.css.path", "");

//0 : loadCurrentTab
//1 : openNewTab
//2 : selectTab
//3 : closeItem
//4 : non

pref("extensions.stacklink.mouse.left",       0);
pref("extensions.stacklink.mouse.alt_left",   4);
pref("extensions.stacklink.mouse.ctrl_left",  4);
pref("extensions.stacklink.mouse.shift_left", 4);

pref("extensions.stacklink.mouse.middle",      1);
pref("extensions.stacklink.mouse.alt_middle",  4);
pref("extensions.stacklink.mouse.ctrl_middle", 4);
pref("extensions.stacklink.mouse.shift_middle",4);

pref("extensions.stacklink.mouse.right",      4);
pref("extensions.stacklink.mouse.alt_right",  4);
pref("extensions.stacklink.mouse.ctrl_right", 4);
pref("extensions.stacklink.mouse.shift_right",4);   

pref("extensions.stacklink.save_restore", false);



